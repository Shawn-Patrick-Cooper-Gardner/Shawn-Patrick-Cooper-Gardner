import { useEffect, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import {
  Crosshair,
  FileStack,
  Flag,
  Lightbulb,
  Radio,
  Shield,
  Truck,
} from "lucide-react";
import { Mark } from "@/components/mark";
import { LiveClock } from "@/components/live-clock";
import { Badge } from "@/components/ui/badge";
import { PROGRAM, PHASES } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { cn } from "@/lib/utils";
import { formatPct } from "@/lib/format";

const NAV = [
  { to: "/", label: "COP", icon: Crosshair },
  { to: "/sensors", label: "Sensors", icon: Radio },
  { to: "/logistics", label: "Logistics", icon: Truck },
  { to: "/telemetry", label: "Telemetry", icon: Shield },
  { to: "/mission", label: "Mission", icon: Flag },
  { to: "/package", label: "Package", icon: FileStack },
  { to: "/doctrine", label: "Doctrine", icon: Lightbulb },
] as const;

export function Shell({ children }: { children: ReactNode }) {
  const bumpTick = useExcalibur((s) => s.bumpTick);
  const phase = PHASES[0];

  useEffect(() => {
    const id = window.setInterval(bumpTick, 1000);
    return () => window.clearInterval(id);
  }, [bumpTick]);

  return (
    <div className="flex h-dvh min-h-0 flex-col bg-bg text-fg print:h-auto print:overflow-visible">
      <p className="bg-alert/15 px-3 py-1.5 text-center font-mono text-xs uppercase tracking-widest text-alert print:hidden">
        {PROGRAM.classification}
        <span className="mx-2 text-alert/50">·</span>
        <span className="text-alert/80">{PROGRAM.control}</span>
      </p>

      <header className="flex items-center gap-3 border-b border-line px-3 py-2.5 sm:px-4 print:hidden">
        <div className="flex min-w-0 items-center gap-2.5">
          <Mark className="size-8 shrink-0" />
          <div className="min-w-0">
            <p className="truncate text-sm font-medium tracking-widest">
              EXCALIBUR
            </p>
            <p className="truncate font-mono text-xs uppercase tracking-widest text-muted">
              13 Aerospace Defense
            </p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-4">
          <div className="hidden text-right sm:block">
            <p className="font-mono text-xs uppercase tracking-widest text-muted">
              Phase {phase.id}
            </p>
            <p className="text-sm tabular-nums text-fg">
              {formatPct(phase.progress)} · {phase.window}
            </p>
          </div>
          <Badge tone="caution" className="hidden md:inline-flex">
            Pre-decisional
          </Badge>
          <LiveClock />
        </div>
      </header>

      <div className="flex min-h-0 flex-1 flex-col md:flex-row">
        <nav
          aria-label="Primary"
          className="flex shrink-0 gap-1 overflow-x-auto border-b border-line px-2 py-2 print:hidden md:w-16 md:flex-col md:items-center md:overflow-visible md:border-r md:border-b-0 md:px-2 md:py-3"
        >
          {NAV.map((item) => {
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={item.to === "/" ? { exact: true } : undefined}
                className={cn(
                  "flex h-11 min-w-11 shrink-0 items-center justify-center gap-2 rounded-md px-3 text-sm text-muted transition-[background-color,color] duration-150 ease-out hover:bg-elevated hover:text-fg md:w-11 md:px-0",
                )}
                activeProps={{
                  className: "bg-elevated text-fg",
                }}
                title={item.label}
              >
                <Icon className="size-4" strokeWidth={1.6} />
                <span className="md:sr-only">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        <div className="min-h-0 min-w-0 flex-1 overflow-auto print:overflow-visible">{children}</div>
      </div>
    </div>
  );
}
