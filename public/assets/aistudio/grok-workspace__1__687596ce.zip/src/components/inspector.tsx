import { CONVOYS, KIND_META, SENSORS, SITES, lookupEntity, surgeMargin } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { sensorLive, provenanceHash } from "@/lib/live";
import { formatCoord, formatPct } from "@/lib/format";
import { Kicker, Metric, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { StatusDot } from "@/components/status-dot";

export function Inspector() {
  const selectedId = useExcalibur((s) => s.selectedId);
  const tick = useExcalibur((s) => s.tick);
  const simLatG = useExcalibur((s) => s.simLatG);
  const entity = selectedId ? lookupEntity(selectedId) : null;

  if (!entity) {
    return (
      <Panel className="flex h-full flex-col justify-center">
        <Kicker>Inspector</Kicker>
        <h2 className="mt-2 text-lg font-medium">No object selected</h2>
        <p className="mt-2 text-sm text-muted">
          Select a sensor, convoy, or site on the theater map.
        </p>
      </Panel>
    );
  }

  if (entity.kind === "sensor") {
    const s = SENSORS.find((n) => n.id === entity.id);
    if (!s) return null;
    const live = sensorLive(s.id, s.health, tick);
    const tone =
      s.health === "nominal" ? "ok" : s.health === "degraded" ? "caution" : "alert";
    return (
      <Panel className="flex h-full flex-col gap-4 overflow-auto">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Kicker>Sensor · {KIND_META[s.kind].label}</Kicker>
            <h2 className="mt-1 text-lg font-medium tracking-tight">{s.name}</h2>
            <p className="font-mono text-xs text-muted">{s.id}</p>
          </div>
          <Badge tone={tone}>
            <StatusDot health={s.health} pulse />
            {s.health}
          </Badge>
        </div>
        <p className="text-sm text-muted">{s.notes}</p>
        <dl className="grid grid-cols-2 gap-3">
          <Metric label="Position" value={formatCoord(s.lat, s.lon)} />
          <Metric label="Elevation" value={`${s.elevM} m`} />
          <Metric label="Packets / s" value={live.packets.toLocaleString()} />
          <Metric
            label="Anomaly"
            value={formatPct(live.anomaly, 1)}
            tone={live.anomaly > 0.2 ? "caution" : "ok"}
          />
          <Metric label="SNR" value={`${live.snr.toFixed(1)} dB`} />
          <Metric label="Delay" value={`${live.delayMs.toFixed(0)} ms`} />
        </dl>
        <div>
          <Kicker>Spec / provenance</Kicker>
          <p className="mt-1 text-sm">{s.spec}</p>
          <p className="mt-1 font-mono text-xs text-muted">
            hash {provenanceHash(s.id, tick)} · installed {s.installed}
          </p>
        </div>
      </Panel>
    );
  }

  if (entity.kind === "convoy") {
    const c = CONVOYS.find((n) => n.id === entity.id);
    if (!c) return null;
    const margin = surgeMargin(c.fill, simLatG);
    return (
      <Panel className="flex h-full flex-col gap-4 overflow-auto">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Kicker>Convoy · HazMat</Kicker>
            <h2 className="mt-1 text-lg font-medium tracking-tight">{c.callsign}</h2>
            <p className="font-mono text-xs text-muted">
              {c.id} · {c.un}
            </p>
          </div>
          <Badge tone={margin < 0.05 ? "alert" : margin < 0.12 ? "caution" : "ok"}>
            {margin < 0.05 ? "surge watch" : "stable"}
          </Badge>
        </div>
        <p className="text-sm text-muted">{c.notes}</p>
        <dl className="grid grid-cols-2 gap-3">
          <Metric label="Cargo" value={c.cargo} />
          <Metric label="Tank" value={c.tank} />
          <Metric label="Fill" value={formatPct(c.fill)} />
          <Metric
            label="Surge margin"
            value={`${margin.toFixed(2)} g`}
            tone={margin < 0.05 ? "alert" : "ok"}
            hint={`at ${simLatG.toFixed(2)} g lateral`}
          />
        </dl>
      </Panel>
    );
  }

  const site = SITES.find((n) => n.id === entity.id);
  if (!site) return null;
  return (
    <Panel className="flex h-full flex-col gap-4 overflow-auto">
      <div>
        <Kicker>Site</Kicker>
        <h2 className="mt-1 text-lg font-medium tracking-tight">{site.name}</h2>
        <p className="font-mono text-xs text-muted">{site.id}</p>
      </div>
      <p className="text-sm text-muted">{site.notes}</p>
    </Panel>
  );
}
