import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

type Tone = "neutral" | "ok" | "caution" | "alert";

const tones: Record<Tone, string> = {
  neutral: "text-muted bg-elevated",
  ok: "text-ok bg-ok/10",
  caution: "text-caution bg-caution/10",
  alert: "text-alert bg-alert/10",
};

export function Badge({
  className,
  tone = "neutral",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: Tone }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-sm px-2 py-0.5 font-mono text-xs uppercase tracking-widest",
        tones[tone],
        className,
      )}
      {...props}
    />
  );
}
