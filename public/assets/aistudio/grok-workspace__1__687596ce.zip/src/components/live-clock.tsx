import { useEffect, useState } from "react";
import { formatZulu } from "@/lib/format";

export function LiveClock() {
  const [now, setNow] = useState<Date | null>(null);

  useEffect(() => {
    setNow(new Date());
    const id = window.setInterval(() => setNow(new Date()), 1000);
    return () => window.clearInterval(id);
  }, []);

  return (
    <div className="text-right">
      <p className="font-mono text-xs uppercase tracking-widest text-muted">Zulu</p>
      <p className="font-mono text-sm tabular-nums text-fg">
        {now ? formatZulu(now) : "——:——:——Z"}
      </p>
    </div>
  );
}
