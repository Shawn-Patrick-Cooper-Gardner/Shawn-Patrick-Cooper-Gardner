import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Panel({
  className,
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return (
    <section className={cn("rounded-xl bg-surface p-4 shadow-panel", className)}>
      {children}
    </section>
  );
}

export function Kicker({
  children,
  className,
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <p
      className={cn(
        "font-mono text-xs uppercase tracking-widest text-muted",
        className,
      )}
    >
      {children}
    </p>
  );
}

export function Metric({
  label,
  value,
  hint,
  tone,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: "ok" | "caution" | "alert" | "fg";
}) {
  const color =
    tone === "ok"
      ? "text-ok"
      : tone === "caution"
        ? "text-caution"
        : tone === "alert"
          ? "text-alert"
          : "text-fg";
  return (
    <div className="min-w-0">
      <Kicker>{label}</Kicker>
      <p className={cn("mt-1 font-medium tabular-nums tracking-tight", color)}>
        {value}
      </p>
      {hint ? <p className="mt-0.5 text-xs text-subtle">{hint}</p> : null}
    </div>
  );
}

export function PageHeader({
  kicker,
  title,
  children,
}: {
  kicker: string;
  title: string;
  children?: ReactNode;
}) {
  return (
    <header className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <Kicker>{kicker}</Kicker>
        <h1 className="mt-1 text-2xl font-medium tracking-tight text-fg">{title}</h1>
      </div>
      {children}
    </header>
  );
}
