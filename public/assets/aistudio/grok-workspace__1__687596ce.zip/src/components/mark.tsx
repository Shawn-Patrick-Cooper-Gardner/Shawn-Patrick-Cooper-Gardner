import { cn } from "@/lib/utils";

/** Geometric 13 lockup — the 13ADC tail-number mark. */
export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-fg", className)}
      fill="currentColor"
      aria-hidden="true"
    >
      <rect x="5.5" y="6.5" width="3.4" height="19" />
      <rect x="5.5" y="6.5" width="6.4" height="2.8" />
      <rect x="14.2" y="6.5" width="12.2" height="2.8" />
      <rect x="23.6" y="6.5" width="2.8" height="8.2" />
      <rect x="16.6" y="14.6" width="9.8" height="2.8" />
      <rect x="23.6" y="14.6" width="2.8" height="10.9" />
      <rect x="14.2" y="22.7" width="12.2" height="2.8" />
    </svg>
  );
}
