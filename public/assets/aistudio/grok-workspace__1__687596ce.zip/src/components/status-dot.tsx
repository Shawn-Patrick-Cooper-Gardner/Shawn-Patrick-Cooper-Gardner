import { cn } from "@/lib/utils";
import type { Health } from "@/lib/theater-data";

const tones: Record<Health, string> = {
  nominal: "bg-ok",
  degraded: "bg-caution",
  offline: "bg-alert",
};

export function StatusDot({
  health,
  pulse,
  className,
}: {
  health: Health;
  pulse?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-block size-1.5 shrink-0 rounded-full",
        tones[health],
        pulse && health === "nominal" && "pulse-live",
        className,
      )}
      aria-hidden="true"
    />
  );
}
