import { useCallback, useEffect, useRef, useState } from "react";
import {
  CITY_BLOCKS,
  CONVOYS,
  KIND_META,
  LAKE_POLY,
  OVERLAYS,
  ROADS,
  SENSORS,
  SITES,
  type OverlayId,
} from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { cn } from "@/lib/utils";
import { nyToLat, nxToLon } from "@/lib/theater-data";
import { formatCoord } from "@/lib/format";

function pointInPoly(x: number, y: number, poly: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [xi, yi] = poly[i];
    const [xj, yj] = poly[j];
    const intersect =
      yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi + 1e-9) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

function elevAt(x: number, y: number, lake: boolean): number {
  if (lake) return -0.45;
  const mccullough =
    Math.exp(-((x - 0.08) ** 2) / 0.018 - ((y - 0.5) ** 2) / 0.07) * 1.15;
  const river =
    Math.exp(-((x - 0.21) ** 2) / 0.012 - ((y - 0.72) ** 2) / 0.02) * 0.85;
  const black =
    Math.exp(-((x - 0.52) ** 2) / 0.03 - ((y - 0.88) ** 2) / 0.035) * 1.05;
  const frenchman =
    Math.exp(-((x - 0.1) ** 2) / 0.02 - ((y - 0.22) ** 2) / 0.04) * 0.65;
  const muddy =
    Math.exp(-((x - 0.86) ** 2) / 0.05 - ((y - 0.14) ** 2) / 0.05) * 0.95;
  const eldorado =
    Math.exp(-((x - 0.72) ** 2) / 0.04 - ((y - 0.8) ** 2) / 0.05) * 0.7;
  const noise =
    Math.sin(x * 41.3 + y * 29.7) * Math.sin(x * 17.1 - y * 13.4) * 0.04;
  return 0.12 + mccullough + river + black + frenchman + muddy + eldorado + noise;
}

function parseColor(input: string): [number, number, number] {
  const hex = input.trim();
  if (hex.startsWith("#")) {
    const h = hex.slice(1);
    const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
    return [
      parseInt(full.slice(0, 2), 16),
      parseInt(full.slice(2, 4), 16),
      parseInt(full.slice(4, 6), 16),
    ];
  }
  const m = hex.match(/rgba?\(([^)]+)\)/);
  if (m?.[1]) {
    const p = m[1].split(",").map((n) => parseFloat(n));
    return [p[0] ?? 16, p[1] ?? 16, p[2] ?? 18];
  }
  return [16, 16, 18];
}

function cssVar(name: string, fallback: string): string {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function along(path: [number, number][], t: number): [number, number] {
  const clamped = ((t % 1) + 1) % 1;
  const segs = path.length - 1;
  const f = clamped * segs;
  const i = Math.min(segs - 1, Math.floor(f));
  const u = f - i;
  const a = path[i];
  const b = path[i + 1];
  return [a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u];
}

function mix(
  a: [number, number, number],
  b: [number, number, number],
  t: number,
): [number, number, number] {
  return [
    a[0] + (b[0] - a[0]) * t,
    a[1] + (b[1] - a[1]) * t,
    a[2] + (b[2] - a[2]) * t,
  ];
}

function drawGlyph(
  ctx: CanvasRenderingContext2D,
  kind: string,
  x: number,
  y: number,
  r: number,
) {
  ctx.beginPath();
  if (kind === "lidar") {
    ctx.rect(x - r, y - r, r * 2, r * 2);
  } else if (kind === "hsi") {
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y);
    ctx.lineTo(x, y + r);
    ctx.lineTo(x - r, y);
    ctx.closePath();
  } else if (kind === "gpr") {
    ctx.moveTo(x, y - r);
    ctx.lineTo(x + r, y + r);
    ctx.lineTo(x - r, y + r);
    ctx.closePath();
  } else if (kind === "mag") {
    ctx.moveTo(x - r, y);
    ctx.lineTo(x + r, y);
    ctx.moveTo(x, y - r);
    ctx.lineTo(x, y + r);
  } else if (kind === "edge") {
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.moveTo(x - r * 1.5, y);
    ctx.lineTo(x + r * 1.5, y);
    ctx.moveTo(x, y - r * 1.5);
    ctx.lineTo(x, y + r * 1.5);
  } else {
    ctx.arc(x, y, r, 0, Math.PI * 2);
  }
}

export function TheaterMap() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const staticRef = useRef<HTMLCanvasElement | null>(null);
  const overlays = useExcalibur((s) => s.overlays);
  const selectedId = useExcalibur((s) => s.selectedId);
  const hoverId = useExcalibur((s) => s.hoverId);
  const setSelected = useExcalibur((s) => s.setSelected);
  const setHover = useExcalibur((s) => s.setHover);
  const [cursor, setCursor] = useState<string | null>(null);
  const overlaysRef = useRef(overlays);
  overlaysRef.current = overlays;

  const rebuildStatic = useCallback(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    if (!canvas || !wrap) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = wrap.clientWidth;
    const h = wrap.clientHeight;
    if (w < 8 || h < 8) return;
    canvas.width = Math.floor(w * dpr);
    canvas.height = Math.floor(h * dpr);
    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;

    const off = staticRef.current ?? document.createElement("canvas");
    staticRef.current = off;
    off.width = canvas.width;
    off.height = canvas.height;
    const ctx = off.getContext("2d");
    if (!ctx) return;

    const ov = overlaysRef.current;
    const topo = [
      parseColor(cssVar("--color-topo-0", "#121310")),
      parseColor(cssVar("--color-topo-1", "#181914")),
      parseColor(cssVar("--color-topo-2", "#1f201a")),
      parseColor(cssVar("--color-topo-3", "#272820")),
      parseColor(cssVar("--color-topo-4", "#313228")),
    ];
    const water = parseColor(cssVar("--color-water", "#1a2c36"));
    const waterDeep = parseColor(cssVar("--color-bg", "#09090b"));
    const gw = 280;
    const gh = 200;
    const tmp = document.createElement("canvas");
    tmp.width = gw;
    tmp.height = gh;
    const tctx = tmp.getContext("2d");
    if (!tctx) return;
    const img = tctx.createImageData(gw, gh);
    const heights = new Float32Array(gw * gh);
    const lakes = new Uint8Array(gw * gh);
    for (let j = 0; j < gh; j++) {
      for (let i = 0; i < gw; i++) {
        const x = i / (gw - 1);
        const y = j / (gh - 1);
        const lake = pointInPoly(x, y, LAKE_POLY);
        lakes[j * gw + i] = lake ? 1 : 0;
        heights[j * gw + i] = elevAt(x, y, lake);
      }
    }
    for (let j = 0; j < gh; j++) {
      for (let i = 0; i < gw; i++) {
        const idx = j * gw + i;
        const e = heights[idx];
        let col: [number, number, number];
        if (lakes[idx]) {
          const depth = Math.min(1, Math.abs(e));
          col = mix(water, waterDeep, depth * 0.45);
        } else {
          const t = Math.min(1, Math.max(0, e / 1.35));
          const band = t * (topo.length - 1);
          const b0 = Math.floor(band);
          const b1 = Math.min(topo.length - 1, b0 + 1);
          col = mix(topo[b0], topo[b1], band - b0);
          const i1 = Math.min(gw - 1, i + 1);
          const j1 = Math.min(gh - 1, j + 1);
          const dzdx = heights[j * gw + i1] - e;
          const dzdy = heights[j1 * gw + i] - e;
          const shade = 0.72 + 0.28 * Math.max(0, -dzdx * 0.7 - dzdy * 0.5);
          col = [col[0] * shade, col[1] * shade, col[2] * shade];
        }
        const p = idx * 4;
        img.data[p] = col[0];
        img.data[p + 1] = col[1];
        img.data[p + 2] = col[2];
        img.data[p + 3] = 255;
      }
    }
    tctx.putImageData(img, 0, 0);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(tmp, 0, 0, off.width, off.height);

    const sx = off.width;
    const sy = off.height;
    const px = (x: number) => x * sx;
    const py = (y: number) => y * sy;

    ctx.strokeStyle = cssVar("--color-water-edge", "#4a6570");
    ctx.lineWidth = 1.4 * dpr;
    ctx.beginPath();
    LAKE_POLY.forEach(([x, y], i) => {
      if (i === 0) ctx.moveTo(px(x), py(y));
      else ctx.lineTo(px(x), py(y));
    });
    ctx.stroke();

    ctx.fillStyle = cssVar("--color-city", "#3a3b36");
    for (const [x, y, w0, h0] of CITY_BLOCKS) {
      ctx.globalAlpha = 0.55;
      ctx.fillRect(px(x), py(y), w0 * sx, h0 * sy);
    }
    ctx.globalAlpha = 1;

    ctx.strokeStyle = cssVar("--color-road", "#6d6a62");
    ctx.lineWidth = 1.6 * dpr;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    for (const road of ROADS) {
      ctx.beginPath();
      road.forEach(([x, y], i) => {
        if (i === 0) ctx.moveTo(px(x), py(y));
        else ctx.lineTo(px(x), py(y));
      });
      ctx.stroke();
    }

    if (ov.grid) {
      ctx.strokeStyle = "rgba(236,234,228,0.07)";
      ctx.lineWidth = 1 * dpr;
      ctx.font = `${10 * dpr}px "IBM Plex Mono", ui-monospace, monospace`;
      ctx.fillStyle = "rgba(138,140,145,0.7)";
      for (let g = 1; g < 10; g++) {
        const x = g / 10;
        ctx.beginPath();
        ctx.moveTo(px(x), 0);
        ctx.lineTo(px(x), sy);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, py(x));
        ctx.lineTo(sx, py(x));
        ctx.stroke();
        const lon = nxToLon(x);
        ctx.fillText(`${Math.abs(lon).toFixed(2)}W`, px(x) + 6 * dpr, 14 * dpr);
      }
    }

    const hq = SITES[0];
    ctx.strokeStyle = "rgba(168,180,194,0.22)";
    ctx.lineWidth = 1 * dpr;
    for (const r of [0.08, 0.16, 0.26]) {
      ctx.beginPath();
      ctx.ellipse(px(hq.x), py(hq.y), r * sx, r * sy, 0, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.fillStyle = cssVar("--color-muted", "#8a8c91");
    ctx.font = `${10 * dpr}px Barlow, sans-serif`;
    ctx.fillText("LAKE MEAD", px(0.5), py(0.4));
    ctx.fillText("BOULDER CITY", px(0.165), py(0.635));
    ctx.fillText("HOOVER DAM", px(0.445), py(0.825));
  }, []);

  useEffect(() => {
    rebuildStatic();
    const wrap = wrapRef.current;
    if (!wrap) return;
    const ro = new ResizeObserver(() => rebuildStatic());
    ro.observe(wrap);
    return () => ro.disconnect();
  }, [rebuildStatic, overlays.grid]);

  useEffect(() => {
    let raf = 0;
    const loop = (now: number) => {
      const canvas = canvasRef.current;
      const off = staticRef.current;
      if (canvas && off) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.clearRect(0, 0, canvas.width, canvas.height);
          ctx.drawImage(off, 0, 0);
          const dpr = canvas.width / (wrapRef.current?.clientWidth || canvas.width);
          const sx = canvas.width;
          const sy = canvas.height;
          const px = (x: number) => x * sx;
          const py = (y: number) => y * sy;
          const ov = overlaysRef.current;
          const selected = useExcalibur.getState().selectedId;
          const hover = useExcalibur.getState().hoverId;
          const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
          const pulse = reduced ? 1 : 0.55 + 0.45 * Math.sin(now / 700);

          if (ov.logistics) {
            ctx.lineWidth = 1.2 * dpr;
            ctx.setLineDash([4 * dpr, 4 * dpr]);
            ctx.strokeStyle = cssVar("--color-caution", "#b89a78");
            ctx.globalAlpha = 0.7;
            for (const c of CONVOYS) {
              ctx.beginPath();
              c.path.forEach(([x, y], i) => {
                if (i === 0) ctx.moveTo(px(x), py(y));
                else ctx.lineTo(px(x), py(y));
              });
              ctx.stroke();
            }
            ctx.setLineDash([]);
            ctx.globalAlpha = 1;
            for (const c of CONVOYS) {
              const t = (now / 38000 + (c.id.charCodeAt(4) % 9) * 0.11) % 1;
              const [x, y] = along(c.path, t);
              const active = selected === c.id || hover === c.id;
              ctx.fillStyle = cssVar("--color-caution", "#b89a78");
              ctx.beginPath();
              ctx.arc(px(x), py(y), (active ? 5.5 : 4) * dpr, 0, Math.PI * 2);
              ctx.fill();
              if (active) {
                ctx.font = `${11 * dpr}px "IBM Plex Mono", monospace`;
                ctx.fillStyle = cssVar("--color-fg", "#eceae4");
                ctx.fillText(c.callsign, px(x) + 8 * dpr, py(y) - 8 * dpr);
              }
            }
          }

          for (const s of SENSORS) {
            const meta = KIND_META[s.kind];
            if (meta.overlay && !ov[meta.overlay]) continue;
            const x = px(s.x);
            const y = py(s.y);
            const active = selected === s.id || hover === s.id;
            const r = (active ? 6 : 4.5) * dpr;
            const color =
              s.health === "degraded"
                ? cssVar("--color-caution", "#b89a78")
                : s.health === "offline"
                  ? cssVar("--color-alert", "#c46b5a")
                  : cssVar("--color-accent", "#a8b4c2");
            if (s.health === "nominal" && !reduced) {
              ctx.strokeStyle = color;
              ctx.globalAlpha = 0.25 * pulse;
              ctx.lineWidth = 1 * dpr;
              ctx.beginPath();
              ctx.arc(x, y, r + 6 * dpr * pulse, 0, Math.PI * 2);
              ctx.stroke();
              ctx.globalAlpha = 1;
            }
            ctx.strokeStyle = color;
            ctx.fillStyle = cssVar("--color-bg", "#09090b");
            ctx.lineWidth = 1.5 * dpr;
            drawGlyph(ctx, s.kind, x, y, r);
            if (s.kind !== "mag") {
              ctx.fill();
              ctx.stroke();
            } else {
              ctx.stroke();
            }
            if (active) {
              ctx.font = `${11 * dpr}px "IBM Plex Mono", monospace`;
              ctx.fillStyle = cssVar("--color-fg", "#eceae4");
              ctx.fillText(s.id, x + 9 * dpr, y - 8 * dpr);
            }
          }

          for (const site of SITES) {
            if (site.kind === "hq") continue;
            const x = px(site.x);
            const y = py(site.y);
            ctx.fillStyle = cssVar("--color-muted", "#8a8c91");
            ctx.fillRect(x - 2 * dpr, y - 2 * dpr, 4 * dpr, 4 * dpr);
          }
        }
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const hit = useCallback((clientX: number, clientY: number) => {
    const wrap = wrapRef.current;
    if (!wrap) return null;
    const rect = wrap.getBoundingClientRect();
    const x = (clientX - rect.left) / rect.width;
    const y = (clientY - rect.top) / rect.height;
    const ov = overlaysRef.current;
    const state: { best: { id: string; d: number } | null } = { best: null };
    const consider = (id: string, nx: number, ny: number) => {
      const dx = (nx - x) * rect.width;
      const dy = (ny - y) * rect.height;
      const d = Math.hypot(dx, dy);
      if (d < 22 && (!state.best || d < state.best.d)) state.best = { id, d };
    };
    for (const s of SENSORS) {
      const meta = KIND_META[s.kind];
      if (meta.overlay && !ov[meta.overlay]) continue;
      consider(s.id, s.x, s.y);
    }
    if (ov.logistics) {
      const now = performance.now();
      for (const c of CONVOYS) {
        const t = (now / 38000 + (c.id.charCodeAt(4) % 9) * 0.11) % 1;
        const [cx, cy] = along(c.path, t);
        consider(c.id, cx, cy);
      }
    }
    for (const site of SITES) consider(site.id, site.x, site.y);
    return { hit: state.best, x, y };
  }, []);

  return (
    <div className="flex h-full min-h-96 flex-col overflow-hidden rounded-xl bg-surface shadow-panel">
      <div ref={wrapRef} className="relative min-h-0 flex-1">
        <canvas
          ref={canvasRef}
          className="absolute inset-0 size-full"
          onMouseMove={(e) => {
            const res = hit(e.clientX, e.clientY);
            if (!res) return;
            setHover(res.hit?.id ?? null);
            setCursor(formatCoord(nyToLat(res.y), nxToLon(res.x)));
          }}
          onMouseLeave={() => {
            setHover(null);
            setCursor(null);
          }}
          onClick={(e) => {
            const res = hit(e.clientX, e.clientY);
            setSelected(res?.hit?.id ?? null);
          }}
          style={{ cursor: hoverId ? "pointer" : "crosshair" }}
        />
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between p-3">
          <p className="rounded-sm bg-bg/70 px-2 py-1 font-mono text-xs uppercase tracking-widest text-muted">
            Theater · Lake Mead
          </p>
          <p className="rounded-sm bg-bg/70 px-2 py-1 font-mono text-xs tabular-nums text-muted">
            {cursor ?? "Move across the grid"}
          </p>
        </div>
      </div>
      <div className="flex flex-wrap gap-1 border-t border-line p-2">
        {OVERLAYS.map((o) => (
          <OverlayChip key={o.id} id={o.id} label={o.short} />
        ))}
      </div>
    </div>
  );
}

function OverlayChip({ id, label }: { id: OverlayId; label: string }) {
  const on = useExcalibur((s) => s.overlays[id]);
  const toggle = useExcalibur((s) => s.toggleOverlay);
  return (
    <button
      type="button"
      onClick={() => toggle(id)}
      aria-pressed={on}
      className={cn(
        "h-9 rounded-sm px-2.5 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out",
        on ? "bg-accent text-accent-fg" : "text-muted hover:bg-elevated hover:text-fg",
      )}
    >
      {label}
    </button>
  );
}
