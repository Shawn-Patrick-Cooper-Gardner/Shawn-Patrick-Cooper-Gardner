import { createFileRoute } from "@tanstack/react-router";
import { TheaterMap } from "@/components/theater-map";
import { Inspector } from "@/components/inspector";
import { Metric, Panel } from "@/components/chrome";
import { SENSORS, PHASES } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { poolElevation, sensorLive } from "@/lib/live";
import { formatPct } from "@/lib/format";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const tick = useExcalibur((s) => s.tick);
  const online = SENSORS.filter((s) => s.health === "nominal").length;
  const degraded = SENSORS.filter((s) => s.health === "degraded").length;
  const avgAnom =
    SENSORS.reduce((a, s) => a + sensorLive(s.id, s.health, tick).anomaly, 0) /
    SENSORS.length;
  const phase = PHASES[0];

  return (
    <div className="flex h-full min-h-0 flex-col gap-3 overflow-auto p-3 lg:overflow-hidden">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Panel>
          <Metric label="Array" value={`${online}/${SENSORS.length}`} hint={`${degraded} degraded`} />
        </Panel>
        <Panel>
          <Metric
            label="Mean anomaly"
            value={formatPct(avgAnom, 1)}
            tone={avgAnom > 0.15 ? "caution" : "ok"}
          />
        </Panel>
        <Panel>
          <Metric
            label="Lake Mead pool"
            value={`${poolElevation(tick).toFixed(2)} ft`}
            hint="USBR stage · Boulder Basin"
          />
        </Panel>
        <Panel>
          <Metric
            label={`Phase ${phase.id}`}
            value={formatPct(phase.progress)}
            hint={phase.name}
          />
        </Panel>
      </div>
      <div className="flex min-h-0 flex-1 flex-col gap-3 lg:flex-row">
        <div className="min-h-96 min-w-0 flex-1 lg:min-h-0">
          <TheaterMap />
        </div>
        <div className="shrink-0 lg:w-80 xl:w-96">
          <Inspector />
        </div>
      </div>
    </div>
  );
}
