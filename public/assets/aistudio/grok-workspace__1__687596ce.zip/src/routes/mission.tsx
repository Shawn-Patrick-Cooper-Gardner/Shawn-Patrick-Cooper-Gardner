import { createFileRoute } from "@tanstack/react-router";
import { PHASES } from "@/lib/theater-data";
import { formatPct } from "@/lib/format";
import { Kicker, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Check, Minus } from "lucide-react";

export const Route = createFileRoute("/mission")({ component: MissionPage });

function MissionPage() {
  const overall =
    PHASES.reduce((a, p) => {
      const span = p.id === "I" ? 6 : p.id === "II" ? 8 : 10;
      return a + p.progress * span;
    }, 0) / 24;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6">
      <PageHeader kicker="24-month program" title="Mission phases">
        <div className="text-right">
          <Kicker>Overall</Kicker>
          <p className="mt-1 text-2xl font-medium tabular-nums tracking-tight">
            {formatPct(overall)}
          </p>
        </div>
      </PageHeader>

      <Panel>
        <Kicker>Timeline</Kicker>
        <div className="mt-4 flex h-3 overflow-hidden rounded-sm bg-elevated">
          <div className="bg-accent" style={{ width: `${(6 / 24) * 100}%` }}>
            <div className="h-full bg-fg/40" style={{ width: formatPct(PHASES[0].progress) }} />
          </div>
          <div className="bg-line" style={{ width: `${(8 / 24) * 100}%` }} />
          <div className="bg-elevated" style={{ width: `${(10 / 24) * 100}%` }} />
        </div>
        <div className="mt-2 flex justify-between font-mono text-xs text-muted">
          <span>M1</span>
          <span>M6</span>
          <span>M14</span>
          <span>M24</span>
        </div>
      </Panel>

      <div className="grid gap-4 lg:grid-cols-3">
        {PHASES.map((phase) => (
          <Panel key={phase.id} className="flex flex-col gap-4">
            <div className="flex items-start justify-between gap-2">
              <div>
                <Kicker>
                  Phase {phase.id} · {phase.window}
                </Kicker>
                <h2 className="mt-1 text-lg font-medium tracking-tight">{phase.name}</h2>
              </div>
              <Badge
                tone={
                  phase.status === "active"
                    ? "ok"
                    : phase.status === "complete"
                      ? "ok"
                      : "neutral"
                }
              >
                {phase.status}
              </Badge>
            </div>
            <p className="font-mono text-xs text-muted">{phase.months}</p>
            <div>
              <div className="mb-1 flex justify-between font-mono text-xs text-muted">
                <span>Progress</span>
                <span className="tabular-nums">{formatPct(phase.progress)}</span>
              </div>
              <div className="h-1.5 rounded-sm bg-elevated">
                <div
                  className="h-full rounded-sm bg-accent"
                  style={{ width: formatPct(phase.progress) }}
                />
              </div>
            </div>
            <ul className="space-y-2">
              {phase.objectives.map((o) => (
                <li key={o.id} className="flex items-start gap-2 text-sm">
                  <span
                    className={cn(
                      "mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-sm",
                      o.done ? "bg-ok/20 text-ok" : "bg-elevated text-subtle",
                    )}
                  >
                    {o.done ? <Check className="size-3" /> : <Minus className="size-3" />}
                  </span>
                  <span className={o.done ? "text-fg" : "text-muted"}>{o.text}</span>
                </li>
              ))}
            </ul>
          </Panel>
        ))}
      </div>
    </div>
  );
}
