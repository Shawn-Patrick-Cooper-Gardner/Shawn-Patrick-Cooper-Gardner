import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Bar, BarChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { NIST_FAMILIES } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { auditFeed, identitySessions, provenanceHash } from "@/lib/live";
import { formatPct } from "@/lib/format";
import { Kicker, Metric, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/telemetry")({ component: TelemetryPage });

function TelemetryPage() {
  const tick = useExcalibur((s) => s.tick);
  const [now, setNow] = useState<Date | null>(null);
  useEffect(() => {
    setNow(new Date());
  }, [tick]);

  const aligned = NIST_FAMILIES.reduce((a, f) => a + f.aligned, 0);
  const total = NIST_FAMILIES.reduce((a, f) => a + f.controls, 0);
  const sessions = identitySessions(tick);
  const feed = now ? auditFeed(tick, now) : [];
  const chart = NIST_FAMILIES.map((f) => ({
    id: f.id,
    pct: Number(((f.aligned / f.controls) * 100).toFixed(0)),
  }));

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6">
      <PageHeader kicker="NIST SP 800-171 · SP 800-207" title="Zero-trust telemetry">
        <p className="max-w-md text-sm text-muted">
          Identity, provenance, and control alignment. No CUI or ITAR crosses public
          interfaces. Federated OIDC / OAuth 2.0 at the edge.
        </p>
      </PageHeader>

      <div className="grid gap-3 sm:grid-cols-3">
        <Panel>
          <Metric
            label="800-171 aligned"
            value={`${aligned}/${total}`}
            hint={formatPct(aligned / total)}
            tone="ok"
          />
        </Panel>
        <Panel>
          <Metric label="Provenance root" value={provenanceHash("EDGE-01", tick)} hint="EDGE-01 issuer" />
        </Panel>
        <Panel>
          <Metric
            label="Sessions"
            value={`${sessions.filter((s) => s.status === "active").length} active`}
            hint="OIDC · mTLS · OAuth 2.0"
          />
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel className="lg:col-span-3">
          <Kicker>Control family coverage</Kicker>
          <div className="mt-4 h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} margin={{ top: 4, right: 4, left: -16, bottom: 0 }}>
                <XAxis
                  dataKey="id"
                  tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                  axisLine={{ stroke: "var(--color-line)" }}
                  tickLine={false}
                />
                <YAxis
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  domain={[0, 100]}
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-elevated)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 8,
                    color: "var(--color-fg)",
                    fontSize: 12,
                  }}
                  formatter={(value) => [`${value}%`, "aligned"]}
                />
                <Bar dataKey="pct" fill="var(--color-accent)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel className="lg:col-span-2">
          <Kicker>Identity sessions</Kicker>
          <ul className="mt-3 divide-y divide-line">
            {sessions.map((s) => (
              <li key={s.id} className="flex items-center gap-3 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{s.subject}</p>
                  <p className="font-mono text-xs text-muted">
                    {s.role} · {s.method}
                  </p>
                </div>
                <Badge tone={s.status === "active" ? "ok" : "neutral"}>{s.age}</Badge>
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Panel>
          <Kicker>Audit / provenance</Kicker>
          <ul className="mt-3 space-y-1.5 font-mono text-xs">
            {feed.map((line) => (
              <li key={line.id} className="flex flex-wrap gap-x-3 gap-y-0.5">
                <span className="tabular-nums text-subtle">{line.time}</span>
                <span
                  className={cn(
                    "w-10",
                    line.tone === "ok" && "text-ok",
                    line.tone === "caution" && "text-caution",
                    line.tone === "alert" && "text-alert",
                    line.tone === "neutral" && "text-accent",
                  )}
                >
                  {line.verb}
                </span>
                <span className="text-fg">{line.node}</span>
                <span className="text-muted">{line.detail}</span>
              </li>
            ))}
          </ul>
        </Panel>

        <Panel>
          <Kicker>Family notes</Kicker>
          <ul className="mt-3 divide-y divide-line">
            {NIST_FAMILIES.map((f) => (
              <li key={f.id} className="flex items-baseline gap-3 py-2">
                <span className="w-8 font-mono text-xs text-muted">{f.id}</span>
                <span className="flex-1 text-sm">{f.name}</span>
                <span className="font-mono text-xs tabular-nums text-muted">
                  {f.aligned}/{f.controls}
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      </div>
    </div>
  );
}
