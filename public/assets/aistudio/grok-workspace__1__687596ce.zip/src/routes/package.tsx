import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import {
  CALIBRATION,
  MANIFEST,
  NIST_FAMILIES,
  PROGRAM,
} from "@/lib/theater-data";
import { Kicker, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { Mark } from "@/components/mark";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/package")({ component: PackagePage });

const TABS = [
  { id: "cover", label: "Cover" },
  { id: "abstract", label: "Abstract" },
  { id: "directive", label: "Directive" },
  { id: "compliance", label: "Compliance" },
  { id: "calibration", label: "Calibration" },
  { id: "manifest", label: "Manifest" },
] as const;

type TabId = (typeof TABS)[number]["id"];

function PackagePage() {
  const [tab, setTab] = useState<TabId>("cover");

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6 p-4 sm:p-6">
      <PageHeader kicker="AFWERX CSO · internal binder" title="Submission package">
        <Badge tone="caution">Not yet submitted</Badge>
      </PageHeader>

      <div className="flex gap-1 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => setTab(t.id)}
            className={cn(
              "h-11 shrink-0 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out",
              tab === t.id
                ? "bg-accent text-accent-fg"
                : "bg-surface text-muted shadow-panel hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "cover" ? <Cover /> : null}
      {tab === "abstract" ? <Abstract /> : null}
      {tab === "directive" ? <Directive /> : null}
      {tab === "compliance" ? <Compliance /> : null}
      {tab === "calibration" ? <Calibration /> : null}
      {tab === "manifest" ? <Manifest /> : null}
    </div>
  );
}

function Cover() {
  return (
    <Panel className="p-6 sm:p-10">
      <div className="flex items-start justify-between gap-4">
        <Mark className="size-12" />
        <div className="text-right">
          <Kicker>{PROGRAM.control}</Kicker>
          <p className="mt-1 font-mono text-xs text-alert">{PROGRAM.classification}</p>
        </div>
      </div>
      <p className="mt-10 font-mono text-xs uppercase tracking-widest text-muted">
        {PROGRAM.company}
      </p>
      <h2 className="mt-3 max-w-xl text-3xl font-medium tracking-widest">EXCALIBUR</h2>
      <p className="mt-3 max-w-xl text-muted">{PROGRAM.subtitle}</p>
      <p className="mt-2 font-mono text-xs uppercase tracking-widest text-subtle">
        {PROGRAM.solicitation}
      </p>

      <dl className="mt-10 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
        <Field label="Applicant" value={PROGRAM.legalName} />
        <Field label="Business structure" value="Sole Proprietorship (U.S.)" />
        <Field label="Principal investigator" value={`${PROGRAM.pi}, ${PROGRAM.piTitle}`} />
        <Field label="Email / phone" value={`${PROGRAM.email} · ${PROGRAM.phone}`} />
        <Field label="Operating location" value={PROGRAM.location} />
        <Field label="NAICS" value={`${PROGRAM.naics} — ${PROGRAM.naicsLabel}`} />
        <Field label="Operational nexus" value={PROGRAM.theater} />
        <Field label="UEI / CAGE" value="Internal placeholder — SAM.gov pending" />
      </dl>

      <div className="mt-12 border-t border-line pt-6">
        <Kicker>Signature authority</Kicker>
        <p className="mt-3 text-sm font-medium tracking-wide">{PROGRAM.pi.toUpperCase()}</p>
        <p className="text-sm text-muted">
          Principal Cloud Architect · {PROGRAM.company} · Boulder City, Nevada
        </p>
      </div>
    </Panel>
  );
}

function Abstract() {
  return (
    <Panel className="p-6 sm:p-8">
      <Kicker>Executive summary</Kicker>
      <h2 className="mt-2 text-xl font-medium">Technical abstract</h2>
      <div className="mt-6 space-y-4 text-sm leading-relaxed text-muted">
        <p>
          Project EXCALIBUR is a dual-use research initiative integrating advanced
          terrain sensing, hazardous-material logistics modeling, and zero-trust
          cyber-physical telemetry security. The system is designed for deployment
          in austere, degraded-communication environments and supports defense,
          emergency response, and commercial logistics operations.
        </p>
        <p>
          The Boulder City / Lake Mead theater provides a compact, instrumentable
          baseline: high-relief terrain, critical civil infrastructure at Hoover Dam,
          constrained tanker corridors on US-93 and I-11, and a hydrological body
          whose pool elevation is independently published. Phase I establishes that
          baseline. Later phases fabricate autonomous sensor units, apply edge-AI
          anomaly filters, and demonstrate a common operating picture.
        </p>
      </div>
      <ul className="mt-6 grid gap-3 sm:grid-cols-3">
        {[
          {
            t: "Terrain",
            d: "LiDAR, hyperspectral, GPR, and magnetometry fused against a shared grid.",
          },
          {
            t: "Logistics",
            d: "Subpart H-aligned tanker surge and LCV stability on theater grades.",
          },
          {
            t: "Telemetry",
            d: "NIST SP 800-171 provenance, OIDC identity, no CUI on public interfaces.",
          },
        ].map((p) => (
          <li key={p.t} className="rounded-md bg-elevated p-4">
            <p className="font-medium">{p.t}</p>
            <p className="mt-1 text-sm text-muted">{p.d}</p>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function Directive() {
  return (
    <Panel className="p-6 sm:p-8">
      <Kicker>EXCALIBUR Directive</Kicker>
      <h2 className="mt-2 text-xl font-medium">Internal operating instruction</h2>
      <ol className="mt-6 list-decimal space-y-4 pl-5 text-sm leading-relaxed text-muted">
        <li>
          The Principal Architect is system owner and sole signature authority for
          release of this package. No artifact leaves the binder without that
          authorization.
        </li>
        <li>
          Public interfaces SHALL NOT ingest CUI or ITAR. Telemetry at the edge is
          signed, hashed, and forwarded through EDGE-01 as the provenance root.
        </li>
        <li>
          Identity is federated (OIDC / OAuth 2.0) with mTLS between edge nodes.
          Local accounts are not provisioned on field units.
        </li>
        <li>
          Sensor calibration residuals in this binder are the Phase I baseline.
          GPR-02 remains degraded pending EMI retune at Railroad Pass.
        </li>
        <li>
          Source remains under internal code freeze pending Principal Architect
          approval. This console is a demonstration of the operating picture, not
          a production control system.
        </li>
      </ol>
    </Panel>
  );
}

function Compliance() {
  return (
    <Panel className="overflow-x-auto p-0">
      <div className="p-6 pb-3">
        <Kicker>NIST SP 800-171 Rev 2</Kicker>
        <h2 className="mt-2 text-xl font-medium">Control alignment</h2>
        <p className="mt-2 max-w-xl text-sm text-muted">
          Internal mapping only. Not a CMMC assessment. Zero-trust overlay per
          NIST SP 800-207. Subpart H security plan covers cargo-tank movements.
        </p>
      </div>
      <table className="w-full text-left text-sm">
        <thead className="font-mono text-xs uppercase tracking-widest text-muted">
          <tr className="border-y border-line">
            <th className="px-6 py-2 font-medium">Family</th>
            <th className="px-4 py-2 font-medium">Name</th>
            <th className="px-4 py-2 font-medium">Aligned</th>
            <th className="px-6 py-2 font-medium">Note</th>
          </tr>
        </thead>
        <tbody>
          {NIST_FAMILIES.map((f) => (
            <tr key={f.id} className="border-b border-line">
              <td className="px-6 py-2.5 font-mono text-xs">{f.id}</td>
              <td className="px-4 py-2.5">{f.name}</td>
              <td className="px-4 py-2.5 tabular-nums">
                {f.aligned}/{f.controls}
              </td>
              <td className="px-6 py-2.5 text-muted">{f.note}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

function Calibration() {
  return (
    <Panel className="overflow-x-auto p-0">
      <div className="p-6 pb-3">
        <Kicker>Lake Mead baseline</Kicker>
        <h2 className="mt-2 text-xl font-medium">Instrument calibration</h2>
      </div>
      <table className="w-full text-left text-sm">
        <thead className="font-mono text-xs uppercase tracking-widest text-muted">
          <tr className="border-y border-line">
            <th className="px-6 py-2 font-medium">Instrument</th>
            <th className="px-4 py-2 font-medium">Node</th>
            <th className="px-4 py-2 font-medium">Last</th>
            <th className="px-4 py-2 font-medium">Next</th>
            <th className="px-4 py-2 font-medium">Residual</th>
            <th className="px-6 py-2 font-medium">Standard</th>
          </tr>
        </thead>
        <tbody>
          {CALIBRATION.map((r) => (
            <tr key={`${r.node}-${r.instrument}`} className="border-b border-line">
              <td className="px-6 py-2.5">{r.instrument}</td>
              <td className="px-4 py-2.5 font-mono text-xs">{r.node}</td>
              <td className="px-4 py-2.5 tabular-nums text-muted">{r.last}</td>
              <td className="px-4 py-2.5 tabular-nums text-muted">{r.next}</td>
              <td className="px-4 py-2.5 font-mono text-xs">{r.residual}</td>
              <td className="px-6 py-2.5 text-muted">{r.standard}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </Panel>
  );
}

function Manifest() {
  return (
    <Panel className="p-6 sm:p-8">
      <Kicker>DARPA-PS-26-09_submission.zip</Kicker>
      <h2 className="mt-2 text-xl font-medium">Archive manifest</h2>
      <p className="mt-2 text-sm text-muted">
        All artifacts remain internal until Principal Architect release
        authorization. Checksums are demonstration values.
      </p>
      <ul className="mt-6 divide-y divide-line border-y border-line">
        {MANIFEST.map((m) => (
          <li key={m.file} className="flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:gap-4">
            <span className="font-mono text-sm">{m.file}</span>
            <span className="flex-1 text-sm text-muted">{m.role}</span>
            <span className="font-mono text-xs text-subtle">{m.size}</span>
            <span className="font-mono text-xs text-muted">{m.sha}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt>
        <Kicker>{label}</Kicker>
      </dt>
      <dd className="mt-1">{value}</dd>
    </div>
  );
}
