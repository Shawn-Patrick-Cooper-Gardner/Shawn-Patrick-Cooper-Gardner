import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import { Check, Copy, Download } from "lucide-react";
import { Kicker, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Mark } from "@/components/mark";
import { AUTHORITY, SES_MTQ, sesMarkdown } from "@/lib/authority-data";
import {
  ENGINE,
  ENGINE_BOUNDARY,
  ENGINE_CONTROL,
  ENGINE_LEDGER,
  GENESIS_DIGEST,
  engineHead,
  engineYaml,
} from "@/lib/engine-data";
import { FR_RECORD } from "@/lib/fr-provenance";
import { GEO_CLAIM, MIGRATION_HOLD } from "@/lib/migration-hold";
import { UPLINK_PROFILE } from "@/lib/uplink-profile";
import { PHONE_REGISTRY } from "@/lib/phone-registry";
import { DECK_PASTE } from "@/lib/deck-paste";
import { DESERT_SPEC } from "@/lib/desert-spec";
import { ENGINE_TARGET } from "@/lib/engine-target";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  FPDS_AWARDS,
  FPDS_BOUNDARY,
  FPDS_CONTROL,
  fpdsKnownObligation,
  fpdsMarkdown,
  formatUsd,
  type FpdsAward,
} from "@/lib/fpds-data";
import {
  TIP_CATEGORIES,
  TIPS,
  TIPS_BADGE,
  TIPS_CONTROL,
  type Tip,
  type TipCategory,
  tipsMarkdown,
} from "@/lib/tips-data";
import { copyText, downloadText } from "@/lib/clipboard";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/doctrine")({ component: DoctrinePage });

type Tab = "a56" | "us1" | "phone" | "deck" | "spec" | "tips" | "authority" | "ses" | "fpds" | "engine";

const TABS = [
  { id: "a56", label: "a56" },
  { id: "us1", label: "US-1" },
  { id: "phone", label: "Phone" },
  { id: "deck", label: "Deck" },
  { id: "spec", label: "Spec" },
  { id: "tips", label: "Tips" },
  { id: "authority", label: "Authority" },
  { id: "ses", label: "SES MTQ" },
  { id: "fpds", label: "FPDS" },
  { id: "engine", label: "Engine" },
] as const;

function DoctrinePage() {
  const [tab, setTab] = useState<Tab>("tips");
  const kicker =
    tab === "a56"
      ? "a56-fox · held · not dispatched"
      : tab === "us1"
        ? "US-1 web clip · not installed"
      : tab === "phone"
        ? "Termux folders · local only"
      : tab === "deck"
        ? "Pasted screen · 2026-09-10 · hosts do not resolve"
      : tab === "spec"
        ? "Car 13 build sheet · not an entry"
      : tab === "engine"
      ? `${ENGINE_CONTROL} · v${ENGINE.version}`
      : tab === "fpds"
        ? `${FPDS_CONTROL} · PIID 2026`
        : tab === "ses"
          ? "Undergraduate internship / co-op"
          : tab === "authority"
            ? "Super-stack 2.0 · internal authority"
            : `${TIPS_CONTROL} · 26 active`;

  useEffect(() => {
    if (window.location.hash === "#a56") setTab("a56");
    if (window.location.hash === "#us1") setTab("us1");
    if (window.location.hash === "#phone") setTab("phone");
    if (window.location.hash === "#deck") setTab("deck");
    if (window.location.hash === "#spec") setTab("spec");
  }, []);

  return (
    <div className="mx-auto flex max-w-5xl flex-col gap-6 p-4 sm:p-6 print:max-w-none print:p-0">
      <PageHeader kicker={kicker} title="Doctrine">
        <div className="flex flex-wrap gap-2 print:hidden">
          <Button variant="outline" size="sm" onClick={() => window.print()}>
            Print
          </Button>
        </div>
      </PageHeader>

      <div className="flex gap-1 overflow-x-auto print:hidden">
        {TABS.map((t) => (
          <button
            key={t.id}
            type="button"
            onClick={() => {
              setTab(t.id);
              if (t.id === "a56") window.history.replaceState(null, "", "#a56");
              if (t.id === "us1") window.history.replaceState(null, "", "#us1");
              if (t.id === "phone") window.history.replaceState(null, "", "#phone");
              if (t.id === "deck") window.history.replaceState(null, "", "#deck");
              if (t.id === "spec") window.history.replaceState(null, "", "#spec");
            }}
            className={cn(
              "h-11 shrink-0 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out",
              tab === t.id
                ? "bg-accent text-accent-fg"
                : "bg-surface text-muted shadow-panel hover:text-fg",
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === "a56" ? <HoldPane /> : null}
      {tab === "us1" ? <UplinkPane /> : null}
      {tab === "phone" ? <PhonePane /> : null}
      {tab === "deck" ? <DeckPane /> : null}
      {tab === "spec" ? <SpecPane /> : null}
      {tab === "tips" ? <TipsPane /> : null}
      {tab === "authority" ? <AuthorityPane /> : null}
      {tab === "ses" ? <SesPane /> : null}
      {tab === "fpds" ? <FpdsPane /> : null}
      {tab === "engine" ? <EnginePane /> : null}
    </div>
  );
}

function TipsPane() {
  const [cat, setCat] = useState<TipCategory | "ALL">("ALL");
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<number | null>(1);
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(null);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return TIPS.filter((t) => {
      if (cat !== "ALL" && t.category !== cat) return false;
      if (!needle) return true;
      return `${t.n} ${t.tag} ${t.title} ${t.body} ${t.directive} ${t.ref}`
        .toLowerCase()
        .includes(needle);
    });
  }, [cat, q]);

  async function copy(id: string, text: string) {
    const ok = await copyText(text);
    if (ok) {
      setCopied(id);
      window.setTimeout(() => setCopied((c) => (c === id ? null : c)), 1400);
    }
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="grid gap-3 sm:grid-cols-3 print:hidden">
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">Active</p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{TIPS.length}</p>
        </Panel>
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">Showing</p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{rows.length}</p>
        </Panel>
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">Standard</p>
          <p className="mt-1 text-sm">NIST SP 800-171 · Zero-trust</p>
        </Panel>
      </div>

      <div className="flex flex-col gap-3 print:hidden">
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search tips, directives, references"
          className="h-11 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-panel outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"
        />
        <div className="flex flex-wrap gap-1">
          {TIP_CATEGORIES.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setCat(c.id)}
              aria-pressed={cat === c.id}
              className={cn(
                "h-11 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out",
                cat === c.id
                  ? "bg-accent text-accent-fg"
                  : "bg-surface text-muted shadow-panel hover:text-fg",
              )}
            >
              {c.label}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => downloadText("13ADC-DIR-TIPS-2026.md", tipsMarkdown())}
          >
            <Download className="size-3.5" strokeWidth={1.6} />
            Download .md
          </Button>
          <Button variant="outline" size="sm" onClick={() => copy("md", tipsMarkdown())}>
            {copied === "md" ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            Copy abstract
          </Button>
          <Button variant="outline" size="sm" onClick={() => copy("badge", TIPS_BADGE)}>
            {copied === "badge" ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            Copy badge
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() =>
              downloadText("EXCALIBUR-slide-notes.txt", slideNotes(), "text/plain")
            }
          >
            <Download className="size-3.5" strokeWidth={1.6} />
            PPTX notes
          </Button>
        </div>
      </div>

      {rows.length === 0 ? (
        <Panel>
          <p className="text-sm text-muted">No tips match that filter.</p>
        </Panel>
      ) : (
        <ul className="flex flex-col gap-2">
          {rows.map((t) => (
            <TipCard
              key={t.n}
              tip={t}
              open={open === t.n}
              onToggle={() => setOpen(open === t.n ? null : t.n)}
              copied={copied}
              onCopy={copy}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function TipCard({
  tip,
  open,
  onToggle,
  copied,
  onCopy,
}: {
  tip: Tip;
  open: boolean;
  onToggle: () => void;
  copied: string | null;
  onCopy: (id: string, text: string) => void;
}) {
  const id = `tip-${tip.n}`;
  return (
    <li>
      <Panel className={cn("p-0", open && "shadow-panel-hover")}>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          className="flex w-full items-start gap-3 px-4 py-3 text-left"
        >
          <span className="w-8 shrink-0 font-mono text-xs tabular-nums text-muted">
            {String(tip.n).padStart(2, "0")}
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{tip.title}</span>
              <Badge>{tip.category}</Badge>
            </span>
            <span className="mt-0.5 block font-mono text-xs text-subtle">
              [{tip.tag}] · {tip.ref}
            </span>
          </span>
        </button>
        {open ? (
          <div className="border-t border-line px-4 py-4">
            <p className="text-sm leading-relaxed text-muted">{tip.body}</p>
            <p className="mt-3 rounded-md bg-elevated px-3 py-2 font-mono text-xs text-fg">
              {tip.directive}
            </p>
            <div className="mt-3 print:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onCopy(id, tip.directive)}
              >
                {copied === id ? (
                  <Check className="size-3.5" />
                ) : (
                  <Copy className="size-3.5" />
                )}
                Copy directive
              </Button>
            </div>
          </div>
        ) : null}
      </Panel>
    </li>
  );
}

function slideNotes(): string {
  return TIPS.map(
    (t) =>
      `Slide ${t.n}: ${t.title}\n[${t.tag}] ${t.category}\n- ${t.body}\n- Directive: ${t.directive}\n`,
  ).join("\n");
}

function AuthorityPane() {
  const a = AUTHORITY;
  return (
    <Panel className="p-6 sm:p-10">
      <div className="flex items-start justify-between gap-4">
        <Mark className="size-12" />
        <div className="text-right">
          <Kicker>{a.documentControl}</Kicker>
          <p className="mt-1 font-mono text-xs text-muted">Super-stack {a.superStackVersion}</p>
          <p className="font-mono text-xs text-alert">Internal organizational authority only</p>
        </div>
      </div>
      <h2 className="mt-8 text-2xl font-medium tracking-tight">Authority certificate</h2>
      <p className="mt-2 max-w-xl text-sm text-muted">{a.disclaimer}</p>

      <dl className="mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
        <Field label="Entity" value={a.organization.entityName} />
        <Field label="Type" value={a.organization.entityType} />
        <Field label="Principal architect" value={a.organization.principalArchitect} />
        <Field label="Role" value={a.executive.role} />
        <Field label="Jurisdiction" value={a.organization.jurisdiction} />
        <Field label="Scope" value={a.organization.operationalScope} />
        <Field label="PEC safety" value={a.organization.pecSafety} />
        <Field label="ORCID" value={a.organization.orcid} />
        <Field label="GovInfo tag" value={a.organization.govinfoTag} />
        <Field label="Effective" value={a.effective} />
        <Field label="Identity model" value={a.identity.model} />
        <Field label="License" value={a.license} />
      </dl>

      <div className="mt-10 grid gap-6 sm:grid-cols-2">
        <ListBlock title="Executive mandate" items={a.executive.mandate} />
        <ListBlock title="Technical scope" items={a.technical} />
        <ListBlock title="Governance" items={a.governance} />
        <ListBlock title="Identity requirements" items={a.identity.requirements} />
      </div>
      <div className="mt-6">
        <ListBlock title="Execution constraints" items={a.constraints} />
      </div>
    </Panel>
  );
}

function SesPane() {
  const s = SES_MTQ;
  const [copied, setCopied] = useState(false);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap gap-2 print:hidden">
        <Button
          variant="outline"
          size="sm"
          onClick={() => downloadText("SES_MTQ_Statement.md", sesMarkdown())}
        >
          <Download className="size-3.5" strokeWidth={1.6} />
          Download .md
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            const ok = await copyText(sesMarkdown());
            if (ok) {
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1400);
            }
          }}
        >
          {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          Copy statement
        </Button>
      </div>

      <Panel className="border-l-2 border-l-caution p-6">
        <Kicker>Evidence-control rule</Kicker>
        <p className="mt-2 text-sm leading-relaxed">{s.controlRule}</p>
      </Panel>

      <Panel className="p-6 sm:p-10">
        <Kicker>{s.program}</Kicker>
        <h2 className="mt-2 text-2xl font-medium tracking-tight">{s.title}</h2>
        <p className="mt-1 text-muted">{s.subtitle}</p>

        <dl className="mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
          <Field label="Applicant" value={s.applicant} />
          <Field label="Location" value={s.location} />
          <Field label="Citizenship" value={s.citizenship} />
          <Field label="Target role" value={s.targetRole} />
        </dl>

        <Section title="Objective">{s.objective}</Section>

        <Section title="Relevant experience">
          <ul className="list-disc space-y-2 pl-5">
            {s.experience.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        </Section>

        <Section title="Core skills">{s.skills}</Section>

        <Section title="Education & development">
          <p>{s.education.diploma}</p>
          <p className="mt-2">{s.education.development}</p>
        </Section>

        <Section title="Mission alignment">
          <p className="mb-3 text-muted">
            Applicant-stated design and geospatial skills are potentially relevant to
            documented USGS institutional activities involving:
          </p>
          <ol className="list-decimal space-y-1 pl-5">
            {s.alignment.map((a) => (
              <li key={a}>{a}</li>
            ))}
          </ol>
        </Section>

        <Section title="Particularly relevant USGS context">
          <p className="mb-3 text-muted">
            The supplied inventory is institutional context for alignment analysis. It
            does not confer applicant status.
          </p>
          <ul className="list-disc space-y-2 pl-5">
            {s.usgsContext.map((u) => (
              <li key={u}>{u}</li>
            ))}
          </ul>
        </Section>

        <Section title="Evidence boundary">
          <p className="mb-3">
            USGS agreement material documents institutional relationships. It does{" "}
            <span className="font-medium">not</span> establish that the applicant
            personally has or had:
          </p>
          <ul className="grid gap-1 sm:grid-cols-2">
            {s.evidenceBoundary.map((e) => (
              <li key={e} className="rounded-sm bg-elevated px-3 py-2 text-sm">
                {e}
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Executive Order 13526">{s.eo13526}</Section>

        <Section title="Recommended positioning">
          <p className="font-medium">Mission alignment</p>
          <p className="mt-1 text-muted">{s.positioning.mission}</p>
          <p className="mt-4 font-medium">Internship objective</p>
          <p className="mt-1 text-muted">{s.positioning.objective}</p>
        </Section>

        <Section title="Validation status">
          <dl className="divide-y divide-line border-y border-line">
            {s.validation.map((v) => (
              <div
                key={v.label}
                className="flex flex-col gap-1 py-2.5 sm:flex-row sm:items-baseline sm:gap-6"
              >
                <dt className="w-56 shrink-0 font-mono text-xs uppercase tracking-widest text-muted">
                  {v.label}
                </dt>
                <dd>{v.value}</dd>
              </div>
            ))}
          </dl>
        </Section>
      </Panel>
    </div>
  );
}

function FpdsPane() {
  const [q, setQ] = useState("");
  const [open, setOpen] = useState<string | null>(FPDS_AWARDS[0]?.id ?? null);
  const [copied, setCopied] = useState(false);

  const rows = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return FPDS_AWARDS;
    return FPDS_AWARDS.filter((a) =>
      `${a.vendor} ${a.parent ?? ""} ${a.office} ${a.idv} ${a.psc} ${a.pscLabel} ${a.naics ?? ""} ${a.naicsLabel ?? ""} ${a.place} ${a.country}`
        .toLowerCase()
        .includes(needle),
    );
  }, [q]);

  const known = fpdsKnownObligation();

  return (
    <div className="flex flex-col gap-4">
      <Panel className="border-l-2 border-l-caution p-6">
        <Kicker>{FPDS_BOUNDARY.title}</Kicker>
        <p className="mt-2 text-sm leading-relaxed">{FPDS_BOUNDARY.lead}</p>
        <p className="mt-3 text-sm">This extract does not establish:</p>
        <ul className="mt-2 grid gap-1 sm:grid-cols-2">
          {FPDS_BOUNDARY.notEstablished.map((e) => (
            <li key={e} className="rounded-sm bg-elevated px-3 py-2 text-sm">
              {e}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">{FPDS_BOUNDARY.note}</p>
      </Panel>

      <div className="grid gap-3 sm:grid-cols-3 print:hidden">
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">Rows</p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{FPDS_AWARDS.length}</p>
          <p className="mt-0.5 text-xs text-subtle">All PIID 2026 · FY00–FY04</p>
        </Panel>
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">
            Known obligation
          </p>
          <p className="mt-1 text-2xl font-medium tabular-nums">{formatUsd(known)}</p>
          <p className="mt-0.5 text-xs text-subtle">
            {FPDS_AWARDS.filter((a) => a.obligation != null).length} of {FPDS_AWARDS.length}{" "}
            rows complete
          </p>
        </Panel>
        <Panel>
          <p className="font-mono text-xs uppercase tracking-widest text-muted">
            EXCALIBUR NAICS
          </p>
          <p className="mt-1 text-2xl font-medium tabular-nums">541715</p>
          <p className="mt-0.5 text-xs text-subtle">No match in this extract</p>
        </Panel>
      </div>

      <div className="flex flex-col gap-3 print:hidden">
        <input
          type="search"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search vendor, office, NAICS, place"
          className="h-11 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-panel outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"
        />
        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => downloadText("13ADC-DIR-FPDS-2026-PIID.md", fpdsMarkdown())}
          >
            <Download className="size-3.5" strokeWidth={1.6} />
            Download .md
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              const ok = await copyText(fpdsMarkdown());
              if (ok) {
                setCopied(true);
                window.setTimeout(() => setCopied(false), 1400);
              }
            }}
          >
            {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
            Copy extract
          </Button>
        </div>
      </div>

      {rows.length === 0 ? (
        <Panel>
          <p className="text-sm text-muted">No awards match that filter.</p>
        </Panel>
      ) : (
        <ul className="flex flex-col gap-2">
          {rows.map((a) => (
            <FpdsCard
              key={a.id}
              award={a}
              open={open === a.id}
              onToggle={() => setOpen(open === a.id ? null : a.id)}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function FpdsCard({
  award,
  open,
  onToggle,
}: {
  award: FpdsAward;
  open: boolean;
  onToggle: () => void;
}) {
  return (
    <li>
      <Panel className={cn("p-0", open && "shadow-panel-hover")}>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={open}
          className="flex w-full items-start gap-3 px-4 py-3 text-left"
        >
          <span className="w-16 shrink-0 font-mono text-xs tabular-nums text-muted">
            {award.signed.slice(0, 4)}
          </span>
          <span className="min-w-0 flex-1">
            <span className="flex flex-wrap items-center gap-2">
              <span className="font-medium">{award.vendor}</span>
              <Badge>{award.psc}</Badge>
              {award.incomplete ? <Badge tone="caution">Incomplete</Badge> : null}
            </span>
            <span className="mt-0.5 block font-mono text-xs text-subtle">
              {award.officeId} · {award.idv} · {formatUsd(award.obligation)}
            </span>
          </span>
        </button>
        {open ? (
          <div className="border-t border-line px-4 py-4">
            <dl className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2">
              <Field label="Office" value={`${award.office} (${award.officeId})`} />
              <Field label="Agency" value={award.agency} />
              <Field label="PIID" value={`${award.piid} against ${award.idv}`} />
              <Field label="Award type" value={`${award.awardType} · ${award.type}`} />
              <Field label="Signed" value={award.signed} />
              <Field
                label="Period of performance"
                value={`${award.popStart} → ${award.popEnd}`}
              />
              <Field label="PSC" value={`${award.psc} ${award.pscLabel}`} />
              <Field
                label="NAICS"
                value={
                  award.naics
                    ? `${award.naics} ${award.naicsLabel ?? ""}`.trim()
                    : "Not in extract"
                }
              />
              <Field label="Place" value={`${award.place} (${award.country})`} />
              <Field label="Competition" value={`${award.competed} · ${award.setAside}`} />
              <Field label="UEI" value={award.uei ?? "Not in extract"} />
              <Field label="Parent" value={award.parent ?? "Not in extract"} />
              <Field label="Address" value={award.address} />
              <Field label="Size" value={award.size} />
              <Field label="Action obligation" value={formatUsd(award.obligation)} />
            </dl>
            {award.incomplete ? (
              <p className="mt-3 text-xs text-caution">
                Source paste truncated at vendor address. Obligation and NAICS were not in
                the supplied row.
              </p>
            ) : null}
          </div>
        ) : null}
      </Panel>
    </li>
  );
}

function SpecPane() {
  return (
    <div className="flex flex-col gap-4">
      <CarSpec />
      <EngineSheet />
    </div>
  );
}

function EngineSheet() {
  return (
    <Panel className="border-l-2 border-l-caution p-6">
      <Kicker>{ENGINE_TARGET.id}</Kicker>
      <h2 className="mt-2 text-2xl font-medium tracking-tight">
        Target pull · {ENGINE_TARGET.statedHp} hp / {ENGINE_TARGET.statedTq} lb-ft
      </h2>
      <p className="mt-1 max-w-2xl text-sm text-muted">
        Shaped so the sheet’s two peaks can exist on one curve. Horsepower is torque × rpm ÷ 5252.
        This is not a water-brake recording.
      </p>
      <div className="mt-4 h-64">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={[...ENGINE_TARGET.pulls]} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
            <CartesianGrid stroke="var(--color-line)" strokeDasharray="3 3" />
            <XAxis
              dataKey="rpm"
              tick={{ fill: "var(--color-muted)", fontSize: 12 }}
              axisLine={{ stroke: "var(--color-line)" }}
              tickLine={false}
            />
            <YAxis
              yAxisId="tq"
              tick={{ fill: "var(--color-muted)", fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              domain={[600, 1000]}
            />
            <YAxis
              yAxisId="hp"
              orientation="right"
              tick={{ fill: "var(--color-muted)", fontSize: 12 }}
              axisLine={false}
              tickLine={false}
              domain={[400, 1000]}
            />
            <Tooltip
              contentStyle={{
                background: "var(--color-elevated)",
                border: "1px solid var(--color-line)",
                borderRadius: 8,
                color: "var(--color-fg)",
                fontFamily: "IBM Plex Mono, monospace",
                fontSize: 12,
              }}
            />
            <Line yAxisId="hp" type="monotone" dataKey="hp" name="hp" stroke="var(--color-accent)" strokeWidth={2} dot={false} />
            <Line yAxisId="tq" type="monotone" dataKey="tq" name="lb-ft" stroke="var(--color-caution)" strokeWidth={2} dot={false} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <p className="mt-2 font-mono text-xs text-muted">
        Accent is horsepower. Caution is torque. Peak hp is at 6,200 rpm on this sketch, where torque has already fallen to 796 lb-ft.
      </p>
      <dl className="mt-6 grid gap-3 sm:grid-cols-2">
        {ENGINE_TARGET.log.map(([label, value]) => (
          <div key={label}>
            <dt className="font-mono text-xs uppercase tracking-widest text-muted">{label}</dt>
            <dd className="text-sm">{value}</dd>
          </div>
        ))}
      </dl>
      <ul className="mt-4 space-y-1.5 text-sm text-muted">
        <li>{ENGINE_TARGET.block}. {ENGINE_TARGET.induction}.</li>
        <li>{ENGINE_TARGET.ignition}. {ENGINE_TARGET.exhaust}.</li>
        <li>
          {ENGINE_TARGET.boostPsi} psi, AFR {ENGINE_TARGET.afr}, {ENGINE_TARGET.timing}, {ENGINE_TARGET.fuel}.
        </li>
        <li>{ENGINE_TARGET.gearbox}. {ENGINE_TARGET.axle}.</li>
        <li>{ENGINE_TARGET.rig} Stated engine weight {ENGINE_TARGET.statedWeightLb} lb. The 18 psi line is tire pressure copied onto a dyno rig.</li>
      </ul>
    </Panel>
  );
}

function CarSpec() {
  return (
    <Panel className="border-l-2 border-l-caution p-6">
      <Kicker>{DESERT_SPEC.id}</Kicker>
      <h2 className="mt-2 text-2xl font-medium tracking-tight">
        {DESERT_SPEC.number} {DESERT_SPEC.vehicle}
      </h2>
      <p className="mt-1 text-sm text-muted">
        {DESERT_SPEC.team} · {DESERT_SPEC.crew} · {DESERT_SPEC.livery}
      </p>
      <div className="mt-6 grid gap-6 sm:grid-cols-2">
        <div>
          <h3 className="font-mono text-xs uppercase tracking-widest text-muted">Powertrain</h3>
          <ul className="mt-2 space-y-1.5 text-sm">
            {DESERT_SPEC.power.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
        <div>
          <h3 className="font-mono text-xs uppercase tracking-widest text-muted">Chassis</h3>
          <ul className="mt-2 space-y-1.5 text-sm">
            {DESERT_SPEC.chassis.map((line) => (
              <li key={line}>{line}</li>
            ))}
          </ul>
        </div>
      </div>
      <h3 className="mt-6 font-mono text-xs uppercase tracking-widest text-muted">Named events</h3>
      <ul className="mt-2 space-y-1.5 text-sm">
        {DESERT_SPEC.events.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
      <ul className="mt-4 space-y-1.5 text-sm text-muted">
        {DESERT_SPEC.notes.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
      <h3 className="mt-6 font-mono text-xs uppercase tracking-widest text-muted">Attached pictures</h3>
      <ul className="mt-2 flex flex-col gap-2">
        {DESERT_SPEC.pictures.map((pic) => (
          <li key={pic.file} className="rounded-md bg-elevated px-3 py-2 text-sm">
            <span className="font-medium">{pic.file}</span>
            <span className="mt-0.5 block text-muted">{pic.what}</span>
          </li>
        ))}
      </ul>
    </Panel>
  );
}

function DeckPane() {
  return (
    <Panel className="border-l-2 border-l-alert p-6">
      <Kicker>{DECK_PASTE.id}</Kicker>
      <h2 className="mt-2 text-2xl font-medium tracking-tight">{DECK_PASTE.title}</h2>
      <p className="mt-1 max-w-2xl text-sm text-muted">
        A pasted dashboard. It is not a command link, and nothing on it was executed.
      </p>
      <p className="mt-4 font-mono text-xs text-muted">{DECK_PASTE.dns}</p>
      <ul className="mt-4 space-y-1.5 text-sm">
        {DECK_PASTE.claims.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
    </Panel>
  );
}

function PhonePane() {
  return (
    <Panel className="border-l-2 border-l-caution p-6">
      <Kicker>{PHONE_REGISTRY.id}</Kicker>
      <h2 className="mt-2 text-2xl font-medium tracking-tight">Phone folders</h2>
      <p className="mt-1 max-w-2xl text-sm text-muted">
        The transcript shows local Termux files. A checksum of those files is
        not a SAM.gov, FCC, SEC, or bank record.
      </p>
      <ul className="mt-4 flex flex-col gap-2">
        {PHONE_REGISTRY.present.map((row) => (
          <li key={row.name} className="rounded-md bg-elevated px-3 py-2 text-sm">
            <span className="font-medium">{row.name}</span>
            <span className="mt-0.5 block text-muted">{row.state}</span>
          </li>
        ))}
      </ul>
      <ul className="mt-4 space-y-1.5 text-sm">
        {PHONE_REGISTRY.checks.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
      <ul className="mt-4 space-y-1.5 text-sm text-muted">
        {PHONE_REGISTRY.failures.map((line) => (
          <li key={line}>{line}</li>
        ))}
      </ul>
    </Panel>
  );
}

function UplinkPane() {
  return (
    <Panel className="border-l-2 border-l-caution p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Kicker>{UPLINK_PROFILE.id}</Kicker>
          <h2 className="mt-2 text-2xl font-medium tracking-tight">
            {UPLINK_PROFILE.name}
          </h2>
          <p className="mt-1 text-sm text-muted">
            Unsigned web clip. Not installed. The Drive file says 404.
          </p>
        </div>
        <Badge tone="caution">Not a profile install</Badge>
      </div>
      <ul className="mt-4 space-y-1.5 text-sm">
        {UPLINK_PROFILE.notes.map((note) => (
          <li key={note}>{note}</li>
        ))}
      </ul>
      <dl className="mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
        <Field label="Display name" value={UPLINK_PROFILE.name} />
        <Field label="UUID" value={UPLINK_PROFILE.uuid} />
        <Field label="Clip label" value={UPLINK_PROFILE.clip.label} />
        <Field label="Full screen" value={UPLINK_PROFILE.clip.fullScreen ? "true" : "false"} />
        <Field label="Drive file" value={UPLINK_PROFILE.clip.driveName} />
        <Field label="Drive body" value={UPLINK_PROFILE.clip.driveBody} />
        <Field label="URL" value={UPLINK_PROFILE.clip.url} />
      </dl>
    </Panel>
  );
}

function HoldPane() {
  return (
    <div className="flex flex-col gap-4">
    <Panel className="border-l-2 border-l-alert p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <Kicker>{MIGRATION_HOLD.control}</Kicker>
          <h2 className="mt-2 text-2xl font-medium tracking-tight">a56-fox</h2>
          <p className="mt-1 text-sm text-muted">Held. Not dispatched. Not lost.</p>
        </div>
        <Badge tone="alert">{MIGRATION_HOLD.status}</Badge>
      </div>
      <p className="mt-4 font-mono text-xs text-muted">{MIGRATION_HOLD.url}</p>
      <ul className="mt-4 space-y-1.5 text-sm">
        {MIGRATION_HOLD.holdReasons.map((reason) => (
          <li key={reason}>{reason}</li>
        ))}
      </ul>
      <dl className="mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
        <Field label="Id" value={MIGRATION_HOLD.id} />
        <Field label="Type" value={MIGRATION_HOLD.body.migrationType} />
        <Field label="Source" value={MIGRATION_HOLD.body.source} />
        <Field label="Destination" value={MIGRATION_HOLD.body.destination} />
        <Field label="Project" value={MIGRATION_HOLD.headers.targetProject} />
        <Field label="Vibe code" value={MIGRATION_HOLD.headers.vibeCode} />
        <Field label="Authorization" value={MIGRATION_HOLD.headers.authorization} />
        <Field label="Device" value={MIGRATION_HOLD.body.device.model} />
        <Field label="Serial" value={MIGRATION_HOLD.body.device.serial} />
        <Field label="Claimed protocol" value={MIGRATION_HOLD.body.securityProtocol} />
        <Field
          label="External verification"
          value={MIGRATION_HOLD.body.labels.externalVerification}
        />
        <Field label="Reaffirmed" value={MIGRATION_HOLD.reaffirmed} />
        <Field label="DNS" value={MIGRATION_HOLD.dns} />
        <Field label="AI Studio" value={MIGRATION_HOLD.studio} />
      </dl>
    </Panel>
    <Panel className="p-6">
      <Kicker>{GEO_CLAIM.id}</Kicker>
      <h3 className="mt-2 text-lg font-medium tracking-tight">
        Claimed Termux hash
      </h3>
      <p className="mt-1 text-sm text-muted">{GEO_CLAIM.status}</p>
      <ul className="mt-4 space-y-1.5 text-sm">
        {GEO_CLAIM.notes.map((note) => (
          <li key={note}>{note}</li>
        ))}
      </ul>
      <dl className="mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
        <Field label="Device serial" value={GEO_CLAIM.serial} />
        <Field label="Claimed SHA-256" value={GEO_CLAIM.claimedSha256} />
        <Field label="Target path" value={GEO_CLAIM.path} />
        <Field label="Claimed export" value={GEO_CLAIM.exportPath} />
        <Field label="Claimed plist" value={GEO_CLAIM.plistPath} />
      </dl>
    </Panel>
    </div>
  );
}

function EnginePane() {
  const [copied, setCopied] = useState(false);
  const [open, setOpen] = useState<string | null>(engineHead().id);

  return (
    <div className="flex flex-col gap-4">
      <Panel className="border-l-2 border-l-caution p-6">
        <Kicker>{ENGINE_BOUNDARY.title}</Kicker>
        <p className="mt-2 text-sm leading-relaxed">{ENGINE_BOUNDARY.lead}</p>
        <p className="mt-3 text-sm">This block does not establish:</p>
        <ul className="mt-2 grid gap-1 sm:grid-cols-2">
          {ENGINE_BOUNDARY.notEstablished.map((e) => (
            <li key={e} className="rounded-sm bg-elevated px-3 py-2 text-sm">
              {e}
            </li>
          ))}
        </ul>
        <p className="mt-3 text-sm text-muted">{ENGINE_BOUNDARY.note}</p>
      </Panel>

      <Panel className="p-6 sm:p-10">
        <div className="flex items-start justify-between gap-4">
          <Mark className="size-12" />
          <div className="text-right">
            <Kicker>{ENGINE.id}</Kicker>
            <p className="mt-1 font-mono text-xs text-muted">v{ENGINE.version}</p>
            <p className="font-mono text-xs text-alert">
              {ENGINE.engine.classificationDefault}
            </p>
          </div>
        </div>
        <h2 className="mt-8 text-2xl font-medium tracking-tight">
          Cognitive provenance engine
        </h2>
        <p className="mt-2 max-w-xl text-sm text-muted">{ENGINE.description}</p>

        <dl className="mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
          <Field label="Operator" value={ENGINE.operator.name} />
          <Field label="Role" value={ENGINE.operator.role} />
          <Field label="Workspace" value={ENGINE.operator.workspace} />
          <Field label="Tags" value={ENGINE.operator.identityTags.join(" · ")} />
          <Field label="Mode" value={ENGINE.engine.mode} />
          <Field label="Environment" value={ENGINE.engine.executionEnvironment} />
          <Field label="Persistence" value={ENGINE.engine.persistence} />
          <Field
            label="Determinism / audit"
            value={`${ENGINE.engine.determinism} · ${ENGINE.engine.auditability}`}
          />
        </dl>
      </Panel>

      <div className="grid gap-3 sm:grid-cols-2">
        {ENGINE.dataSources.map((s) => (
          <Panel key={s.name}>
            <Kicker>
              {s.type} · {s.ingestion}
            </Kicker>
            <p className="mt-1 font-medium">{s.name}</p>
            <p className="mt-1 text-sm text-muted">{s.status}</p>
          </Panel>
        ))}
      </div>

      <div className="grid gap-3 sm:grid-cols-2">
        <Panel>
          <ListBlock title="Capability map" items={ENGINE.capabilities} />
        </Panel>
        <Panel>
          <ListBlock title="Execution constraints" items={ENGINE.constraints} />
        </Panel>
      </div>

      <Panel>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <Kicker>Provenance chain · 14 nodes</Kicker>
            <p className="mt-1 text-sm text-muted">
              Completes the truncated structure that ended at actor. Each ledger
              row hashes the prior digest.
            </p>
          </div>
          <p className="font-mono text-xs text-subtle">
            GENESIS {GENESIS_DIGEST} → HEAD {engineHead().digest}
          </p>
        </div>
        <ol className="mt-4 flex flex-wrap gap-2">
          {ENGINE.chain.map((step, i) => (
            <li
              key={step}
              className="flex h-11 items-center rounded-md bg-elevated px-3 font-mono text-xs uppercase tracking-widest"
            >
              <span className="mr-2 text-subtle">{String(i + 1).padStart(2, "0")}</span>
              {step.replaceAll("_", " ")}
            </li>
          ))}
        </ol>
      </Panel>

      <Panel className="p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <Kicker>{FR_RECORD.id}</Kicker>
            <h3 className="mt-2 text-lg font-medium tracking-tight">
              What this record actually is
            </h3>
          </div>
          <Badge tone="caution">Authority redacted</Badge>
        </div>
        <p className="mt-3 max-w-3xl text-sm leading-relaxed text-muted">
          On 29 September 2026 the operator wrote down a retrieval of two public
          Federal Register rules and a planned GovInfo search. The rules are real
          and public. The API key, the authority token, and the signature are not
          in this console. Nothing here is a live federal feed.
        </p>
        <ul className="mt-4 flex flex-col gap-3">
          {FR_RECORD.documents.map((d) => (
            <li key={d.id} className="rounded-md bg-elevated px-4 py-3">
              <p className="font-medium">
                {d.citation} · {d.title}
              </p>
              <p className="mt-1 text-sm text-muted">{d.plain}</p>
              <p className="mt-2 font-mono text-xs text-subtle">
                {d.id} · {d.agency} · {d.check}
              </p>
            </li>
          ))}
        </ul>
        <dl className="mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
          <Field label="Planned search" value={FR_RECORD.plannedQuery.query} />
          <Field label="Search status" value={FR_RECORD.plannedQuery.status} />
          <Field label="Authority label" value={FR_RECORD.authority.label} />
          <Field label="Authority token" value={FR_RECORD.authority.rawValue} />
          <Field label="Vault pointer" value={FR_RECORD.authority.vaultRef} />
          <Field label="Hash note" value={FR_RECORD.authority.hashNote} />
          <Field
            label="Signature"
            value={`${FR_RECORD.signature.algorithm} · ${FR_RECORD.signature.status}`}
          />
          <Field label="Named output" value={FR_RECORD.transformation.output} />
        </dl>
        <ul className="mt-4 space-y-1 text-sm text-muted">
          {FR_RECORD.opsec.map((rule) => (
            <li key={rule}>{rule}</li>
          ))}
        </ul>
      </Panel>

      <div className="flex flex-wrap gap-2 print:hidden">
        <Button
          variant="outline"
          size="sm"
          onClick={() =>
            downloadText("excalibur-core-engine-2026.yaml", engineYaml(), "text/yaml")
          }
        >
          <Download className="size-3.5" strokeWidth={1.6} />
          Download YAML
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={async () => {
            const ok = await copyText(engineYaml());
            if (ok) {
              setCopied(true);
              window.setTimeout(() => setCopied(false), 1400);
            }
          }}
        >
          {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          Copy ledger
        </Button>
      </div>

      <ul className="flex flex-col gap-2">
        {ENGINE_LEDGER.map((row) => {
          const expanded = open === row.id;
          return (
            <li key={row.id}>
              <Panel className={expanded ? "p-0 shadow-panel-hover" : "p-0"}>
                <button
                  type="button"
                  onClick={() => setOpen(expanded ? null : row.id)}
                  aria-expanded={expanded}
                  className="flex w-full items-start gap-3 px-4 py-3 text-left"
                >
                  <span className="w-14 shrink-0 font-mono text-xs tabular-nums text-muted">
                    {row.id}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="font-medium">{row.artifact}</span>
                      <Badge>{row.action}</Badge>
                    </span>
                    <span className="mt-0.5 block font-mono text-xs text-subtle">
                      {row.parentDigest} → {row.digest}
                    </span>
                  </span>
                </button>
                {expanded ? (
                  <dl className="grid gap-x-8 gap-y-3 border-t border-line px-4 py-4 text-sm sm:grid-cols-2">
                    <Field label="Actor" value={row.actor} />
                    <Field label="Role" value={row.role} />
                    <Field label="Action" value={row.action} />
                    <Field label="Source" value={row.source} />
                    <Field label="Ingestion" value={row.ingestion} />
                    <Field label="Capability" value={row.capability} />
                    <Field label="Constraint" value={row.constraint} />
                    <Field label="Timestamp" value={row.timestamp} />
                    <Field label="Parent digest" value={row.parentDigest} />
                    <Field label="Digest" value={row.digest} />
                    <Field label="Classification" value={row.classification} />
                    <Field label="Evidence boundary" value={row.evidenceBoundary} />
                    <Field label="Workspace" value={row.workspace} />
                    <Field label="Artifact" value={row.artifact} />
                  </dl>
                ) : null}
              </Panel>
            </li>
          );
        })}
      </ul>
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt>
        <Kicker>{label}</Kicker>
      </dt>
      <dd className="mt-1">{value}</dd>
    </div>
  );
}

function ListBlock({ title, items }: { title: string; items: readonly string[] }) {
  return (
    <div>
      <Kicker>{title}</Kicker>
      <ul className="mt-2 space-y-1.5 text-sm text-muted">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mt-10">
      <h3 className="text-lg font-medium tracking-tight">{title}</h3>
      <div className="mt-3 text-sm leading-relaxed">{children}</div>
    </section>
  );
}
