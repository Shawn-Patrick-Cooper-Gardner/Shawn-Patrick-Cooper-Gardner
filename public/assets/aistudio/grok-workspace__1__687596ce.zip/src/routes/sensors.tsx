import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { KIND_META, SENSORS, type SensorKind } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { sensorLive, provenanceHash } from "@/lib/live";
import { formatCoord, formatPct } from "@/lib/format";
import { Kicker, Metric, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { StatusDot } from "@/components/status-dot";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/sensors")({ component: SensorsPage });

const FILTERS: { id: "all" | SensorKind; label: string }[] = [
  { id: "all", label: "All" },
  { id: "lidar", label: "LiDAR" },
  { id: "hsi", label: "HSI" },
  { id: "gpr", label: "GPR" },
  { id: "mag", label: "MAG" },
  { id: "hydro", label: "Hydro" },
  { id: "edge", label: "Edge" },
];

function SensorsPage() {
  const [filter, setFilter] = useState<(typeof FILTERS)[number]["id"]>("all");
  const selectedId = useExcalibur((s) => s.selectedId);
  const setSelected = useExcalibur((s) => s.setSelected);
  const tick = useExcalibur((s) => s.tick);

  const rows = useMemo(
    () => (filter === "all" ? SENSORS : SENSORS.filter((s) => s.kind === filter)),
    [filter],
  );
  const selected = SENSORS.find((s) => s.id === selectedId) ?? rows[0];
  const live = selected ? sensorLive(selected.id, selected.health, tick) : null;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6">
      <PageHeader kicker="Multi-sensor array" title="Terrain sensing grid">
        <p className="max-w-sm text-sm text-muted">
          LiDAR, hyperspectral, GPR, and magnetometry over the Lake Mead baseline.
          Edge nodes carry identity and provenance.
        </p>
      </PageHeader>

      <div className="flex flex-wrap gap-1">
        {FILTERS.map((f) => (
          <button
            key={f.id}
            type="button"
            onClick={() => setFilter(f.id)}
            className={cn(
              "h-11 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out",
              filter === f.id
                ? "bg-accent text-accent-fg"
                : "bg-surface text-muted shadow-panel hover:text-fg",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel className="lg:col-span-3 lg:p-2">
          <ul className="divide-y divide-line">
            {rows.map((s) => {
              const l = sensorLive(s.id, s.health, tick);
              const active = selected?.id === s.id;
              return (
                <li key={s.id}>
                  <button
                    type="button"
                    onClick={() => setSelected(s.id)}
                    className={cn(
                      "flex w-full items-center gap-3 px-3 py-3 text-left transition-[background-color] duration-150 ease-out hover:bg-elevated",
                      active && "bg-elevated",
                    )}
                  >
                    <StatusDot health={s.health} pulse />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{s.name}</p>
                      <p className="font-mono text-xs text-muted">
                        {s.id} · {KIND_META[s.kind].label}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-xs tabular-nums text-fg">
                        {formatPct(l.anomaly, 1)}
                      </p>
                      <p className="font-mono text-xs text-subtle">anom</p>
                    </div>
                  </button>
                </li>
              );
            })}
          </ul>
        </Panel>

        {selected && live ? (
          <Panel className="flex flex-col gap-4 lg:col-span-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <Kicker>{KIND_META[selected.kind].label}</Kicker>
                <h2 className="mt-1 text-lg font-medium">{selected.name}</h2>
              </div>
              <Badge
                tone={
                  selected.health === "nominal"
                    ? "ok"
                    : selected.health === "degraded"
                      ? "caution"
                      : "alert"
                }
              >
                {selected.health}
              </Badge>
            </div>
            <p className="text-sm text-muted">{selected.notes}</p>
            <p className="text-sm">{selected.spec}</p>
            <dl className="grid grid-cols-2 gap-3">
              <Metric label="Fix" value={formatCoord(selected.lat, selected.lon)} />
              <Metric label="Elev" value={`${selected.elevM} m`} />
              <Metric label="Packets" value={live.packets.toLocaleString()} />
              <Metric label="SNR" value={`${live.snr.toFixed(1)} dB`} />
              <Metric label="Delay" value={`${live.delayMs.toFixed(0)} ms`} />
              <Metric
                label="Integrity"
                value={formatPct(live.integrity, 1)}
                tone="ok"
              />
            </dl>
            <p className="font-mono text-xs text-subtle">
              prov {provenanceHash(selected.id, tick)} · cal {selected.installed}
            </p>
          </Panel>
        ) : null}
      </div>
    </div>
  );
}
