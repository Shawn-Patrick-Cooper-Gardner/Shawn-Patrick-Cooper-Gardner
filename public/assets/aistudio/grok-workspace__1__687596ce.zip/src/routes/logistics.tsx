import { createFileRoute } from "@tanstack/react-router";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { CONVOYS, lcvAmplification, surgeMargin } from "@/lib/theater-data";
import { useExcalibur } from "@/lib/store";
import { formatPct } from "@/lib/format";
import { Kicker, Metric, PageHeader, Panel } from "@/components/chrome";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/logistics")({ component: LogisticsPage });

function surgeSeries(latG: number) {
  const out = [];
  for (let i = 5; i <= 95; i += 5) {
    const fill = i / 100;
    out.push({
      fill: i,
      margin: Number(surgeMargin(fill, latG).toFixed(3)),
      zero: 0,
    });
  }
  return out;
}

function LogisticsPage() {
  const simLatG = useExcalibur((s) => s.simLatG);
  const simFill = useExcalibur((s) => s.simFill);
  const simSpeed = useExcalibur((s) => s.simSpeed);
  const setSim = useExcalibur((s) => s.setSim);
  const selectedId = useExcalibur((s) => s.selectedId);
  const setSelected = useExcalibur((s) => s.setSelected);
  const data = surgeSeries(simLatG);
  const margin = surgeMargin(simFill, simLatG);
  const amp = lcvAmplification(simSpeed, 1.15);
  const rearG = simLatG * amp;

  return (
    <div className="mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6">
      <PageHeader kicker="49 CFR Subpart H · cargo tank" title="HazMat logistics model">
        <p className="max-w-md text-sm text-muted">
          Tanker surge and LCV rearward amplification for the US-93 / I-11 theater.
          Partial fill is the free-surface case.
        </p>
      </PageHeader>

      <div className="grid gap-3 sm:grid-cols-3">
        <Panel>
          <Metric
            label="Surge margin"
            value={`${margin.toFixed(2)} g`}
            tone={margin < 0.05 ? "alert" : margin < 0.12 ? "caution" : "ok"}
            hint="Rollover threshold 0.42 g"
          />
        </Panel>
        <Panel>
          <Metric
            label="Rearward amp"
            value={`${amp.toFixed(2)}×`}
            hint={`${rearG.toFixed(2)} g at trailer`}
          />
        </Panel>
        <Panel>
          <Metric label="Fill / lateral" value={`${formatPct(simFill)} · ${simLatG.toFixed(2)} g`} />
        </Panel>
      </div>

      <div className="grid gap-4 lg:grid-cols-5">
        <Panel className="lg:col-span-3">
          <Kicker>Stability margin vs fill</Kicker>
          <p className="mt-1 mb-4 text-sm text-muted">
            Worst free-surface near 50% fill. High fill raises CG; empty tanks are stiff.
          </p>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={data} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-line)" strokeDasharray="3 3" />
                <XAxis
                  dataKey="fill"
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={{ stroke: "var(--color-line)" }}
                  tickLine={false}
                  unit="%"
                />
                <YAxis
                  tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                  axisLine={false}
                  tickLine={false}
                  domain={["auto", "auto"]}
                  unit=" g"
                />
                <Tooltip
                  contentStyle={{
                    background: "var(--color-elevated)",
                    border: "1px solid var(--color-line)",
                    borderRadius: 8,
                    color: "var(--color-fg)",
                    fontFamily: "IBM Plex Mono, monospace",
                    fontSize: 12,
                  }}
                  formatter={(value) => [`${Number(value).toFixed(2)} g`, "margin"]}
                  labelFormatter={(label) => `Fill ${label}%`}
                />
                <Line
                  type="monotone"
                  dataKey="margin"
                  stroke="var(--color-accent)"
                  strokeWidth={2}
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="zero"
                  stroke="var(--color-alert)"
                  strokeDasharray="4 4"
                  strokeWidth={1}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel className="flex flex-col gap-5 lg:col-span-2">
          <Kicker>Run parameters</Kicker>
          <label className="block">
            <span className="font-mono text-xs uppercase tracking-widest text-muted">
              Lateral acceleration · {simLatG.toFixed(2)} g
            </span>
            <input
              type="range"
              min={0.05}
              max={0.36}
              step={0.01}
              value={simLatG}
              onChange={(e) => setSim({ simLatG: Number(e.target.value) })}
              className="mt-2 w-full accent-accent"
            />
          </label>
          <label className="block">
            <span className="font-mono text-xs uppercase tracking-widest text-muted">
              Tank fill · {formatPct(simFill)}
            </span>
            <input
              type="range"
              min={0.15}
              max={0.95}
              step={0.01}
              value={simFill}
              onChange={(e) => setSim({ simFill: Number(e.target.value) })}
              className="mt-2 w-full accent-accent"
            />
          </label>
          <label className="block">
            <span className="font-mono text-xs uppercase tracking-widest text-muted">
              LCV speed · {simSpeed} mph
            </span>
            <input
              type="range"
              min={20}
              max={70}
              step={1}
              value={simSpeed}
              onChange={(e) => setSim({ simSpeed: Number(e.target.value) })}
              className="mt-2 w-full accent-accent"
            />
          </label>
          <p className="text-sm text-muted">
            Rocky Mountain Double, 48 ft + 28 ft. Rearward amplification grows with
            speed and articulation on the Hoover grade.
          </p>
        </Panel>
      </div>

      <Panel className="p-0">
        <div className="border-b border-line px-4 py-3">
          <Kicker>Active movements</Kicker>
        </div>
        <ul className="divide-y divide-line">
          {CONVOYS.map((c) => {
            const m = surgeMargin(c.fill, simLatG);
            const active = selectedId === c.id;
            return (
              <li key={c.id}>
                <button
                  type="button"
                  onClick={() => setSelected(c.id)}
                  className={cn(
                    "flex w-full flex-col gap-1 px-4 py-3 text-left transition-[background-color] duration-150 ease-out hover:bg-elevated sm:flex-row sm:items-center sm:gap-4",
                    active && "bg-elevated",
                  )}
                >
                  <span className="w-24 font-medium">{c.callsign}</span>
                  <span className="flex-1 text-sm text-muted">
                    {c.cargo} · {c.un} · {c.tank}
                  </span>
                  <span className="font-mono text-xs tabular-nums text-muted">
                    fill {formatPct(c.fill)}
                  </span>
                  <Badge tone={m < 0.05 ? "alert" : m < 0.12 ? "caution" : "ok"}>
                    {m.toFixed(2)} g
                  </Badge>
                </button>
              </li>
            );
          })}
        </ul>
      </Panel>
    </div>
  );
}
