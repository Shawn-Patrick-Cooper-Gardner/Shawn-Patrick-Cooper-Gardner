export const PROGRAM = {
  title: "PROJECT EXCALIBUR",
  subtitle: "Terrain-Sensing, HazMat Logistics Modeling & Zero-Trust Telemetry",
  control: "EXCALIBUR-AFW-2026-DIR01",
  solicitation: "AFWERX Commercial Solutions Opening (CSO)",
  company: "13 Aerospace Defense Company",
  legalName: "Shawn Patrick Cooper Gardner d/b/a 13 Aerospace Defense Company",
  pi: "Shawn Patrick Cooper Gardner",
  piTitle: "Principal Cloud Architect",
  email: "gardnershawn379@gmail.com",
  phone: "(702) 663-0160",
  location: "803 Clarice Ln, Boulder City, NV 89005",
  naics: "541715",
  naicsLabel: "R&D in Physical, Engineering, Life Sciences",
  theater: "Boulder City Operational Theater / Lake Mead Baseline",
  classification: "INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED",
  status: "INTERNAL",
} as const;

export const BOUNDS = {
  west: -115.08,
  east: -114.28,
  north: 36.28,
  south: 35.9,
} as const;

export type OverlayId =
  | "lidar"
  | "hsi"
  | "gpr"
  | "mag"
  | "hydro"
  | "logistics"
  | "grid";

export const OVERLAYS: { id: OverlayId; label: string; short: string }[] = [
  { id: "lidar", label: "LiDAR point cloud", short: "LiDAR" },
  { id: "hsi", label: "Hyperspectral imaging", short: "HSI" },
  { id: "gpr", label: "Ground-penetrating radar", short: "GPR" },
  { id: "mag", label: "Magnetometry", short: "MAG" },
  { id: "hydro", label: "Hydrological model", short: "HYDRO" },
  { id: "logistics", label: "HazMat logistics", short: "LOG" },
  { id: "grid", label: "Coordinate grid", short: "GRID" },
];

export type SensorKind = "lidar" | "hsi" | "gpr" | "mag" | "hydro" | "edge";
export type Health = "nominal" | "degraded" | "offline";

export interface SensorNode {
  id: string;
  name: string;
  kind: SensorKind;
  x: number;
  y: number;
  lat: number;
  lon: number;
  elevM: number;
  health: Health;
  installed: string;
  spec: string;
  notes: string;
}

export const SENSORS: SensorNode[] = [
  {
    id: "LIDAR-01",
    name: "Hoover Overlook",
    kind: "lidar",
    x: 0.41,
    y: 0.78,
    lat: 36.021,
    lon: -114.741,
    elevM: 412,
    health: "nominal",
    installed: "2026-03-18",
    spec: "905 nm · 128-ch · 300 m",
    notes: "Dam abutment scan, spillway geometry, canyon wall change detection.",
  },
  {
    id: "LIDAR-02",
    name: "River Mountains",
    kind: "lidar",
    x: 0.22,
    y: 0.7,
    lat: 36.048,
    lon: -114.918,
    elevM: 891,
    health: "nominal",
    installed: "2026-03-22",
    spec: "1550 nm · 64-ch · 450 m",
    notes: "High-ground coverage of Boulder City grid and US-93 corridor.",
  },
  {
    id: "HSI-01",
    name: "Boulder Harbor",
    kind: "hsi",
    x: 0.33,
    y: 0.66,
    lat: 36.04,
    lon: -114.802,
    elevM: 372,
    health: "nominal",
    installed: "2026-04-02",
    spec: "400–2500 nm · 224 bands",
    notes: "Shoreline mineral and hydrocarbon film detection.",
  },
  {
    id: "HSI-02",
    name: "Virgin Narrows",
    kind: "hsi",
    x: 0.54,
    y: 0.46,
    lat: 36.118,
    lon: -114.62,
    elevM: 368,
    health: "nominal",
    installed: "2026-04-09",
    spec: "400–2500 nm · 224 bands",
    notes: "Algal and sediment plume tracking between basins.",
  },
  {
    id: "GPR-01",
    name: "US-93 Corridor",
    kind: "gpr",
    x: 0.3,
    y: 0.74,
    lat: 36.012,
    lon: -114.832,
    elevM: 610,
    health: "nominal",
    installed: "2026-03-28",
    spec: "200–900 MHz dual",
    notes: "Subsurface void and utility mapping under the dam approach.",
  },
  {
    id: "GPR-02",
    name: "Railroad Pass",
    kind: "gpr",
    x: 0.14,
    y: 0.62,
    lat: 36.07,
    lon: -114.98,
    elevM: 668,
    health: "degraded",
    installed: "2026-04-11",
    spec: "200–900 MHz dual",
    notes: "EMI from I-11 substations. Filter retune scheduled.",
  },
  {
    id: "MAG-01",
    name: "Black Canyon",
    kind: "mag",
    x: 0.4,
    y: 0.88,
    lat: 35.972,
    lon: -114.748,
    elevM: 290,
    health: "nominal",
    installed: "2026-04-04",
    spec: "Fluxgate + Overhauser",
    notes: "Ferrous anomaly baseline along the river gorge.",
  },
  {
    id: "MAG-02",
    name: "McCullough Range",
    kind: "mag",
    x: 0.08,
    y: 0.52,
    lat: 36.11,
    lon: -115.04,
    elevM: 1124,
    health: "nominal",
    installed: "2026-04-16",
    spec: "Fluxgate + Overhauser",
    notes: "Regional diurnal correction reference.",
  },
  {
    id: "HYDRO-01",
    name: "Boulder Basin Gauge",
    kind: "hydro",
    x: 0.36,
    y: 0.62,
    lat: 36.055,
    lon: -114.78,
    elevM: 367,
    health: "nominal",
    installed: "2026-03-12",
    spec: "ADCP + stage + temp",
    notes: "Lake Mead pool elevation and circulation.",
  },
  {
    id: "HYDRO-02",
    name: "Intake Towers",
    kind: "hydro",
    x: 0.44,
    y: 0.76,
    lat: 36.028,
    lon: -114.725,
    elevM: 355,
    health: "nominal",
    installed: "2026-03-14",
    spec: "ADCP + turbidity",
    notes: "Forebay current shear and sediment load.",
  },
  {
    id: "EDGE-01",
    name: "Clarice Lane HQ",
    kind: "edge",
    x: 0.2,
    y: 0.68,
    lat: 35.9786,
    lon: -114.8391,
    elevM: 765,
    health: "nominal",
    installed: "2026-02-01",
    spec: "Zero-trust edge node",
    notes: "System owner, identity issuer, provenance root.",
  },
  {
    id: "EDGE-02",
    name: "Callville Bay",
    kind: "edge",
    x: 0.46,
    y: 0.5,
    lat: 36.138,
    lon: -114.71,
    elevM: 385,
    health: "nominal",
    installed: "2026-04-20",
    spec: "Zero-trust edge node",
    notes: "Austere-link relay. Store-and-forward when SATCOM drops.",
  },
];

export const KIND_META: Record<
  SensorKind,
  { label: string; overlay: OverlayId | null }
> = {
  lidar: { label: "LiDAR", overlay: "lidar" },
  hsi: { label: "Hyperspectral", overlay: "hsi" },
  gpr: { label: "GPR", overlay: "gpr" },
  mag: { label: "Magnetometry", overlay: "mag" },
  hydro: { label: "Hydrology", overlay: "hydro" },
  edge: { label: "Edge / identity", overlay: null },
};

export interface Site {
  id: string;
  name: string;
  x: number;
  y: number;
  kind: "hq" | "dam" | "staging" | "harbor";
  notes: string;
}

export const SITES: Site[] = [
  {
    id: "SITE-HQ",
    name: "13ADC Clarice Lane",
    x: 0.2,
    y: 0.68,
    kind: "hq",
    notes: "Principal operating location. Identity root of trust.",
  },
  {
    id: "SITE-DAM",
    name: "Hoover Dam",
    x: 0.42,
    y: 0.8,
    kind: "dam",
    notes: "Critical infrastructure adjacency. No CUI ingested at the edge.",
  },
  {
    id: "SITE-YARD",
    name: "Boulder Staging Yard",
    x: 0.24,
    y: 0.72,
    kind: "staging",
    notes: "LCV and cargo-tank marshalling. Subpart H security plan.",
  },
  {
    id: "SITE-HBR",
    name: "Boulder Harbor",
    x: 0.325,
    y: 0.655,
    kind: "harbor",
    notes: "Hydrological baseline pier.",
  },
];

export interface Convoy {
  id: string;
  callsign: string;
  cargo: string;
  un: string;
  tank: string;
  fill: number;
  path: [number, number][];
  notes: string;
}

export const CONVOYS: Convoy[] = [
  {
    id: "CVY-A",
    callsign: "ALPHA",
    cargo: "Diesel fuel",
    un: "UN1202",
    tank: "MC-406",
    fill: 0.62,
    path: [
      [0.12, 0.58],
      [0.18, 0.64],
      [0.24, 0.7],
      [0.3, 0.74],
      [0.38, 0.78],
      [0.42, 0.8],
    ],
    notes: "US-93 northbound to dam service. Partial fill — surge watch.",
  },
  {
    id: "CVY-B",
    callsign: "BRAVO",
    cargo: "Gasoline",
    un: "UN1203",
    tank: "MC-406",
    fill: 0.88,
    path: [
      [0.1, 0.48],
      [0.16, 0.56],
      [0.2, 0.66],
      [0.24, 0.72],
    ],
    notes: "I-11 to Boulder staging. High fill, low free-surface.",
  },
  {
    id: "CVY-C",
    callsign: "CHARLIE",
    cargo: "Propane",
    un: "UN1978",
    tank: "MC-331",
    fill: 0.45,
    path: [
      [0.26, 0.8],
      [0.22, 0.74],
      [0.2, 0.68],
      [0.18, 0.6],
    ],
    notes: "Pressure vessel. LCV Rocky Mountain Double, southbound.",
  },
];

export const ROADS: [number, number][][] = [
  [
    [0.02, 0.46],
    [0.1, 0.52],
    [0.16, 0.6],
    [0.2, 0.66],
    [0.24, 0.72],
    [0.3, 0.75],
    [0.38, 0.78],
    [0.42, 0.8],
  ],
  [
    [0.2, 0.68],
    [0.26, 0.66],
    [0.3, 0.64],
    [0.325, 0.655],
  ],
  [
    [0.325, 0.655],
    [0.38, 0.58],
    [0.46, 0.5],
    [0.58, 0.42],
    [0.7, 0.32],
  ],
  [
    [0.08, 0.72],
    [0.14, 0.7],
    [0.2, 0.68],
    [0.24, 0.66],
  ],
];

export const CITY_BLOCKS: [number, number, number, number][] = [
  [0.17, 0.64, 0.07, 0.08],
  [0.19, 0.7, 0.05, 0.05],
  [0.15, 0.66, 0.04, 0.04],
];

export const LAKE_POLY: [number, number][] = [
  [0.42, 0.8],
  [0.4, 0.88],
  [0.385, 0.97],
  [0.41, 0.97],
  [0.445, 0.86],
  [0.45, 0.8],
  [0.48, 0.72],
  [0.54, 0.6],
  [0.62, 0.52],
  [0.78, 0.48],
  [0.9, 0.45],
  [0.97, 0.43],
  [0.98, 0.48],
  [0.9, 0.5],
  [0.78, 0.53],
  [0.68, 0.5],
  [0.6, 0.44],
  [0.58, 0.34],
  [0.62, 0.22],
  [0.66, 0.1],
  [0.64, 0.05],
  [0.7, 0.05],
  [0.72, 0.12],
  [0.7, 0.24],
  [0.74, 0.32],
  [0.84, 0.36],
  [0.86, 0.42],
  [0.72, 0.44],
  [0.6, 0.4],
  [0.52, 0.46],
  [0.46, 0.56],
  [0.4, 0.64],
  [0.32, 0.62],
  [0.28, 0.66],
  [0.3, 0.74],
  [0.36, 0.78],
  [0.42, 0.8],
];

export interface Phase {
  id: string;
  name: string;
  window: string;
  months: string;
  progress: number;
  status: "active" | "planned" | "complete";
  objectives: { id: string; text: string; done: boolean }[];
}

export const PHASES: Phase[] = [
  {
    id: "I",
    name: "Feasibility & Baseline Mapping",
    window: "Months 1–6",
    months: "Apr–Sep 2026",
    progress: 0.38,
    status: "active",
    objectives: [
      { id: "i1", text: "Lake Mead hydrological baseline (pool, shear, sediment)", done: true },
      { id: "i2", text: "Multi-sensor terrain grid over Boulder City theater", done: true },
      { id: "i3", text: "Zero-trust telemetry provenance on EDGE-01", done: true },
      { id: "i4", text: "Subpart H tanker surge model, MC-406 family", done: false },
      { id: "i5", text: "NIST SP 800-171 control mapping (14 families)", done: false },
      { id: "i6", text: "Degraded-comms store-and-forward rehearsal", done: false },
    ],
  },
  {
    id: "II",
    name: "Prototype Fabrication & Field Testing",
    window: "Months 7–14",
    months: "Oct 2026–May 2027",
    progress: 0,
    status: "planned",
    objectives: [
      { id: "ii1", text: "Autonomous sensor units, edge-AI anomaly filter", done: false },
      { id: "ii2", text: "Rough-terrain LCV stability on US-93 grades", done: false },
      { id: "ii3", text: "GPR retune and Railroad Pass EMI mitigation", done: false },
      { id: "ii4", text: "Cross-sensor fusion against MAG ferrous baseline", done: false },
    ],
  },
  {
    id: "III",
    name: "Defense Integration & Operational Demonstration",
    window: "Months 15–24",
    months: "Jun 2027–Mar 2028",
    progress: 0,
    status: "planned",
    objectives: [
      { id: "iii1", text: "Common operating picture integration", done: false },
      { id: "iii2", text: "Anomaly tracking exercise with civil partners", done: false },
      { id: "iii3", text: "Manufacturing blueprint and dual-use transition", done: false },
    ],
  },
];

export interface NistFamily {
  id: string;
  name: string;
  aligned: number;
  controls: number;
  note: string;
}

export const NIST_FAMILIES: NistFamily[] = [
  { id: "3.1", name: "Access Control", aligned: 18, controls: 22, note: "Least privilege on edge nodes" },
  { id: "3.2", name: "Awareness & Training", aligned: 3, controls: 3, note: "Internal PI-led briefings" },
  { id: "3.3", name: "Audit & Accountability", aligned: 8, controls: 9, note: "Provenance log complete" },
  { id: "3.4", name: "Configuration Management", aligned: 6, controls: 9, note: "Code freeze pending PA" },
  { id: "3.5", name: "Identification & Authentication", aligned: 9, controls: 11, note: "OIDC / OAuth 2.0" },
  { id: "3.6", name: "Incident Response", aligned: 2, controls: 3, note: "Playbook in draft" },
  { id: "3.7", name: "Maintenance", aligned: 3, controls: 6, note: "Field cal cycle defined" },
  { id: "3.8", name: "Media Protection", aligned: 4, controls: 9, note: "No CUI on public interfaces" },
  { id: "3.9", name: "Personnel Security", aligned: 2, controls: 2, note: "Sole-prop screening" },
  { id: "3.10", name: "Physical Protection", aligned: 4, controls: 6, note: "Clarice Lane controlled" },
  { id: "3.11", name: "Risk Assessment", aligned: 2, controls: 3, note: "Theater risk register live" },
  { id: "3.12", name: "Security Assessment", aligned: 2, controls: 4, note: "Internal only" },
  { id: "3.13", name: "System & Comms Protection", aligned: 11, controls: 16, note: "Zero-trust overlay" },
  { id: "3.14", name: "System & Info Integrity", aligned: 5, controls: 7, note: "Signed telemetry" },
];

export interface CalibrationRow {
  instrument: string;
  node: string;
  last: string;
  next: string;
  residual: string;
  standard: string;
}

export const CALIBRATION: CalibrationRow[] = [
  { instrument: "LiDAR IMU bias", node: "LIDAR-01", last: "2026-09-12", next: "2026-12-12", residual: "0.04°", standard: "NIST-traceable tilt" },
  { instrument: "LiDAR range", node: "LIDAR-02", last: "2026-09-12", next: "2026-12-12", residual: "8 mm @ 100 m", standard: "EDM pillar" },
  { instrument: "HSI radiometric", node: "HSI-01", last: "2026-08-28", next: "2026-11-28", residual: "1.8% refl.", standard: "Spectralon panel" },
  { instrument: "HSI wavelength", node: "HSI-02", last: "2026-08-28", next: "2026-11-28", residual: "1.1 nm", standard: "HgAr lamp" },
  { instrument: "GPR dielectric", node: "GPR-01", last: "2026-09-04", next: "2026-12-04", residual: "εr ±0.3", standard: "Known sand pit" },
  { instrument: "GPR timing", node: "GPR-02", last: "2026-09-04", next: "2026-10-04", residual: "0.6 ns", standard: "Air-launch target" },
  { instrument: "Mag diurnal", node: "MAG-02", last: "2026-09-20", next: "2026-10-20", residual: "3 nT", standard: "Overhauser base" },
  { instrument: "Mag heading", node: "MAG-01", last: "2026-09-20", next: "2026-12-20", residual: "0.2°", standard: "Declination mark" },
  { instrument: "ADCP velocity", node: "HYDRO-01", last: "2026-09-01", next: "2026-12-01", residual: "1.2 cm/s", standard: "Tow-tank transfer" },
  { instrument: "Stage datum", node: "HYDRO-02", last: "2026-07-15", next: "2027-01-15", residual: "6 mm", standard: "USBR BM" },
];

export const MANIFEST = [
  { file: "EXCALIBUR_Directive.pdf", sha: "7c91e2a4b0f6d18c", size: "184 KB", role: "Program directive" },
  { file: "Technical_Abstract.pdf", sha: "12ab90c3e5d44701", size: "96 KB", role: "CSO abstract" },
  { file: "Authority_Certificate.pdf", sha: "9d44f0aa17ce62b8", size: "41 KB", role: "Signature authority" },
  { file: "Compliance_Matrix.xlsx", sha: "c3e018f59aa21d07", size: "128 KB", role: "NIST 800-171 / Subpart H" },
  { file: "Calibration_Data.csv", sha: "55b1d0e9c4a83f12", size: "22 KB", role: "Instrument residuals" },
  { file: "package_excalibur.sh", sha: "e08c77b2d1a94f30", size: "4 KB", role: "Archive script" },
  { file: "ZIP_MANIFEST.txt", sha: "a1c2d3e4f5061728", size: "2 KB", role: "This index" },
];

export const AUDIT_VERBS = [
  "PROV",
  "AUTH",
  "FRAME",
  "ANOM",
  "ROUTE",
  "CAL",
  "SYNC",
  "DENY",
] as const;

export function nxToLon(x: number): number {
  return BOUNDS.west + x * (BOUNDS.east - BOUNDS.west);
}

export function nyToLat(y: number): number {
  return BOUNDS.north + y * (BOUNDS.south - BOUNDS.north);
}

export function surgeMargin(fill: number, latG: number): number {
  const slosh = Math.sin(Math.PI * fill);
  const cgRise = Math.max(0, fill - 0.55) * 0.45;
  const sloshPenalty = slosh * 0.38 * latG;
  const threshold = 0.42;
  return threshold - latG - sloshPenalty - cgRise * latG;
}

export function lcvAmplification(speedMph: number, articulation: number): number {
  return 1 + (speedMph / 65) * 0.35 + articulation * 0.55;
}

export type EntityKind = "sensor" | "convoy" | "site";

export function lookupEntity(id: string): { kind: EntityKind; id: string } | null {
  if (SENSORS.some((s) => s.id === id)) return { kind: "sensor", id };
  if (CONVOYS.some((c) => c.id === id)) return { kind: "convoy", id };
  if (SITES.some((s) => s.id === id)) return { kind: "site", id };
  return null;
}
