import { AUDIT_VERBS, CONVOYS, SENSORS, type Health } from "./theater-data";
import { formatZulu, hashString, seededUnit } from "./format";

export function sensorLive(id: string, health: Health, tick: number) {
  const u = seededUnit(id, tick, 1);
  const u2 = seededUnit(id, tick, 7);
  const u3 = seededUnit(id, tick, 13);
  const baseAnom = health === "degraded" ? 0.24 : health === "offline" ? 0.61 : 0.035;
  return {
    packets: 8_400 + Math.floor(u * 9_200),
    anomaly: Math.max(0, Math.min(1, baseAnom + (u2 - 0.5) * 0.07)),
    snr: 14 + u3 * 12,
    delayMs: health === "degraded" ? 48 + u * 70 : 8 + u * 22,
    integrity: health === "offline" ? 0 : 0.97 + (u - 0.5) * 0.03,
  };
}

export function poolElevation(tick: number): number {
  return 1065.4 + seededUnit("pool", tick, 2) * 0.35;
}

export function provenanceHash(id: string, tick: number): string {
  const h = hashString(`${id}:${Math.floor(tick / 3)}`);
  return h.toString(16).padStart(8, "0");
}

export interface AuditLine {
  id: string;
  time: string;
  verb: string;
  node: string;
  detail: string;
  tone: "ok" | "caution" | "alert" | "neutral";
}

export function auditFeed(tick: number, now: Date, count = 11): AuditLine[] {
  const lines: AuditLine[] = [];
  for (let i = 0; i < count; i++) {
    const t = tick + 64 - i;
    const h = hashString(`audit:${t}`);
    const node = SENSORS[h % SENSORS.length];
    const verb = AUDIT_VERBS[h % AUDIT_VERBS.length];
    const d = new Date(now.getTime() - i * 1400);
    let detail = `sig=${provenanceHash(node.id, t).slice(0, 6)}`;
    let tone: AuditLine["tone"] = "neutral";
    if (verb === "ANOM") {
      detail = `score=${(0.04 + (h % 18) / 100).toFixed(2)}`;
      tone = node.health === "degraded" ? "caution" : "ok";
    } else if (verb === "DENY") {
      detail = "policy=OIDC.session";
      tone = "alert";
    } else if (verb === "AUTH") {
      detail = "oidc=ok  mfa=internal";
      tone = "ok";
    } else if (verb === "FRAME") {
      detail = `pts=${(120000 + (h % 80000)).toString()}`;
    } else if (verb === "ROUTE") {
      const c = CONVOYS[h % CONVOYS.length];
      detail = `${c.callsign}  ${c.un}`;
    } else if (verb === "PROV") {
      detail = `root=${provenanceHash("EDGE-01", t).slice(0, 6)}`;
      tone = "ok";
    }
    lines.push({
      id: `audit-${i}-${t}-${h}`,
      time: formatZulu(d),
      verb,
      node: node.id,
      detail,
      tone,
    });
  }
  return lines;
}

export function identitySessions(tick: number) {
  return [
    {
      id: "pi-root",
      subject: "gardner.s",
      role: "Principal Architect",
      method: "OIDC",
      age: `${12 + (tick % 40)}m`,
      status: "active" as const,
    },
    {
      id: "edge-01",
      subject: "EDGE-01",
      role: "Issuer",
      method: "mTLS",
      age: "bound",
      status: "active" as const,
    },
    {
      id: "edge-02",
      subject: "EDGE-02",
      role: "Relay",
      method: "mTLS",
      age: `${(tick % 7) + 1} hops`,
      status: "active" as const,
    },
    {
      id: "field-svc",
      subject: "field.cal",
      role: "Calibration",
      method: "OAuth 2.0",
      age: "standby",
      status: "idle" as const,
    },
  ];
}
