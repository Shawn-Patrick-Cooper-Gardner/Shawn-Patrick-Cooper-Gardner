import { create } from "zustand";
import type { OverlayId } from "./theater-data";

export const DEFAULT_OVERLAYS: Record<OverlayId, boolean> = {
  lidar: true,
  hsi: true,
  gpr: true,
  mag: true,
  hydro: true,
  logistics: true,
  grid: true,
};

interface ExcaliburState {
  overlays: Record<OverlayId, boolean>;
  selectedId: string | null;
  tick: number;
  hoverId: string | null;
  simLatG: number;
  simFill: number;
  simSpeed: number;
  toggleOverlay: (id: OverlayId) => void;
  setSelected: (id: string | null) => void;
  setHover: (id: string | null) => void;
  bumpTick: () => void;
  setSim: (partial: Partial<Pick<ExcaliburState, "simLatG" | "simFill" | "simSpeed">>) => void;
}

export const useExcalibur = create<ExcaliburState>((set) => ({
  overlays: { ...DEFAULT_OVERLAYS },
  selectedId: "EDGE-01",
  tick: 0,
  hoverId: null,
  simLatG: 0.18,
  simFill: 0.62,
  simSpeed: 48,
  toggleOverlay: (id) =>
    set((s) => ({ overlays: { ...s.overlays, [id]: !s.overlays[id] } })),
  setSelected: (id) => set({ selectedId: id }),
  setHover: (id) => set({ hoverId: id }),
  bumpTick: () => set((s) => ({ tick: s.tick + 1 })),
  setSim: (partial) => set(partial),
}));
