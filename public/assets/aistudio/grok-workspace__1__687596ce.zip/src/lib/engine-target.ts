/**
 * Target curve shaped so the sheet's two peaks can sit on one pull.
 * Horsepower is torque × rpm / 5252. Nothing here was measured.
 */
export const ENGINE_TARGET = {
  id: "core-13-engine-target-2026",
  title: "C.O.R.E. Blown V8",
  block: "468 cu. in. Dart Iron Eagle",
  induction: "8-71 Roots, dual 850 CFM Holley, progressive linkage",
  ignition: "Mallory Super-Mag IV, mechanical tach drive",
  exhaust: "Ceramic-wrapped 2.25 in. primary zoomies",
  statedHp: 940,
  statedTq: 868,
  boostPsi: 12,
  afr: "12.5:1",
  timing: "34° BTC",
  fuel: "110 octane",
  gearbox: "Jerico 4-speed dog box, Tilton triple-disc",
  axle: "Winters quick-change",
  rig: "Sheet says a water-brake absorber and a mounting cradle. No brake model or calibration date.",
  statedWeightLb: 780,
  pulls: [
    { rpm: 3500, tq: 700, hp: 466 },
    { rpm: 4000, tq: 780, hp: 594 },
    { rpm: 4500, tq: 840, hp: 720 },
    { rpm: 5000, tq: 868, hp: 826 },
    { rpm: 5400, tq: 850, hp: 874 },
    { rpm: 5800, tq: 820, hp: 905 },
    { rpm: 6200, tq: 796, hp: 940 },
    { rpm: 6600, tq: 740, hp: 930 },
    { rpm: 7000, tq: 680, hp: 906 },
  ],
  log: [
    ["Engine serial", "Blank"],
    ["Dyno", "Not named"],
    ["Brake calibration", "Not dated"],
    ["Correction factor", "Not stated"],
    ["Pull date", "None"],
    ["Operator of record", "None"],
    ["Witness", "None"],
    ["Barometer / vapor", "Not recorded"],
    ["Status", "Target sheet. Not a measured pull."],
  ],
} as const;
