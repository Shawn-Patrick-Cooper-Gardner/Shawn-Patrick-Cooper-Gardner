export function formatZulu(date: Date): string {
  return `${date.toISOString().slice(11, 19)}Z`;
}

export function formatZuluDate(date: Date): string {
  return date.toISOString().replace("T", " ").replace(/\.\d+Z$/, "Z");
}

export function formatCoord(lat: number, lon: number): string {
  const ns = lat >= 0 ? "N" : "S";
  const ew = lon >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(4)}°${ns}  ${Math.abs(lon).toFixed(4)}°${ew}`;
}

export function formatInt(n: number): string {
  return new Intl.NumberFormat("en-US").format(Math.round(n));
}

export function formatPct(n: number, digits = 0): string {
  return `${(n * 100).toFixed(digits)}%`;
}

export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function seededUnit(id: string, tick: number, salt = 0): number {
  const h = hashString(`${id}:${salt}`);
  const phase = (h % 3600) / 3600;
  const v = Math.sin((tick * 0.11 + phase) * Math.PI * 2) * 0.5 + 0.5;
  return v;
}
