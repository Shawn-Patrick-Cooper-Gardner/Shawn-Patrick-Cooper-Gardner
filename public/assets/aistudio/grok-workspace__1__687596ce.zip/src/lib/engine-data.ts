import { hashString } from "@/lib/format";
import { tipsMarkdown } from "@/lib/tips-data";
import { sesMarkdown } from "@/lib/authority-data";
import { fpdsMarkdown } from "@/lib/fpds-data";

export const ENGINE_CONTROL = "excalibur-core-engine-2026";
export const GENESIS_DIGEST = "00000000";

export const ENGINE = {
  id: "excalibur-core-engine-2026",
  version: "1.1",
  description:
    "Unified cognitive-provenance engine operating entirely within this EXCALIBUR console. Provides deterministic lineage, audit-ready structure, and PRE-DECISIONAL analysis for regulatory ingestion, provenance chaining, capability mapping, and operational logging.",
  operator: {
    name: "Shawn Patrick Cooper Gardner",
    role: "Principal Cloud Architect, 13 Aerospace Defense Company",
    workspace: "EXCALIBUR Cognitive Environment",
    identityTags: ["SPCG", "EXCALIBUR-Operator-1"],
  },
  engine: {
    mode: "cognitive-provenance",
    executionEnvironment: "Grok",
    persistence: "YAML-ledger",
    determinism: "strict",
    auditability: "full",
    classificationDefault: "PRE-DECISIONAL / INTERNAL TECHNICAL ANALYSIS",
  },
  dataSources: [
    {
      name: "GovInfo API",
      type: "public",
      ingestion: "textual",
      status: "Citations public · API not wired",
    },
    {
      name: "FederalRegister.gov",
      type: "public",
      ingestion: "textual",
      status: "Two 2026-09-29 citations checked · feed not wired",
    },
    {
      name: "GitHub Thread Metadata",
      type: "user-generated",
      ingestion: "structured",
      status: "Declared — not wired",
    },
    {
      name: "Grok Reasoning Layer",
      type: "LLM",
      ingestion: "semantic",
      status: "This console",
    },
  ],
  /** Completes the truncated `provenance_chain.structure` that ended at `actor`. */
  chain: [
    "actor",
    "role",
    "action",
    "source",
    "ingestion",
    "artifact",
    "capability",
    "constraint",
    "timestamp",
    "digest",
    "parent_digest",
    "classification",
    "evidence_boundary",
    "workspace",
  ],
  capabilities: [
    "Terrain-sensing COP (Lake Mead / Boulder City theater)",
    "HazMat tanker surge and LCV stability modeling",
    "Zero-trust telemetry visualization (NIST SP 800-171 aligned)",
    "AFWERX CSO internal binder (PRE-DECISIONAL)",
    "YAML provenance ledger with parent-digest chaining",
  ],
  constraints: [
    "No elevation beyond defined IAM roles",
    "No public unauthenticated access",
    "No bypass of logging or provenance controls",
    "No CUI / ITAR on public interfaces",
    "No conversion of applicant claims into federal status",
  ],
  license: "CC BY 4.0",
} as const;

export const ENGINE_BOUNDARY = {
  title: "Evidence-control rule",
  lead: "This metadata block describes an internal cognitive-provenance schema for EXCALIBUR. It does not create a federal system of record, a live GovInfo or Federal Register feed, or classification authority.",
  notEstablished: [
    "a government information system",
    "live GovInfo / Federal Register ingestion",
    "classification or declassification authority",
    "an official audit log admissible as federal evidence",
    "operator clearance, appointment, or agency affiliation",
  ],
  note: "Declared sources remain declared until independently connected and verified. Digests fingerprint local console artifacts and chain to the prior digest. They are not a federal hash authority.",
} as const;

export interface LedgerRow {
  id: string;
  actor: string;
  role: string;
  action: string;
  source: string;
  ingestion: string;
  artifact: string;
  capability: string;
  constraint: string;
  timestamp: string;
  digest: string;
  parentDigest: string;
  classification: string;
  evidenceBoundary: string;
  workspace: string;
}

function digestOf(text: string): string {
  return hashString(text).toString(16).padStart(8, "0");
}

const ACTOR = "SPCG / EXCALIBUR-Operator-1";
const ROLE = ENGINE.operator.role;
const WORKSPACE = ENGINE.operator.workspace;
const BOUNDARY = "Applicant-stated / local console only";
const CLASS = "PRE-DECISIONAL";

type Seed = {
  id: string;
  action: string;
  source: string;
  ingestion: string;
  artifact: string;
  capability: string;
  constraint: string;
  timestamp: string;
  payload: string;
};

const SEEDS: Seed[] = [
  {
    id: "LED-000",
    action: "Genesis",
    source: "Engine schema",
    ingestion: "structured",
    artifact: "Chain genesis · parent 00000000",
    capability: "Deterministic lineage",
    constraint: ENGINE.constraints[2],
    timestamp: "2026-08-14T22:38:00Z",
    payload: `${ENGINE.id}|${ENGINE.version}|genesis`,
  },
  {
    id: "LED-001",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "13ADC-DIR-TIPS-2026 · 26 tips",
    capability: ENGINE.capabilities[3],
    constraint: ENGINE.constraints[3],
    timestamp: "2026-10-01T12:00:00Z",
    payload: tipsMarkdown(),
  },
  {
    id: "LED-002",
    action: "Attest",
    source: "Operator paste",
    ingestion: "structured",
    artifact: "Super-stack 2.0 authority certificate",
    capability: "Identity governance (internal)",
    constraint: ENGINE.constraints[0],
    timestamp: "2026-10-01T12:05:00Z",
    payload: "EXCALIBUR-AFW-2026-DIR01|super-stack-2.0",
  },
  {
    id: "LED-003",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "SES MTQ · Designer / Cartographer internship",
    capability: "Cartographic / geospatial alignment (applicant-stated)",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-01T12:10:00Z",
    payload: sesMarkdown(),
  },
  {
    id: "LED-004",
    action: "Ingest",
    source: "FPDS-NG extract",
    ingestion: "structured",
    artifact: "Navy DO PIID 2026 · 6 rows (1 truncated)",
    capability: "Public-award research extract",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-01T12:20:00Z",
    payload: fpdsMarkdown(),
  },
  {
    id: "LED-005",
    action: "Lockup",
    source: "Brand pass",
    ingestion: "semantic",
    artifact: "13 geometric mark · Lake Mead share card",
    capability: "Visual identity",
    constraint: ENGINE.constraints[3],
    timestamp: "2026-10-06T18:10:00Z",
    payload: "13ADC-lockup|EXCALIBUR|09090B",
  },
  {
    id: "LED-006",
    action: "Declare",
    source: "Operator paste",
    ingestion: "structured",
    artifact: "excalibur-core-engine-2026 metadata block v1.0 (truncated at actor)",
    capability: ENGINE.capabilities[4],
    constraint: ENGINE.constraints[2],
    timestamp: "2026-10-06T18:16:00Z",
    payload: `${ENGINE.id}|1.0|cognitive-provenance|actor`,
  },
  {
    id: "LED-007",
    action: "Extend",
    source: "Operator directive",
    ingestion: "structured",
    artifact: "Provenance chain completed · 14-node structure + parent digest",
    capability: ENGINE.capabilities[4],
    constraint: ENGINE.constraints[2],
    timestamp: "2026-10-06T18:39:00Z",
    payload: ENGINE.chain.join("|"),
  },
  {
    id: "LED-008",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "excalibur-govinfo-fr-2026-09-29 · two FR citations, authority redacted",
    capability: "Regulatory lineage (public citations only)",
    constraint: ENGINE.constraints[3],
    timestamp: "2026-10-08T01:44:00Z",
    payload: "excalibur-govinfo-fr-2026-09-29|2026-19929|2026-19884|REDACTED",
  },
  {
    id: "LED-009",
    action: "Hold",
    source: "Operator paste",
    ingestion: "structured",
    artifact: "a56-fox total migration · STAGE_5 queued · not dispatched",
    capability: "Staged request only",
    constraint: ENGINE.constraints[1],
    timestamp: "2026-10-08T01:48:00Z",
    payload: "a56-fox|HOLD|PKCS7_CERT_TOKEN|NOT_ESTABLISHED",
  },
  {
    id: "LED-010",
    action: "Hold",
    source: "Operator paste",
    ingestion: "structured",
    artifact: "a56-fox reaffirmed · still STAGE_5 · not dispatched",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-10T04:46:00Z",
    payload: "a56-fox|REAFFIRM|HOLD|NOT_ESTABLISHED|NOT_SENT",
  },
  {
    id: "LED-011",
    action: "Hold",
    source: "DNS lookup",
    ingestion: "structured",
    artifact: "api.13adc.gov does not resolve · reserve-assets not sent",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-10T05:12:00Z",
    payload: "a56-fox|NXDOMAIN|13adc.gov|reserve-assets|NOT_SENT",
  },
  {
    id: "LED-012",
    action: "Hold",
    source: "HTTPS lookup",
    ingestion: "structured",
    artifact: "ai.studio service 404 · a56 not moved",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-10T05:17:00Z",
    payload: "a56-fox|ai.studio|404|NOT_SENT",
  },
  {
    id: "LED-013",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "structured",
    artifact: "US-1 web clip · Drive file body is 404: Not Found",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-10T05:20:00Z",
    payload: "com.13adc.us1.uplink.profile|US_1_Uplink.txt|404",
  },
  {
    id: "LED-014",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "geo-migrate-2026-10-07-01 · claimed SHA-256, bytes not present",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-10T05:41:00Z",
    payload: "geo-migrate-2026-10-07-01|db2d4737|NOT_RECOMPUTED",
  },
  {
    id: "LED-015",
    action: "Ingest",
    source: "Termux transcript",
    ingestion: "textual",
    artifact: "13adCompany local folders · checksums are local only",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-12T07:49:00Z",
    payload: "termux-13adCompany-2026-10-12|0039482103|LOCAL_ONLY",
  },
  {
    id: "LED-016",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "P.A.T. 13 deck · command hosts do not resolve",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-17T06:54:00Z",
    payload: "pat13-dreadnought-deck-2026-09-10|NXDOMAIN|NOT_EXECUTED",
  },
  {
    id: "LED-017",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "Car 13 desert spec · stated output, no entry",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-17T07:00:00Z",
    payload: "core-13-desert-runner-spec|850bhp|NOT_AN_ENTRY",
  },
  {
    id: "LED-018",
    action: "Ingest",
    source: "Operator paste",
    ingestion: "textual",
    artifact: "468 target curve · not a measured pull",
    capability: "Staged request only",
    constraint: ENGINE.constraints[4],
    timestamp: "2026-10-17T07:08:00Z",
    payload: "core-13-engine-target-2026|940hp|NOT_MEASURED",
  },
];

function buildLedger(seeds: Seed[]): LedgerRow[] {
  let parent = GENESIS_DIGEST;
  return seeds.map((s) => {
    const digest = digestOf(`${parent}|${s.id}|${s.payload}`);
    const row: LedgerRow = {
      id: s.id,
      actor: ACTOR,
      role: ROLE,
      action: s.action,
      source: s.source,
      ingestion: s.ingestion,
      artifact: s.artifact,
      capability: s.capability,
      constraint: s.constraint,
      timestamp: s.timestamp,
      digest,
      parentDigest: parent,
      classification: CLASS,
      evidenceBoundary: BOUNDARY,
      workspace: WORKSPACE,
    };
    parent = digest;
    return row;
  });
}

export const ENGINE_LEDGER: LedgerRow[] = buildLedger(SEEDS);

export function engineHead(): LedgerRow {
  return ENGINE_LEDGER[ENGINE_LEDGER.length - 1];
}

export function engineYaml(): string {
  const src = ENGINE.dataSources
    .map(
      (s) =>
        `    - name: "${s.name}"\n      type: "${s.type}"\n      ingestion: "${s.ingestion}"\n      status: "${s.status}"`,
    )
    .join("\n");
  const chain = ENGINE.chain.map((c) => `      - ${c}`).join("\n");
  const caps = ENGINE.capabilities.map((c) => `    - "${c}"`).join("\n");
  const cons = ENGINE.constraints.map((c) => `    - "${c}"`).join("\n");
  const ledger = ENGINE_LEDGER.map(
    (r) =>
      [
        `    - id: ${r.id}`,
        `      actor: "${r.actor}"`,
        `      role: "${r.role}"`,
        `      action: ${r.action}`,
        `      source: "${r.source}"`,
        `      ingestion: ${r.ingestion}`,
        `      artifact: "${r.artifact}"`,
        `      capability: "${r.capability}"`,
        `      constraint: "${r.constraint}"`,
        `      timestamp: ${r.timestamp}`,
        `      digest: ${r.digest}`,
        `      parent_digest: ${r.parentDigest}`,
        `      classification: ${r.classification}`,
        `      evidence_boundary: "${r.evidenceBoundary}"`,
        `      workspace: "${r.workspace}"`,
      ].join("\n"),
  ).join("\n");
  const head = engineHead();

  return [
    `EXCALIBUR_Metadata_Block:`,
    `  id: ${ENGINE.id}`,
    `  version: "${ENGINE.version}"`,
    `  description: >`,
    `    ${ENGINE.description}`,
    ``,
    `  operator:`,
    `    name: "${ENGINE.operator.name}"`,
    `    role: "${ENGINE.operator.role}"`,
    `    workspace: "${ENGINE.operator.workspace}"`,
    `    identity_tags:`,
    ...ENGINE.operator.identityTags.map((t) => `      - "${t}"`),
    ``,
    `  engine:`,
    `    mode: "${ENGINE.engine.mode}"`,
    `    execution_environment: "${ENGINE.engine.executionEnvironment}"`,
    `    persistence: "${ENGINE.engine.persistence}"`,
    `    determinism: "${ENGINE.engine.determinism}"`,
    `    auditability: "${ENGINE.engine.auditability}"`,
    `    classification_default: "${ENGINE.engine.classificationDefault}"`,
    ``,
    `  data_sources:`,
    src,
    ``,
    `  provenance_chain:`,
    `    structure:`,
    chain,
    `    genesis_digest: ${GENESIS_DIGEST}`,
    `    head_id: ${head.id}`,
    `    head_digest: ${head.digest}`,
    ``,
    `  capability_map:`,
    caps,
    ``,
    `  execution_constraints:`,
    cons,
    ``,
    `  ledger:`,
    ledger,
    ``,
    `  evidence_boundary:`,
    `    rule: "${ENGINE_BOUNDARY.lead}"`,
    `    not_established:`,
    ...ENGINE_BOUNDARY.notEstablished.map((e) => `      - "${e}"`),
    ``,
    `  license: "${ENGINE.license}"`,
    `  disclaimer: "${ENGINE_BOUNDARY.lead}"`,
    ``,
  ].join("\n");
}
