export const TIPS_CONTROL = "13ADC-DIR-TIPS-2026";

export const TIPS_BADGE = [
  "=========================================",
  "  13ADC  EXCALIBUR  PRE-DECISIONAL",
  "  DIR-TIPS-2026  ·  NIST 800-171",
  "=========================================",
].join("\n");

export type TipCategory =
  | "CHECKLIST"
  | "ENGINEERING"
  | "PROPOSAL"
  | "TERMINAL"
  | "SECURITY"
  | "PRINTING";

export interface Tip {
  n: number;
  tag: string;
  title: string;
  ref: string;
  category: TipCategory;
  body: string;
  directive: string;
}

export const TIP_CATEGORIES: { id: TipCategory | "ALL"; label: string }[] = [
  { id: "ALL", label: "All" },
  { id: "CHECKLIST", label: "Checklist" },
  { id: "ENGINEERING", label: "Engineering" },
  { id: "PROPOSAL", label: "Proposal" },
  { id: "TERMINAL", label: "Terminal" },
  { id: "SECURITY", label: "Security" },
  { id: "PRINTING", label: "Printing" },
];

export const TIPS: Tip[] = [
  {
    n: 1,
    tag: "PHASE BLUEPRINT",
    title: "End-to-End Deployment Roadmap",
    ref: "EXCALIBUR-AFW-2026-DEP-RM01",
    category: "CHECKLIST",
    body: "Moves EXCALIBUR across 8 structured phases: Pre-Award Google AI Studio prototyping → Award Entra tenant provisioning → Azure zero-trust architecture → Defense COP integration → Nevada basin field deployment → TRL-6 NNSS demonstration → Contract manufacturing → Fleet sustainment.",
    directive: "8-Phase Transition: Concept Sandbox → Entra Authority → Azure Defense → TRL-6",
  },
  {
    n: 2,
    tag: "PRE-RELEASE AUDIT",
    title: "Final ZIP Review Checklist",
    ref: "EXCALIBUR-AFW-2026-ZIP-CHK01",
    category: "CHECKLIST",
    body: "Before authorizing package release, step through the 7-section checklist: verify core submission slides, authority certificates, calibration datasets, and run automated Termux integrity tests.",
    directive: "Document Reference: EXCALIBUR-AFW-2026-ZIP-CHK01 | 7 Verification Sections",
  },
  {
    n: 3,
    tag: "NEXT ACTION",
    title: "Unified EXCALIBUR Technical Volume",
    ref: "Forward Action Milestone",
    category: "CHECKLIST",
    body: "Consolidates all system engineering blueprints, interface control specifications (ICD-26-09), and empirical spectroscopic baselines into one authoritative defense acquisition binder upon contract award.",
    directive: "Next Forward Milestone: Technical Volume Binder & SED-26-09 Synchronization",
  },
  {
    n: 4,
    tag: "MECHANICAL DYNAMICS",
    title: "13ADC C.O.R.E. Rough-Terrain Mechanical Dynamics",
    ref: "C.O.R.E.",
    category: "ENGINEERING",
    body: "Company Off-road Racing Engineering (C.O.R.E.) standards ruggedize field sensor nodes against severe vibrations, high dust ingestion, and acute thermal swings across off-road desert proving grounds.",
    directive: "C.O.R.E. Standards: Desert Hardening, Shock Isolation & Mobile Telemetry Rigs",
  },
  {
    n: 5,
    tag: "HAZMAT LADING",
    title: "Subpart H HazMat Lading & Hydrodynamic Physics Grounding",
    ref: "3355 E. Carey",
    category: "PROPOSAL",
    body: "Grounded in 2013 Subpart H HazMat Lading certification (3355 E. Carey Infrastructure), mathematical fluid surge damping models and Longer Combination Vehicle (LCV) dynamics provide physical stability baselines for heavy subterranean sensor node deployment.",
    directive: "2013 Subpart H HazMat Certified (3355 E. Carey) | Tanker Surge Physics",
  },
  {
    n: 6,
    tag: "OPTICAL HERITAGE",
    title: "Lake Mead Project 288 Optical Telemetry Lineage",
    ref: "Project 288",
    category: "PROPOSAL",
    body: "Descended from the 1948 Lake Mead high-altitude Sun Tracker platform, Project 288 telemetry provides empirical baselines for sun-angle differential atmospheric refraction across desert-lacustrine fault zones.",
    directive: "Lake Mead Baseline: 1948 Optical Heritage + High-Salinity Aquifer Coupling",
  },
  {
    n: 7,
    tag: "TERRAIN CALIBRATION",
    title: "Nevada Basin Lacustrine Fault-Line & Aquifer Calibration",
    ref: "Lake Mead waveguide",
    category: "ENGINEERING",
    body: "The high-salinity subterranean hydronic veins of Lake Mead serve as natural waveguides for dielectric flux, enabling repeatable signal-to-noise indexing before deploying into contested environments.",
    directive: "Lacustrine Fault Lines: Subterranean Waveguides for Dielectric Flux Calibration",
  },
  {
    n: 8,
    tag: "FEDERAL COMPLIANCE",
    title: "AFWERX & Federal Submission Prerequisites",
    ref: "SAM.gov / DSIP",
    category: "PROPOSAL",
    body: "To submit a live proposal to AFWERX CSO or SBIR/STTR programs, the applicant must possess an active SAM.gov registration (UEI & CAGE code) and an active Defense SBIR/STTR Innovation Portal (DSIP) account. Drafts must remain designated as PRE-DECISIONAL / INTERNAL until all official registration hurdles are complete.",
    directive: "Prerequisites: SAM.gov Active Status (UEI/CAGE) + DSIP Portal Access",
  },
  {
    n: 9,
    tag: "PRE-DECISIONAL",
    title: "Cover Sheet Designation & Pre-Decisional Status",
    ref: "Status banner",
    category: "PROPOSAL",
    body: "Official federal solicitations strictly disallow unauthorized logos or unverified registration codes. Retaining INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED ensures full compliance and prevents accidental representation as an already-awarded contract.",
    directive: "Status Banner: INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED",
  },
  {
    n: 10,
    tag: "BRIEFING SYNC",
    title: "Syncing COMPLETED_ABSTRACT.pptx Slide Deck",
    ref: "PPTX outline",
    category: "PROPOSAL",
    body: "Use the slide-notes download to get structured slide headers, talking points, and bullet layouts matching the written proposal sections. Paste into PowerPoint Outline View.",
    directive: "Download Outline → Paste into PowerPoint Outline View",
  },
  {
    n: 11,
    tag: "LOCAL ARCHIVE",
    title: "Local Markdown Archival & Git Tracking",
    ref: "GFM archive",
    category: "PROPOSAL",
    body: "Download Markdown or copy abstract text to save the proposal in local note archives (Obsidian, VS Code, or Git) for offline tracking.",
    directive: "Standard GitHub-flavored Markdown compatible with all tools",
  },
  {
    n: 12,
    tag: "PACKAGING VERIFY",
    title: "Termux Packaging & Checksum Verification",
    ref: "zip -9 -j",
    category: "TERMINAL",
    body: "After running zip -9 -j, always run sha256sum and unzip -t to verify the archive before transmission. A zero-error return code guarantees no corrupted payloads.",
    directive: "unzip -t verifies data integrity without unpacking",
  },
  {
    n: 13,
    tag: "CLI BRANDING",
    title: "ASCII Badge Embedding for CLI & Git Headers",
    ref: "41-character badge",
    category: "TERMINAL",
    body: "The Copy Badge action copies a standardized text block formatted for terminal banners, CLI MOTD, and Git repository headers.",
    directive: "Preserves fixed 41-character width formatting",
  },
  {
    n: 14,
    tag: "AIR-GAPPED STORAGE",
    title: "Air-Gapped & Local Filesystem Management",
    ref: "Termux tmp",
    category: "TERMINAL",
    body: "In Termux, store submission packages under /data/data/com.termux/files/usr/tmp or local storage before generating sha256sum checksums. This keeps working files isolated from public cloud sync.",
    directive: "Path: /data/data/com.termux/files/usr/tmp/DARPA-PS-26-09_submission",
  },
  {
    n: 15,
    tag: "IDENTITY TENANT",
    title: "Microsoft Entra Identity Tenant & Principal Architect Governance",
    ref: "Entra RBAC",
    category: "SECURITY",
    body: "Post-award provisioning maps Principal Architect Shawn Patrick Cooper Gardner to absolute executive cloud tenant authority, binding all AI microservices to dedicated service principals with Conditional Access.",
    directive: "Entra RBAC: Dedicated Defense Tenant + Principal Architect Role Authority",
  },
  {
    n: 16,
    tag: "HSM ENCRYPTION",
    title: "Azure Key Vault + HSM Hardware Cryptographic Signing",
    ref: "FIPS 140-2 L3",
    category: "SECURITY",
    body: "Telemetry packets ingested from mobile field sensors are signed at the Hardware Security Module (HSM) boundary, ensuring immutable origin attestation and anti-tamper validation.",
    directive: "Cryptographic Provenance: FIPS 140-2 Level 3 HSM Telemetry Signing",
  },
  {
    n: 17,
    tag: "COP INTEGRATION",
    title: "Defense Common Operational Picture (COP) Ingestion Feeds",
    ref: "Signed protobuf",
    category: "ENGINEERING",
    body: "EXCALIBUR streams feed into standard military COP tactical consoles via signed protobuf payloads, providing real-time subsurface and atmospheric transition visualization without latency spikes.",
    directive: "COP Feeds: Sub-Second Telemetry Ingestion via Signed Protobuf Payloads",
  },
  {
    n: 18,
    tag: "TRL-6 DEMONSTRATION",
    title: "TRL-6 Demonstration Protocols at NNSS / White Sands",
    ref: "NNSS Phase 6",
    category: "ENGINEERING",
    body: "The Phase 6 operational exercise at Nevada National Security Site executes live anomaly detection under high-contrast thermal gradients and simulated adversarial electronic jamming.",
    directive: "TRL-6 Milestone: Live Anomaly Tracking Under Electronic Jamming Stress",
  },
  {
    n: 19,
    tag: "ZERO-TRUST IAM",
    title: "Zero-Trust IAM Enforcement & No Anonymous Endpoints",
    ref: "NIST SP 800-171",
    category: "SECURITY",
    body: "Always bind AI service endpoints to explicit federated identities (OIDC/OAuth 2.0). Reject all anonymous or unauthenticated API calls to comply with NIST SP 800-171 guidelines.",
    directive: "Least-privilege service accounts: cloudrun-identity & ai-governance",
  },
  {
    n: 20,
    tag: "AUDIT PROVENANCE",
    title: "Tamper-Resistant Telemetry Logging & Audit Trails",
    ref: "Hardware timestamps",
    category: "SECURITY",
    body: "Maintain immutable audit logs with hardware-backed timestamps. Any unexpected permission elevation attempts should trigger automatic containment and immediate alerting.",
    directive: "Continuous perimeter logging aligned with NIST SP 800-171",
  },
  {
    n: 21,
    tag: "PUBLIC INTERFACE",
    title: "Zero CUI / Non-ITAR Public Interface Sanitization",
    ref: "No CUI",
    category: "SECURITY",
    body: "Verify that no Controlled Unclassified Information (CUI), classified materials, or ITAR-controlled designs are ever pasted into public AI prompts or web interfaces. Keep all operational proposals strictly internal and unclassified.",
    directive: "Zero CUI / Non-ITAR Guarantee: Public Domain & Pre-Decisional Only",
  },
  {
    n: 22,
    tag: "SAFETY PROTOCOL",
    title: "PEC Safety Certification 00711617 Field Protocols",
    ref: "PEC 00711617",
    category: "ENGINEERING",
    body: "All field testing rigs, high-mass sensor anchors, and lacustrine survey nodes adhere to strict PEC safety compliance, ensuring accident-free execution across steep desert fault lines.",
    directive: "PEC Safety Cert: 00711617 | Zero-Incident Rigging & Logistics Standard",
  },
  {
    n: 23,
    tag: "NAICS CLASSIFICATION",
    title: "NAICS 541715 R&D Accounting & SBIR Cost Accounting",
    ref: "NAICS 541715",
    category: "PROPOSAL",
    body: "Work performed under NAICS 541715 (Research and Development in the Physical, Engineering, and Life Sciences) maintains segregated phase-by-phase cost ledgering matching DARPA SOW milestones.",
    directive: "NAICS 541715: Segregated R&D Accounting Aligned with Federal FAR Rules",
  },
  {
    n: 24,
    tag: "PDF PRINT SETTINGS",
    title: "High-Fidelity PDF Generation Settings",
    ref: "Background graphics",
    category: "PRINTING",
    body: "When printing or saving as PDF, enable Background graphics in the browser print dialog so borders, seals, and watermark crests render with crisp contrast.",
    directive: "Print Dialog → More Settings → Check “Background graphics”",
  },
  {
    n: 25,
    tag: "PAGE MARGINS",
    title: "Standard US Letter & Margins Alignment",
    ref: "US Letter / A4",
    category: "PRINTING",
    body: "The print layout is calibrated for US Letter (8.5\" × 11\") and A4 portrait. Setting margins to Default or Minimum gives a balanced presentation without awkward page breaks.",
    directive: "Paper Size: US Letter / A4 | Margins: Default",
  },
  {
    n: 26,
    tag: "SHORTCUTS",
    title: "Keyboard Shortcuts & Fast Action Triggers",
    ref: "Ctrl/Cmd+P",
    category: "PRINTING",
    body: "Press Ctrl+P (or Cmd+P on macOS) to launch the high-resolution printable layout. Press Esc to dismiss expanded tips. Use one-click Copy for clipboard ingestion.",
    directive: "Print: Ctrl+P / Cmd+P | Close: Esc | Copy: 1-click clipboard",
  },
];

export function tipsMarkdown(): string {
  const lines = [
    `# 13 Aerospace Defense Company`,
    `## Operational & Technical Lightbulb Tips Compendium`,
    ``,
    `**Document control:** ${TIPS_CONTROL}`,
    `**Principal Cloud Architect:** Shawn Patrick Cooper Gardner`,
    `**Total active tips:** ${TIPS.length}`,
    `**Governance:** Zero-Trust | NIST SP 800-171 aligned`,
    `**Status:** INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED`,
    ``,
    `This compendium consolidates operational, technical, logistical, and architectural tips developed across Project EXCALIBUR, DARPA-PS-26-09, AFWERX CSO, and Microsoft Entra / Azure zero-trust governance.`,
    ``,
  ];
  for (const t of TIPS) {
    lines.push(`### ${t.n}. [${t.tag}] ${t.title}`);
    lines.push(`**Category:** ${t.category}  `);
    lines.push(`**Reference:** ${t.ref}`);
    lines.push(``);
    lines.push(t.body);
    lines.push(``);
    lines.push(`> **Directive:** \`${t.directive}\``);
    lines.push(``);
  }
  lines.push(
    `---`,
    ``,
    `*Authorized by Shawn Patrick Cooper Gardner, Principal Cloud Architect & System Owner, 13 Aerospace Defense Company.*`,
    ``,
  );
  return lines.join("\n");
}
