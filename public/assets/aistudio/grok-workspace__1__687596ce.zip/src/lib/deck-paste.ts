/** Pasted screen from 2026-09-10. Labels are on the screen. They were not checked against an agency. */
export const DECK_PASTE = {
  id: "pat13-dreadnought-deck-2026-09-10",
  seen: "2026-09-10T23:26:26Z",
  title: "P.A.T. 13 cognitive bridge",
  dns:
    "command.13aerospacedefensecompany.com, telemetry.13aerospacedefensecompany.com, 13aerospacedefensecompany.com, and m2m.infrastructure.net do not resolve.",
  claims: [
    "The screen calls itself a command node, an ATO, and a federal jurisdiction. Those words are on the page. No agency record was attached.",
    "CAGE 9AZX1 and UEI A13B-X792-C4M9 are printed on the screen. The earlier cover sheet still said UEI and CAGE were placeholders. A UEI does not use hyphens.",
    "This screen’s FRN is 00314163408. The phone yaml used 0039482103. Those are different numbers, and neither was confirmed here.",
    "Treasury “+$11,050.00 influx” and a Cash App route are text on a chart. No bank record was included.",
    "Logistics “100% online,” satellite lock, and “US GOV DEFENSE TERRITORY: ENFORCED” are status lines. They are not a feed.",
    "NextDNS, 192.168.137.173, and the link-local IPv6 are private-network notes. This console is not on that network.",
    "The shell URLs say pending provisioning. The command and telemetry hostnames do not resolve.",
    "Hangar temperature is printed as 72°C. That is a hot room, not a verified sensor.",
  ],
} as const;
