/** Unsigned web-clip plist. Not installed. Not a device uplink. */
export const UPLINK_PROFILE = {
  id: "com.13adc.us1.uplink.profile",
  name: "13ADC US-1 Uplink Profile",
  description: "13 Aerospace Defense Company US-1 Visual & UX Uplink Profile",
  organization: "13 Aerospace Defense Company",
  type: "Configuration",
  uuid: "13ADC-US1-UPLINK-2026-00711617",
  version: 1,
  clip: {
    label: "13ADC US-1",
    fullScreen: true,
    url: "https://drive.google.com/file/d/12GgfISncfYzd4-wI7NZAD1mDb6pkCkLE/view?usp=drivesdk",
    driveFileId: "12GgfISncfYzd4-wI7NZAD1mDb6pkCkLE",
    driveName: "US_1_Uplink.txt",
    driveBody: "404: Not Found",
  },
  notes: [
    "The paste is an unsigned Apple web-clip plist. It was not installed on a device.",
    "The opening mark is missing: the text starts at xml version, not <?xml.",
    "The icon is the placeholder [BASE64_PNG_DATA_460x460_2899_BYTES], not PNG bytes.",
    "The only payload is a full-screen link to a Google Drive file.",
    "That file is a text file named US_1_Uplink.txt. Its contents are the words 404: Not Found.",
    "This does not move a56-fox, open api.13adc.gov, or create a certificate.",
  ],
} as const;
