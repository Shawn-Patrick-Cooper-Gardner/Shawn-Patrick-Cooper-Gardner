export const FPDS_CONTROL = "13ADC-DIR-FPDS-2026-PIID";

export const FPDS_BOUNDARY = {
  title: "Evidence-control rule",
  lead: "These are public FPDS-NG records whose delivery-order PIID is the numeral 2026. That identifier is an order number on older IDIQ vehicles. It is not fiscal year 2026, not an AFWERX CSO award, and not Project EXCALIBUR.",
  notEstablished: [
    "an award to 13 Aerospace Defense Company",
    "an award to Shawn Patrick Cooper Gardner",
    "SAM.gov registration, UEI, or CAGE for the applicant",
    "AFWERX / SBIR / STTR selection or funding",
    "a current NAVSEA or NAVFAC contract",
    "NAICS 541715 performance history",
  ],
  note: "Applicant claims and public award extracts must not be converted into verified federal status, past performance, or proposal eligibility without independent authoritative evidence.",
} as const;

export interface FpdsAward {
  id: string;
  agency: string;
  officeId: string;
  office: string;
  piid: string;
  idv: string;
  signed: string;
  popStart: string;
  popEnd: string;
  type: string;
  psc: string;
  pscLabel: string;
  naics: string | null;
  naicsLabel: string | null;
  place: string;
  country: string;
  competed: string;
  setAside: string;
  awardType: string;
  uei: string | null;
  vendor: string;
  parentUei: string | null;
  parent: string | null;
  address: string;
  size: string;
  obligation: number | null;
  incomplete?: boolean;
}

export const FPDS_AWARDS: FpdsAward[] = [
  {
    id: "NAVSEA-2026-EDS",
    agency: "Dept of the Navy",
    officeId: "BZ006",
    office: "Naval Sea Systems Command",
    piid: "2026",
    idv: "N0002400D6000",
    signed: "2000-10-06",
    popStart: "2000-10-06",
    popEnd: "2001-09-30",
    type: "Fixed price",
    psc: "D399",
    pscLabel: "Other ADP & telecommunications services",
    naics: "541519",
    naicsLabel: "Other computer related services",
    place: "Herndon, Fairfax County, Virginia",
    country: "United States",
    competed: "Full and open competition",
    setAside: "No set aside used",
    awardType: "Delivery order",
    uei: "MBSRAWAQ9559",
    vendor: "Electronic Data Systems Corporation",
    parentUei: "SMLNZ8X9SHE7",
    parent: "Hewlett-Packard Company",
    address: "13600 EDS Drive, Herndon, VA 20171",
    size: "Other than small business",
    obligation: 32199,
  },
  {
    id: "NAVFAC-2026-ALLSTAR",
    agency: "Dept of the Navy",
    officeId: "C2470",
    office: "Naval Facilities Engineering Command",
    piid: "2026",
    idv: "N0018795D6050",
    signed: "2000-10-27",
    popStart: "2000-10-27",
    popEnd: "2000-11-27",
    type: "Fixed price",
    psc: "Z161",
    pscLabel: "Maint-rep-alt / family housing",
    naics: "235990",
    naicsLabel: "All other special trade contractors",
    place: "Virginia Beach, Virginia",
    country: "United States",
    competed: "Full and open competition",
    setAside: "No set aside used",
    awardType: "Delivery order",
    uei: "NJ5DK8XBHVH1",
    vendor: "All Star Maintenance, Inc.",
    parentUei: "NJ5DK8XBHVH1",
    parent: "All Star Maintenance, Inc.",
    address: "12250 El Camino Real, San Diego, CA 92130",
    size: "Other than small business",
    obligation: 182,
  },
  {
    id: "NAVFAC-2026-DG21",
    agency: "Dept of the Navy",
    officeId: "C2742",
    office: "Naval Facilities Engineering Command",
    piid: "2026",
    idv: "N6274298D4500",
    signed: "2003-08-25",
    popStart: "2003-08-25",
    popEnd: "2004-09-09",
    type: "Fixed price",
    psc: "S299",
    pscLabel: "Other housekeeping services",
    naics: "561210",
    naicsLabel: "Facilities support services",
    place: "British Indian Ocean Territory",
    country: "British Indian Ocean Territory",
    competed: "Full and open competition",
    setAside: "No set aside used",
    awardType: "Delivery order",
    uei: "W9NNLCGR6F18",
    vendor: "DG21 LLC",
    parentUei: "Z98HJ42NLET3",
    parent: "FirstGroup PLC",
    address: "14900 Landmark Boulevard, Dallas, TX 75254",
    size: "Other than small business",
    obligation: 350244,
  },
  {
    id: "FECO-2026-YOKOSOH",
    agency: "Dept of the Navy",
    officeId: "C2836",
    office: "Far East Contracts Office",
    piid: "2026",
    idv: "N6283697D0118",
    signed: "2001-10-25",
    popStart: "2001-10-25",
    popEnd: "2001-10-31",
    type: "Firm fixed price",
    psc: "R499",
    pscLabel: "Other professional services",
    naics: "561210",
    naicsLabel: "Facilities support services",
    place: "Yokosuka, Japan",
    country: "Japan",
    competed: "Full and open competition",
    setAside: "No set aside used",
    awardType: "Delivery order",
    uei: "MYUZRWC5PVY5",
    vendor: "Yokosoh Co Ltd",
    parentUei: "MYUZRWC5PVY5",
    parent: "Yokosoh Co Ltd",
    address: "1-17-98 Morisaki, Yokosuka 238",
    size: "Other than small business",
    obligation: 53,
  },
  {
    id: "NAVFAC-2026-SUDALLARM",
    agency: "Dept of the Navy",
    officeId: "C3191",
    office: "Naval Facilities Engineering Command",
    piid: "2026",
    idv: "N3319198D2216",
    signed: "2003-04-09",
    popStart: "2003-04-09",
    popEnd: "2003-05-09",
    type: "Fixed price",
    psc: "S202",
    pscLabel: "Fire protection services",
    naics: "561210",
    naicsLabel: "Facilities support services",
    place: "Napoli, Italy",
    country: "Italy",
    competed: "Full and open competition",
    setAside: "No set aside used",
    awardType: "Delivery order",
    uei: "K4KVJKY546X6",
    vendor: "Sud Allarm. di Lutricuso Aldo",
    parentUei: "K4KVJKY546X6",
    parent: "Lutricuso Aldo Allarm Sud",
    address: "Via Sartania 37 40, Napoli 80126",
    size: "Other than small business",
    obligation: 2701,
  },
  {
    id: "NAVFAC-2026-JCWS",
    agency: "Dept of the Navy",
    officeId: "C4255",
    office: "Naval Facilities Engineering Field",
    piid: "2026",
    idv: "N4425595D6130",
    signed: "2002-04-11",
    popStart: "2002-04-11",
    popEnd: "2002-07-11",
    type: "Fixed price",
    psc: "S216",
    pscLabel: "Facilities operations support services",
    naics: null,
    naicsLabel: null,
    place: "Naval Submarine Base Bangor, Silverdale, Washington",
    country: "United States",
    competed: "Not in extract",
    setAside: "Not in extract",
    awardType: "Delivery order",
    uei: null,
    vendor: "Johnson Controls World Service",
    parentUei: null,
    parent: null,
    address: "Naval Subbase Bangor Bldg 10, Silverdale, WA",
    size: "Not in extract",
    obligation: null,
    incomplete: true,
  },
];

export function formatUsd(n: number | null): string {
  if (n == null) return "Not in extract";
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
  }).format(n);
}

export function fpdsKnownObligation(): number {
  return FPDS_AWARDS.reduce((sum, a) => sum + (a.obligation ?? 0), 0);
}

export function fpdsMarkdown(): string {
  const lines = [
    `# FPDS-NG extract — delivery-order PIID 2026`,
    ``,
    `**Document control:** ${FPDS_CONTROL}`,
    `**Status:** INTERNAL — PRE-DECISIONAL — RESEARCH EXTRACT`,
    ``,
    `## Evidence-control rule`,
    ``,
    FPDS_BOUNDARY.lead,
    ``,
    `This extract does **not** establish:`,
    ``,
    ...FPDS_BOUNDARY.notEstablished.map((e) => `- ${e}`),
    ``,
    FPDS_BOUNDARY.note,
    ``,
    `Known action obligation in this extract: ${formatUsd(fpdsKnownObligation())} across ${FPDS_AWARDS.filter((a) => a.obligation != null).length} of ${FPDS_AWARDS.length} rows.`,
    ``,
  ];
  for (const a of FPDS_AWARDS) {
    lines.push(`### ${a.vendor} — ${a.officeId} / ${a.piid}`);
    lines.push(``);
    lines.push(`- Agency: ${a.agency} · ${a.office} (${a.officeId})`);
    lines.push(`- PIID: ${a.piid} against IDV ${a.idv}`);
    lines.push(`- Signed: ${a.signed} · PoP ${a.popStart} → ${a.popEnd}`);
    lines.push(`- Type: ${a.type} · ${a.awardType}`);
    lines.push(`- PSC: ${a.psc} ${a.pscLabel}`);
    lines.push(`- NAICS: ${a.naics ?? "Not in extract"} ${a.naicsLabel ?? ""}`.trim());
    lines.push(`- Place: ${a.place} (${a.country})`);
    lines.push(`- Competition: ${a.competed} · ${a.setAside}`);
    lines.push(`- UEI: ${a.uei ?? "Not in extract"}`);
    lines.push(`- Parent: ${a.parent ?? "Not in extract"}`);
    lines.push(`- Address: ${a.address}`);
    lines.push(`- Size: ${a.size}`);
    lines.push(`- Obligation: ${formatUsd(a.obligation)}${a.incomplete ? " (row truncated in source paste)" : ""}`);
    lines.push(``);
  }
  return lines.join("\n");
}
