/** Staged curl. Not dispatched. Token is a placeholder, not a certificate. */
export const MIGRATION_HOLD = {
  id: "a56-fox",
  control: "STAGE_5_CURL_QUEUED",
  status: "HOLD — not dispatched",
  received: "2026-10-08T01:48:00Z",
  reaffirmed: "2026-10-10T04:46:00Z",
  dnsChecked: "2026-10-10T05:12:00Z",
  dns: "api.13adc.gov, 13adc.gov, and www.13adc.gov do not resolve. No address, no HTTP response.",
  studioHost: "service-13adc-cloud-ai-governance-4096.ai.studio",
  studio:
    "The typed name .ai.sudio does not resolve. The corrected .ai.studio name resolves to Google addresses and returns HTTP 404 on /, /api, /v1, and /health. No migration was sent.",
  method: "POST",
  url: "https://api.13adc.gov/v1/migration/execute/a56-fox",
  headers: {
    authorization: "Bearer <PKCS7_CERT_TOKEN>",
    contentType: "application/json",
    vibeCode: "MH55_AFMC_13ADC_IO26",
    targetProject: "p-a-t-13-98670851",
  },
  body: {
    migrationType: "TOTAL_MIGRATION",
    source: "CURRENT_TABLET_TERMUX_SESSION",
    destination: "1401_MADRONE_HQ",
    securityProtocol: "PKCS7_V5.9_DOD_CERTIFIED",
    license: "BSD_CLAUSE_3_PRODUCTION",
    device: {
      model: "WHOOP_TAB-8US2_11_HW_1.0",
      serial: "AF312TYQ23073108072",
      role: "CURRENT_AND_ONLY_AVAILABLE_DEVICE",
      termuxConfirmed: true,
    },
    labels: {
      dodMetadata: "VERIFIED_DOD",
      dodStatus: "EXECUTIVE_AFFIRMED_AUTHORITATIVE",
      verification: "ATTESTED_UNDER_13ADC_EXECUTIVE_DIRECTIVE",
      externalVerification: "NOT_ESTABLISHED",
    },
  },
  holdReasons: [
    "The request’s own status is hold pending dispatch release.",
    "External verification is NOT_ESTABLISHED. DoD and executive-affirmed labels are self-attested only.",
    "The bearer is the placeholder <PKCS7_CERT_TOKEN>, not a certificate.",
    "api.13adc.gov is not a confirmed 13ADC or federal endpoint. A .gov host is not created by naming it.",
    "This console does not send migration or actuator commands.",
    "Presented again 2026-10-10. The wrapper was not a recognized dispatcher. Still not sent.",
    "DNS checked 2026-10-10: api.13adc.gov does not resolve. There is no API to call.",
    "A separate localhost reserve-assets call was not sent. Its body is not valid JSON, and no treasury asset was reserved.",
    "service-13adc-cloud-ai-governance-4096.ai.studio answers 404. It is not a migration destination.",
  ],
} as const;

/** Banner only. The JSON bytes are not in this console, so the hash was not recomputed. */
export const GEO_CLAIM = {
  id: "geo-migrate-2026-10-07-01",
  serial: "AF312TYQ23073108072",
  path: "/data/data/com.termux/files/home/13.geoint.core_migration_provenance.json",
  exportPath:
    "/data/data/com.termux/files/home/storage/downloads/13.geoint.core_migration_provenance.json",
  plistPath: "/data/data/com.termux/files/home/storage/downloads/airtalk_config.plist",
  claimedSha256: "db2d4737f4f7342b20a5727a7320bacfcc98a8cf41926d9474c2e412b54dd44f",
  status: "Claimed match. Not recomputed here.",
  notes: [
    "This paste is a status banner, not the JSON file.",
    "The path is inside a Termux app on a phone. This console cannot read it.",
    "The file is not in this workspace and not in Google Drive under that name.",
    "SHA-256 was not recomputed, so MATCH CONFIRMED is not established.",
    "The Airtalk plist write is claimed. The plist was not included.",
  ],
} as const;
