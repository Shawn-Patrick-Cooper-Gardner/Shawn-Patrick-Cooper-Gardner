import { i as __toESM } from "../_runtime.mjs";
import { K as require_jsx_runtime, _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { c as FileStack, i as Radio, n as TriangleAlert, o as Lightbulb, r as Shield, s as Flag, t as Truck, u as Crosshair } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-DuBNYxjd.js
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var tones = {
	neutral: "text-muted bg-elevated",
	ok: "text-ok bg-ok/10",
	caution: "text-caution bg-caution/10",
	alert: "text-alert bg-alert/10"
};
function Badge({ className, tone = "neutral", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center gap-1.5 rounded-sm px-2 py-0.5 font-mono text-xs uppercase tracking-widest", tones[tone], className),
		...props
	});
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-NnI91c-F.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
/** Geometric 13 lockup — the 13ADC tail-number mark. */
function Mark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("text-fg", className),
		fill: "currentColor",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "5.5",
				y: "6.5",
				width: "3.4",
				height: "19"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "5.5",
				y: "6.5",
				width: "6.4",
				height: "2.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14.2",
				y: "6.5",
				width: "12.2",
				height: "2.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "23.6",
				y: "6.5",
				width: "2.8",
				height: "8.2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "16.6",
				y: "14.6",
				width: "9.8",
				height: "2.8"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "23.6",
				y: "14.6",
				width: "2.8",
				height: "10.9"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "14.2",
				y: "22.7",
				width: "12.2",
				height: "2.8"
			})
		]
	});
}
function formatZulu(date) {
	return `${date.toISOString().slice(11, 19)}Z`;
}
function formatCoord(lat, lon) {
	const ns = lat >= 0 ? "N" : "S";
	const ew = lon >= 0 ? "E" : "W";
	return `${Math.abs(lat).toFixed(4)}°${ns}  ${Math.abs(lon).toFixed(4)}°${ew}`;
}
function formatPct(n, digits = 0) {
	return `${(n * 100).toFixed(digits)}%`;
}
function hashString(input) {
	let h = 2166136261;
	for (let i = 0; i < input.length; i++) {
		h ^= input.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function seededUnit(id, tick, salt = 0) {
	const phase = hashString(`${id}:${salt}`) % 3600 / 3600;
	return Math.sin((tick * .11 + phase) * Math.PI * 2) * .5 + .5;
}
function LiveClock() {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
		const id = window.setInterval(() => setNow(/* @__PURE__ */ new Date()), 1e3);
		return () => window.clearInterval(id);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-right",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-xs uppercase tracking-widest text-muted",
			children: "Zulu"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-mono text-sm tabular-nums text-fg",
			children: now ? formatZulu(now) : "——:——:——Z"
		})]
	});
}
var PROGRAM = {
	title: "PROJECT EXCALIBUR",
	subtitle: "Terrain-Sensing, HazMat Logistics Modeling & Zero-Trust Telemetry",
	control: "EXCALIBUR-AFW-2026-DIR01",
	solicitation: "AFWERX Commercial Solutions Opening (CSO)",
	company: "13 Aerospace Defense Company",
	legalName: "Shawn Patrick Cooper Gardner d/b/a 13 Aerospace Defense Company",
	pi: "Shawn Patrick Cooper Gardner",
	piTitle: "Principal Cloud Architect",
	email: "gardnershawn379@gmail.com",
	phone: "(702) 663-0160",
	location: "803 Clarice Ln, Boulder City, NV 89005",
	naics: "541715",
	naicsLabel: "R&D in Physical, Engineering, Life Sciences",
	theater: "Boulder City Operational Theater / Lake Mead Baseline",
	classification: "INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED",
	status: "INTERNAL"
};
var BOUNDS = {
	west: -115.08,
	east: -114.28,
	north: 36.28,
	south: 35.9
};
var OVERLAYS = [
	{
		id: "lidar",
		label: "LiDAR point cloud",
		short: "LiDAR"
	},
	{
		id: "hsi",
		label: "Hyperspectral imaging",
		short: "HSI"
	},
	{
		id: "gpr",
		label: "Ground-penetrating radar",
		short: "GPR"
	},
	{
		id: "mag",
		label: "Magnetometry",
		short: "MAG"
	},
	{
		id: "hydro",
		label: "Hydrological model",
		short: "HYDRO"
	},
	{
		id: "logistics",
		label: "HazMat logistics",
		short: "LOG"
	},
	{
		id: "grid",
		label: "Coordinate grid",
		short: "GRID"
	}
];
var SENSORS = [
	{
		id: "LIDAR-01",
		name: "Hoover Overlook",
		kind: "lidar",
		x: .41,
		y: .78,
		lat: 36.021,
		lon: -114.741,
		elevM: 412,
		health: "nominal",
		installed: "2026-03-18",
		spec: "905 nm · 128-ch · 300 m",
		notes: "Dam abutment scan, spillway geometry, canyon wall change detection."
	},
	{
		id: "LIDAR-02",
		name: "River Mountains",
		kind: "lidar",
		x: .22,
		y: .7,
		lat: 36.048,
		lon: -114.918,
		elevM: 891,
		health: "nominal",
		installed: "2026-03-22",
		spec: "1550 nm · 64-ch · 450 m",
		notes: "High-ground coverage of Boulder City grid and US-93 corridor."
	},
	{
		id: "HSI-01",
		name: "Boulder Harbor",
		kind: "hsi",
		x: .33,
		y: .66,
		lat: 36.04,
		lon: -114.802,
		elevM: 372,
		health: "nominal",
		installed: "2026-04-02",
		spec: "400–2500 nm · 224 bands",
		notes: "Shoreline mineral and hydrocarbon film detection."
	},
	{
		id: "HSI-02",
		name: "Virgin Narrows",
		kind: "hsi",
		x: .54,
		y: .46,
		lat: 36.118,
		lon: -114.62,
		elevM: 368,
		health: "nominal",
		installed: "2026-04-09",
		spec: "400–2500 nm · 224 bands",
		notes: "Algal and sediment plume tracking between basins."
	},
	{
		id: "GPR-01",
		name: "US-93 Corridor",
		kind: "gpr",
		x: .3,
		y: .74,
		lat: 36.012,
		lon: -114.832,
		elevM: 610,
		health: "nominal",
		installed: "2026-03-28",
		spec: "200–900 MHz dual",
		notes: "Subsurface void and utility mapping under the dam approach."
	},
	{
		id: "GPR-02",
		name: "Railroad Pass",
		kind: "gpr",
		x: .14,
		y: .62,
		lat: 36.07,
		lon: -114.98,
		elevM: 668,
		health: "degraded",
		installed: "2026-04-11",
		spec: "200–900 MHz dual",
		notes: "EMI from I-11 substations. Filter retune scheduled."
	},
	{
		id: "MAG-01",
		name: "Black Canyon",
		kind: "mag",
		x: .4,
		y: .88,
		lat: 35.972,
		lon: -114.748,
		elevM: 290,
		health: "nominal",
		installed: "2026-04-04",
		spec: "Fluxgate + Overhauser",
		notes: "Ferrous anomaly baseline along the river gorge."
	},
	{
		id: "MAG-02",
		name: "McCullough Range",
		kind: "mag",
		x: .08,
		y: .52,
		lat: 36.11,
		lon: -115.04,
		elevM: 1124,
		health: "nominal",
		installed: "2026-04-16",
		spec: "Fluxgate + Overhauser",
		notes: "Regional diurnal correction reference."
	},
	{
		id: "HYDRO-01",
		name: "Boulder Basin Gauge",
		kind: "hydro",
		x: .36,
		y: .62,
		lat: 36.055,
		lon: -114.78,
		elevM: 367,
		health: "nominal",
		installed: "2026-03-12",
		spec: "ADCP + stage + temp",
		notes: "Lake Mead pool elevation and circulation."
	},
	{
		id: "HYDRO-02",
		name: "Intake Towers",
		kind: "hydro",
		x: .44,
		y: .76,
		lat: 36.028,
		lon: -114.725,
		elevM: 355,
		health: "nominal",
		installed: "2026-03-14",
		spec: "ADCP + turbidity",
		notes: "Forebay current shear and sediment load."
	},
	{
		id: "EDGE-01",
		name: "Clarice Lane HQ",
		kind: "edge",
		x: .2,
		y: .68,
		lat: 35.9786,
		lon: -114.8391,
		elevM: 765,
		health: "nominal",
		installed: "2026-02-01",
		spec: "Zero-trust edge node",
		notes: "System owner, identity issuer, provenance root."
	},
	{
		id: "EDGE-02",
		name: "Callville Bay",
		kind: "edge",
		x: .46,
		y: .5,
		lat: 36.138,
		lon: -114.71,
		elevM: 385,
		health: "nominal",
		installed: "2026-04-20",
		spec: "Zero-trust edge node",
		notes: "Austere-link relay. Store-and-forward when SATCOM drops."
	}
];
var KIND_META = {
	lidar: {
		label: "LiDAR",
		overlay: "lidar"
	},
	hsi: {
		label: "Hyperspectral",
		overlay: "hsi"
	},
	gpr: {
		label: "GPR",
		overlay: "gpr"
	},
	mag: {
		label: "Magnetometry",
		overlay: "mag"
	},
	hydro: {
		label: "Hydrology",
		overlay: "hydro"
	},
	edge: {
		label: "Edge / identity",
		overlay: null
	}
};
var SITES = [
	{
		id: "SITE-HQ",
		name: "13ADC Clarice Lane",
		x: .2,
		y: .68,
		kind: "hq",
		notes: "Principal operating location. Identity root of trust."
	},
	{
		id: "SITE-DAM",
		name: "Hoover Dam",
		x: .42,
		y: .8,
		kind: "dam",
		notes: "Critical infrastructure adjacency. No CUI ingested at the edge."
	},
	{
		id: "SITE-YARD",
		name: "Boulder Staging Yard",
		x: .24,
		y: .72,
		kind: "staging",
		notes: "LCV and cargo-tank marshalling. Subpart H security plan."
	},
	{
		id: "SITE-HBR",
		name: "Boulder Harbor",
		x: .325,
		y: .655,
		kind: "harbor",
		notes: "Hydrological baseline pier."
	}
];
var CONVOYS = [
	{
		id: "CVY-A",
		callsign: "ALPHA",
		cargo: "Diesel fuel",
		un: "UN1202",
		tank: "MC-406",
		fill: .62,
		path: [
			[.12, .58],
			[.18, .64],
			[.24, .7],
			[.3, .74],
			[.38, .78],
			[.42, .8]
		],
		notes: "US-93 northbound to dam service. Partial fill — surge watch."
	},
	{
		id: "CVY-B",
		callsign: "BRAVO",
		cargo: "Gasoline",
		un: "UN1203",
		tank: "MC-406",
		fill: .88,
		path: [
			[.1, .48],
			[.16, .56],
			[.2, .66],
			[.24, .72]
		],
		notes: "I-11 to Boulder staging. High fill, low free-surface."
	},
	{
		id: "CVY-C",
		callsign: "CHARLIE",
		cargo: "Propane",
		un: "UN1978",
		tank: "MC-331",
		fill: .45,
		path: [
			[.26, .8],
			[.22, .74],
			[.2, .68],
			[.18, .6]
		],
		notes: "Pressure vessel. LCV Rocky Mountain Double, southbound."
	}
];
var ROADS = [
	[
		[.02, .46],
		[.1, .52],
		[.16, .6],
		[.2, .66],
		[.24, .72],
		[.3, .75],
		[.38, .78],
		[.42, .8]
	],
	[
		[.2, .68],
		[.26, .66],
		[.3, .64],
		[.325, .655]
	],
	[
		[.325, .655],
		[.38, .58],
		[.46, .5],
		[.58, .42],
		[.7, .32]
	],
	[
		[.08, .72],
		[.14, .7],
		[.2, .68],
		[.24, .66]
	]
];
var CITY_BLOCKS = [
	[
		.17,
		.64,
		.07,
		.08
	],
	[
		.19,
		.7,
		.05,
		.05
	],
	[
		.15,
		.66,
		.04,
		.04
	]
];
var LAKE_POLY = [
	[.42, .8],
	[.4, .88],
	[.385, .97],
	[.41, .97],
	[.445, .86],
	[.45, .8],
	[.48, .72],
	[.54, .6],
	[.62, .52],
	[.78, .48],
	[.9, .45],
	[.97, .43],
	[.98, .48],
	[.9, .5],
	[.78, .53],
	[.68, .5],
	[.6, .44],
	[.58, .34],
	[.62, .22],
	[.66, .1],
	[.64, .05],
	[.7, .05],
	[.72, .12],
	[.7, .24],
	[.74, .32],
	[.84, .36],
	[.86, .42],
	[.72, .44],
	[.6, .4],
	[.52, .46],
	[.46, .56],
	[.4, .64],
	[.32, .62],
	[.28, .66],
	[.3, .74],
	[.36, .78],
	[.42, .8]
];
var PHASES = [
	{
		id: "I",
		name: "Feasibility & Baseline Mapping",
		window: "Months 1–6",
		months: "Apr–Sep 2026",
		progress: .38,
		status: "active",
		objectives: [
			{
				id: "i1",
				text: "Lake Mead hydrological baseline (pool, shear, sediment)",
				done: true
			},
			{
				id: "i2",
				text: "Multi-sensor terrain grid over Boulder City theater",
				done: true
			},
			{
				id: "i3",
				text: "Zero-trust telemetry provenance on EDGE-01",
				done: true
			},
			{
				id: "i4",
				text: "Subpart H tanker surge model, MC-406 family",
				done: false
			},
			{
				id: "i5",
				text: "NIST SP 800-171 control mapping (14 families)",
				done: false
			},
			{
				id: "i6",
				text: "Degraded-comms store-and-forward rehearsal",
				done: false
			}
		]
	},
	{
		id: "II",
		name: "Prototype Fabrication & Field Testing",
		window: "Months 7–14",
		months: "Oct 2026–May 2027",
		progress: 0,
		status: "planned",
		objectives: [
			{
				id: "ii1",
				text: "Autonomous sensor units, edge-AI anomaly filter",
				done: false
			},
			{
				id: "ii2",
				text: "Rough-terrain LCV stability on US-93 grades",
				done: false
			},
			{
				id: "ii3",
				text: "GPR retune and Railroad Pass EMI mitigation",
				done: false
			},
			{
				id: "ii4",
				text: "Cross-sensor fusion against MAG ferrous baseline",
				done: false
			}
		]
	},
	{
		id: "III",
		name: "Defense Integration & Operational Demonstration",
		window: "Months 15–24",
		months: "Jun 2027–Mar 2028",
		progress: 0,
		status: "planned",
		objectives: [
			{
				id: "iii1",
				text: "Common operating picture integration",
				done: false
			},
			{
				id: "iii2",
				text: "Anomaly tracking exercise with civil partners",
				done: false
			},
			{
				id: "iii3",
				text: "Manufacturing blueprint and dual-use transition",
				done: false
			}
		]
	}
];
var NIST_FAMILIES = [
	{
		id: "3.1",
		name: "Access Control",
		aligned: 18,
		controls: 22,
		note: "Least privilege on edge nodes"
	},
	{
		id: "3.2",
		name: "Awareness & Training",
		aligned: 3,
		controls: 3,
		note: "Internal PI-led briefings"
	},
	{
		id: "3.3",
		name: "Audit & Accountability",
		aligned: 8,
		controls: 9,
		note: "Provenance log complete"
	},
	{
		id: "3.4",
		name: "Configuration Management",
		aligned: 6,
		controls: 9,
		note: "Code freeze pending PA"
	},
	{
		id: "3.5",
		name: "Identification & Authentication",
		aligned: 9,
		controls: 11,
		note: "OIDC / OAuth 2.0"
	},
	{
		id: "3.6",
		name: "Incident Response",
		aligned: 2,
		controls: 3,
		note: "Playbook in draft"
	},
	{
		id: "3.7",
		name: "Maintenance",
		aligned: 3,
		controls: 6,
		note: "Field cal cycle defined"
	},
	{
		id: "3.8",
		name: "Media Protection",
		aligned: 4,
		controls: 9,
		note: "No CUI on public interfaces"
	},
	{
		id: "3.9",
		name: "Personnel Security",
		aligned: 2,
		controls: 2,
		note: "Sole-prop screening"
	},
	{
		id: "3.10",
		name: "Physical Protection",
		aligned: 4,
		controls: 6,
		note: "Clarice Lane controlled"
	},
	{
		id: "3.11",
		name: "Risk Assessment",
		aligned: 2,
		controls: 3,
		note: "Theater risk register live"
	},
	{
		id: "3.12",
		name: "Security Assessment",
		aligned: 2,
		controls: 4,
		note: "Internal only"
	},
	{
		id: "3.13",
		name: "System & Comms Protection",
		aligned: 11,
		controls: 16,
		note: "Zero-trust overlay"
	},
	{
		id: "3.14",
		name: "System & Info Integrity",
		aligned: 5,
		controls: 7,
		note: "Signed telemetry"
	}
];
var CALIBRATION = [
	{
		instrument: "LiDAR IMU bias",
		node: "LIDAR-01",
		last: "2026-09-12",
		next: "2026-12-12",
		residual: "0.04°",
		standard: "NIST-traceable tilt"
	},
	{
		instrument: "LiDAR range",
		node: "LIDAR-02",
		last: "2026-09-12",
		next: "2026-12-12",
		residual: "8 mm @ 100 m",
		standard: "EDM pillar"
	},
	{
		instrument: "HSI radiometric",
		node: "HSI-01",
		last: "2026-08-28",
		next: "2026-11-28",
		residual: "1.8% refl.",
		standard: "Spectralon panel"
	},
	{
		instrument: "HSI wavelength",
		node: "HSI-02",
		last: "2026-08-28",
		next: "2026-11-28",
		residual: "1.1 nm",
		standard: "HgAr lamp"
	},
	{
		instrument: "GPR dielectric",
		node: "GPR-01",
		last: "2026-09-04",
		next: "2026-12-04",
		residual: "εr ±0.3",
		standard: "Known sand pit"
	},
	{
		instrument: "GPR timing",
		node: "GPR-02",
		last: "2026-09-04",
		next: "2026-10-04",
		residual: "0.6 ns",
		standard: "Air-launch target"
	},
	{
		instrument: "Mag diurnal",
		node: "MAG-02",
		last: "2026-09-20",
		next: "2026-10-20",
		residual: "3 nT",
		standard: "Overhauser base"
	},
	{
		instrument: "Mag heading",
		node: "MAG-01",
		last: "2026-09-20",
		next: "2026-12-20",
		residual: "0.2°",
		standard: "Declination mark"
	},
	{
		instrument: "ADCP velocity",
		node: "HYDRO-01",
		last: "2026-09-01",
		next: "2026-12-01",
		residual: "1.2 cm/s",
		standard: "Tow-tank transfer"
	},
	{
		instrument: "Stage datum",
		node: "HYDRO-02",
		last: "2026-07-15",
		next: "2027-01-15",
		residual: "6 mm",
		standard: "USBR BM"
	}
];
var MANIFEST = [
	{
		file: "EXCALIBUR_Directive.pdf",
		sha: "7c91e2a4b0f6d18c",
		size: "184 KB",
		role: "Program directive"
	},
	{
		file: "Technical_Abstract.pdf",
		sha: "12ab90c3e5d44701",
		size: "96 KB",
		role: "CSO abstract"
	},
	{
		file: "Authority_Certificate.pdf",
		sha: "9d44f0aa17ce62b8",
		size: "41 KB",
		role: "Signature authority"
	},
	{
		file: "Compliance_Matrix.xlsx",
		sha: "c3e018f59aa21d07",
		size: "128 KB",
		role: "NIST 800-171 / Subpart H"
	},
	{
		file: "Calibration_Data.csv",
		sha: "55b1d0e9c4a83f12",
		size: "22 KB",
		role: "Instrument residuals"
	},
	{
		file: "package_excalibur.sh",
		sha: "e08c77b2d1a94f30",
		size: "4 KB",
		role: "Archive script"
	},
	{
		file: "ZIP_MANIFEST.txt",
		sha: "a1c2d3e4f5061728",
		size: "2 KB",
		role: "This index"
	}
];
var AUDIT_VERBS = [
	"PROV",
	"AUTH",
	"FRAME",
	"ANOM",
	"ROUTE",
	"CAL",
	"SYNC",
	"DENY"
];
function nxToLon(x) {
	return BOUNDS.west + x * (BOUNDS.east - BOUNDS.west);
}
function nyToLat(y) {
	return BOUNDS.north + y * (BOUNDS.south - BOUNDS.north);
}
function surgeMargin(fill, latG) {
	const slosh = Math.sin(Math.PI * fill);
	const cgRise = Math.max(0, fill - .55) * .45;
	const sloshPenalty = slosh * .38 * latG;
	return .42 - latG - sloshPenalty - cgRise * latG;
}
function lcvAmplification(speedMph, articulation) {
	return 1 + speedMph / 65 * .35 + articulation * .55;
}
function lookupEntity(id) {
	if (SENSORS.some((s) => s.id === id)) return {
		kind: "sensor",
		id
	};
	if (CONVOYS.some((c) => c.id === id)) return {
		kind: "convoy",
		id
	};
	if (SITES.some((s) => s.id === id)) return {
		kind: "site",
		id
	};
	return null;
}
var DEFAULT_OVERLAYS = {
	lidar: true,
	hsi: true,
	gpr: true,
	mag: true,
	hydro: true,
	logistics: true,
	grid: true
};
var useExcalibur = create((set) => ({
	overlays: { ...DEFAULT_OVERLAYS },
	selectedId: "EDGE-01",
	tick: 0,
	hoverId: null,
	simLatG: .18,
	simFill: .62,
	simSpeed: 48,
	toggleOverlay: (id) => set((s) => ({ overlays: {
		...s.overlays,
		[id]: !s.overlays[id]
	} })),
	setSelected: (id) => set({ selectedId: id }),
	setHover: (id) => set({ hoverId: id }),
	bumpTick: () => set((s) => ({ tick: s.tick + 1 })),
	setSim: (partial) => set(partial)
}));
var NAV = [
	{
		to: "/",
		label: "COP",
		icon: Crosshair
	},
	{
		to: "/sensors",
		label: "Sensors",
		icon: Radio
	},
	{
		to: "/logistics",
		label: "Logistics",
		icon: Truck
	},
	{
		to: "/telemetry",
		label: "Telemetry",
		icon: Shield
	},
	{
		to: "/mission",
		label: "Mission",
		icon: Flag
	},
	{
		to: "/package",
		label: "Package",
		icon: FileStack
	},
	{
		to: "/doctrine",
		label: "Doctrine",
		icon: Lightbulb
	}
];
function Shell({ children }) {
	const bumpTick = useExcalibur((s) => s.bumpTick);
	const phase = PHASES[0];
	(0, import_react.useEffect)(() => {
		const id = window.setInterval(bumpTick, 1e3);
		return () => window.clearInterval(id);
	}, [bumpTick]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh min-h-0 flex-col bg-bg text-fg print:h-auto print:overflow-visible",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "bg-alert/15 px-3 py-1.5 text-center font-mono text-xs uppercase tracking-widest text-alert print:hidden",
				children: [
					PROGRAM.classification,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-2 text-alert/50",
						children: "·"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-alert/80",
						children: PROGRAM.control
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "flex items-center gap-3 border-b border-line px-3 py-2.5 sm:px-4 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-w-0 items-center gap-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-8 shrink-0" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium tracking-widest",
							children: "EXCALIBUR"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate font-mono text-xs uppercase tracking-widest text-muted",
							children: "13 Aerospace Defense"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "ml-auto flex items-center gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "hidden text-right sm:block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs uppercase tracking-widest text-muted",
								children: ["Phase ", phase.id]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm tabular-nums text-fg",
								children: [
									formatPct(phase.progress),
									" · ",
									phase.window
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "caution",
							className: "hidden md:inline-flex",
							children: "Pre-decisional"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveClock, {})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex min-h-0 flex-1 flex-col md:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					"aria-label": "Primary",
					className: "flex shrink-0 gap-1 overflow-x-auto border-b border-line px-2 py-2 print:hidden md:w-16 md:flex-col md:items-center md:overflow-visible md:border-r md:border-b-0 md:px-2 md:py-3",
					children: NAV.map((item) => {
						const Icon = item.icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: item.to,
							activeOptions: item.to === "/" ? { exact: true } : void 0,
							className: cn("flex h-11 min-w-11 shrink-0 items-center justify-center gap-2 rounded-md px-3 text-sm text-muted transition-[background-color,color] duration-150 ease-out hover:bg-elevated hover:text-fg md:w-11 md:px-0"),
							activeProps: { className: "bg-elevated text-fg" },
							title: item.label,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
								className: "size-4",
								strokeWidth: 1.6
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "md:sr-only",
								children: item.label
							})]
						}, item.to);
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-h-0 min-w-0 flex-1 overflow-auto print:overflow-visible",
					children
				})]
			})
		]
	});
}
var styles_default = "/assets/styles-5G6LBPmb.css";
var APP_NAME = "EXCALIBUR";
var Route$7 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "theme-color",
				content: "#09090b"
			},
			{
				name: "description",
				content: "Project EXCALIBUR — 13 Aerospace Defense Company command console for terrain sensing, HazMat logistics, and zero-trust telemetry."
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	});
}
var $$splitComponentImporter$6 = () => import("./routes-k_e_ehqb.mjs");
var Route$6 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./doctrine-BB1dHVGM.mjs");
var Route$5 = createFileRoute("/doctrine")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./logistics-j3UxgOgR.mjs");
var Route$4 = createFileRoute("/logistics")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./mission-Cr4DGAG0.mjs");
var Route$3 = createFileRoute("/mission")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./package-EASNhmtH.mjs");
var Route$2 = createFileRoute("/package")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./sensors-BcFmkd1p.mjs");
var Route$1 = createFileRoute("/sensors")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./telemetry-ek5wVMUh.mjs");
var Route = createFileRoute("/telemetry")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$6.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$7
	}),
	DoctrineRoute: Route$5.update({
		id: "/doctrine",
		path: "/doctrine",
		getParentRoute: () => Route$7
	}),
	LogisticsRoute: Route$4.update({
		id: "/logistics",
		path: "/logistics",
		getParentRoute: () => Route$7
	}),
	MissionRoute: Route$3.update({
		id: "/mission",
		path: "/mission",
		getParentRoute: () => Route$7
	}),
	PackageRoute: Route$2.update({
		id: "/package",
		path: "/package",
		getParentRoute: () => Route$7
	}),
	SensorsRoute: Route$1.update({
		id: "/sensors",
		path: "/sensors",
		getParentRoute: () => Route$7
	}),
	TelemetryRoute: Route.update({
		id: "/telemetry",
		path: "/telemetry",
		getParentRoute: () => Route$7
	})
};
var routeTree = Route$7._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { formatPct as C, Mark as D, seededUnit as E, Badge as O, formatCoord as S, hashString as T, lcvAmplification as _, CITY_BLOCKS as a, nyToLat as b, LAKE_POLY as c, OVERLAYS as d, PHASES as f, SITES as g, SENSORS as h, CALIBRATION as i, cn as k, MANIFEST as l, ROADS as m, useExcalibur as n, CONVOYS as o, PROGRAM as p, AUDIT_VERBS as r, KIND_META as s, router_exports as t, NIST_FAMILIES as u, lookupEntity as v, formatZulu as w, surgeMargin as x, nxToLon as y };
