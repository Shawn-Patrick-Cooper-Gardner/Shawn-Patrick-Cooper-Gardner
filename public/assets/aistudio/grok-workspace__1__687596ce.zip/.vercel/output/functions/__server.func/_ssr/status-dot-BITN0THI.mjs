import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { k as cn } from "./router-NnI91c-F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-dot-BITN0THI.js
var import_jsx_runtime = require_jsx_runtime();
var tones = {
	nominal: "bg-ok",
	degraded: "bg-caution",
	offline: "bg-alert"
};
function StatusDot({ health, pulse, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-block size-1.5 shrink-0 rounded-full", tones[health], pulse && health === "nominal" && "pulse-live", className),
		"aria-hidden": "true"
	});
}
//#endregion
export { StatusDot as t };
