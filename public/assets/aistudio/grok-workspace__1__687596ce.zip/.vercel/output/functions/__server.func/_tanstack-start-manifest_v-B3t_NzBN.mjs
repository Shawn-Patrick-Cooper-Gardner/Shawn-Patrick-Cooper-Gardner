//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B3t_NzBN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/doctrine",
			"/logistics",
			"/mission",
			"/package",
			"/sensors",
			"/telemetry"
		],
		preloads: ["/assets/index-BfbubfZw.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BfbubfZw.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Bfnunszc.js",
			"/assets/chrome-BEqgWvi-.js",
			"/assets/live-BIhUHUXm.js",
			"/assets/status-dot-BQ8Z9kaN.js"
		]
	},
	"/doctrine": {
		filePath: "/workspace/src/routes/doctrine.tsx",
		children: void 0,
		preloads: [
			"/assets/doctrine-DQv6PEV_.js",
			"/assets/check-9f7Eiq7J.js",
			"/assets/chrome-BEqgWvi-.js"
		]
	},
	"/logistics": {
		filePath: "/workspace/src/routes/logistics.tsx",
		children: void 0,
		preloads: [
			"/assets/logistics-ZUNiTPfL.js",
			"/assets/chrome-BEqgWvi-.js",
			"/assets/generateCategoricalChart-BGlMmLdy.js"
		]
	},
	"/mission": {
		filePath: "/workspace/src/routes/mission.tsx",
		children: void 0,
		preloads: [
			"/assets/mission-wQBh67RK.js",
			"/assets/check-9f7Eiq7J.js",
			"/assets/chrome-BEqgWvi-.js"
		]
	},
	"/package": {
		filePath: "/workspace/src/routes/package.tsx",
		children: void 0,
		preloads: ["/assets/package-Hk9CKuXY.js", "/assets/chrome-BEqgWvi-.js"]
	},
	"/sensors": {
		filePath: "/workspace/src/routes/sensors.tsx",
		children: void 0,
		preloads: [
			"/assets/sensors-BI9j_uDw.js",
			"/assets/chrome-BEqgWvi-.js",
			"/assets/live-BIhUHUXm.js",
			"/assets/status-dot-BQ8Z9kaN.js"
		]
	},
	"/telemetry": {
		filePath: "/workspace/src/routes/telemetry.tsx",
		children: void 0,
		preloads: [
			"/assets/telemetry-DmCQ8zaj.js",
			"/assets/chrome-BEqgWvi-.js",
			"/assets/live-BIhUHUXm.js",
			"/assets/generateCategoricalChart-BGlMmLdy.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
