import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { k as cn } from "./router-NnI91c-F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/chrome-Cy9Zw8CL.js
var import_jsx_runtime = require_jsx_runtime();
function Panel({ className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: cn("rounded-xl bg-surface p-4 shadow-panel", className),
		children
	});
}
function Kicker({ children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("font-mono text-xs uppercase tracking-widest text-muted", className),
		children
	});
}
function Metric({ label, value, hint, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: label }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("mt-1 font-medium tabular-nums tracking-tight", tone === "ok" ? "text-ok" : tone === "caution" ? "text-caution" : tone === "alert" ? "text-alert" : "text-fg"),
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-subtle",
				children: hint
			}) : null
		]
	});
}
function PageHeader({ kicker, title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: kicker }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "mt-1 text-2xl font-medium tracking-tight text-fg",
			children: title
		})] }), children]
	});
}
//#endregion
export { Panel as i, Metric as n, PageHeader as r, Kicker as t };
