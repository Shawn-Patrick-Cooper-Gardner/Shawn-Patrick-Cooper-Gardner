import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as formatPct, O as Badge, _ as lcvAmplification, k as cn, n as useExcalibur, o as CONVOYS, x as surgeMargin } from "./router-NnI91c-F.mjs";
import { i as Panel, n as Metric, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
import { a as Line, c as ResponsiveContainer, i as XAxis, l as Tooltip, n as LineChart, o as CartesianGrid, r as YAxis } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/logistics-j3UxgOgR.js
var import_jsx_runtime = require_jsx_runtime();
function surgeSeries(latG) {
	const out = [];
	for (let i = 5; i <= 95; i += 5) {
		const fill = i / 100;
		out.push({
			fill: i,
			margin: Number(surgeMargin(fill, latG).toFixed(3)),
			zero: 0
		});
	}
	return out;
}
function LogisticsPage() {
	const simLatG = useExcalibur((s) => s.simLatG);
	const simFill = useExcalibur((s) => s.simFill);
	const simSpeed = useExcalibur((s) => s.simSpeed);
	const setSim = useExcalibur((s) => s.setSim);
	const selectedId = useExcalibur((s) => s.selectedId);
	const setSelected = useExcalibur((s) => s.setSelected);
	const data = surgeSeries(simLatG);
	const margin = surgeMargin(simFill, simLatG);
	const amp = lcvAmplification(simSpeed, 1.15);
	const rearG = simLatG * amp;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "49 CFR Subpart H · cargo tank",
				title: "HazMat logistics model",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm text-muted",
					children: "Tanker surge and LCV rearward amplification for the US-93 / I-11 theater. Partial fill is the free-surface case."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Surge margin",
						value: `${margin.toFixed(2)} g`,
						tone: margin < .05 ? "alert" : margin < .12 ? "caution" : "ok",
						hint: "Rollover threshold 0.42 g"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Rearward amp",
						value: `${amp.toFixed(2)}×`,
						hint: `${rearG.toFixed(2)} g at trailer`
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Fill / lateral",
						value: `${formatPct(simFill)} · ${simLatG.toFixed(2)} g`
					}) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "lg:col-span-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Stability margin vs fill" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 mb-4 text-sm text-muted",
							children: "Worst free-surface near 50% fill. High fill raises CG; empty tanks are stiff."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-64",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
									data,
									margin: {
										top: 8,
										right: 8,
										left: 0,
										bottom: 0
									},
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
											stroke: "var(--color-line)",
											strokeDasharray: "3 3"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
											dataKey: "fill",
											tick: {
												fill: "var(--color-muted)",
												fontSize: 12
											},
											axisLine: { stroke: "var(--color-line)" },
											tickLine: false,
											unit: "%"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
											tick: {
												fill: "var(--color-muted)",
												fontSize: 12
											},
											axisLine: false,
											tickLine: false,
											domain: ["auto", "auto"],
											unit: " g"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
											contentStyle: {
												background: "var(--color-elevated)",
												border: "1px solid var(--color-line)",
												borderRadius: 8,
												color: "var(--color-fg)",
												fontFamily: "IBM Plex Mono, monospace",
												fontSize: 12
											},
											formatter: (value) => [`${Number(value).toFixed(2)} g`, "margin"],
											labelFormatter: (label) => `Fill ${label}%`
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
											type: "monotone",
											dataKey: "margin",
											stroke: "var(--color-accent)",
											strokeWidth: 2,
											dot: false
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
											type: "monotone",
											dataKey: "zero",
											stroke: "var(--color-alert)",
											strokeDasharray: "4 4",
											strokeWidth: 1,
											dot: false
										})
									]
								})
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex flex-col gap-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Run parameters" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs uppercase tracking-widest text-muted",
								children: [
									"Lateral acceleration · ",
									simLatG.toFixed(2),
									" g"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .05,
								max: .36,
								step: .01,
								value: simLatG,
								onChange: (e) => setSim({ simLatG: Number(e.target.value) }),
								className: "mt-2 w-full accent-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs uppercase tracking-widest text-muted",
								children: ["Tank fill · ", formatPct(simFill)]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: .15,
								max: .95,
								step: .01,
								value: simFill,
								onChange: (e) => setSim({ simFill: Number(e.target.value) }),
								className: "mt-2 w-full accent-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs uppercase tracking-widest text-muted",
								children: [
									"LCV speed · ",
									simSpeed,
									" mph"
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: 20,
								max: 70,
								step: 1,
								value: simSpeed,
								onChange: (e) => setSim({ simSpeed: Number(e.target.value) }),
								className: "mt-2 w-full accent-accent"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Rocky Mountain Double, 48 ft + 28 ft. Rearward amplification grows with speed and articulation on the Hoover grade."
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "border-b border-line px-4 py-3",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Active movements" })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-line",
					children: CONVOYS.map((c) => {
						const m = surgeMargin(c.fill, simLatG);
						const active = selectedId === c.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setSelected(c.id),
							className: cn("flex w-full flex-col gap-1 px-4 py-3 text-left transition-[background-color] duration-150 ease-out hover:bg-elevated sm:flex-row sm:items-center sm:gap-4", active && "bg-elevated"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-24 font-medium",
									children: c.callsign
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex-1 text-sm text-muted",
									children: [
										c.cargo,
										" · ",
										c.un,
										" · ",
										c.tank
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-mono text-xs tabular-nums text-muted",
									children: ["fill ", formatPct(c.fill)]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: m < .05 ? "alert" : m < .12 ? "caution" : "ok",
									children: [m.toFixed(2), " g"]
								})
							]
						}) }, c.id);
					})
				})]
			})
		]
	});
}
//#endregion
export { LogisticsPage as component };
