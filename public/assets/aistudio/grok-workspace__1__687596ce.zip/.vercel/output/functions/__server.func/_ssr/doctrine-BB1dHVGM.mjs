import { i as __toESM } from "../_runtime.mjs";
import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { d as Copy, f as Check, l as Download } from "../_libs/lucide-react.mjs";
import { D as Mark, O as Badge, T as hashString, k as cn } from "./router-NnI91c-F.mjs";
import { i as Panel, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/doctrine-BB1dHVGM.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-wide outline-none select-none transition-[background-color,color,box-shadow,opacity,scale] duration-150 ease-out focus-visible:shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)] disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-fg",
			outline: "bg-transparent text-fg shadow-panel hover:shadow-panel-hover hover:bg-elevated",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-elevated",
			subtle: "bg-elevated text-fg hover:bg-line"
		},
		size: {
			sm: "h-9 rounded-sm px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			icon: "size-11 rounded-md",
			iconSm: "size-9 rounded-sm"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
var AUTHORITY = {
	superStackVersion: "2.0",
	documentControl: "EXCALIBUR-AFW-2026-DIR01",
	effective: "2026-08-14T22:38:00 PDT",
	organization: {
		entityName: "13 Aerospace Defence Company",
		entityType: "Private-Sector Technical Authority",
		principalArchitect: "Shawn Patrick Cooper Gardner",
		jurisdiction: "Boulder City, Nevada, United States",
		operationalScope: "Cloud-AI Systems, Identity Governance, Zero-Trust Architecture",
		pecSafety: "00711617",
		orcid: "0009-0004-6464-7791",
		govinfoTag: "SPCG-13ADC"
	},
	executive: {
		holder: "Shawn Patrick Cooper Gardner",
		role: "Principal Cloud Architect & System Owner",
		mandate: [
			"Full architectural authority over cloud-AI systems",
			"Governance of identity, IAM, and federated access",
			"Enforcement of zero-trust principles",
			"Oversight of audit logging and provenance systems",
			"Compliance alignment with NIST SP 800-171"
		]
	},
	technical: [
		"Define and maintain cloud-AI architecture",
		"Design and enforce IAM and federated identity policies",
		"Control deployment of AI workloads and services",
		"Approve changes to VPC, KMS, BigQuery, Cloud Run"
	],
	governance: [
		"Establish and maintain AI usage policies",
		"Align systems with NIST SP 800-171 and zero-trust principles",
		"Ensure auditability, logging, and provenance of AI workloads"
	],
	identity: {
		model: "Federated (OIDC / OAuth 2.0)",
		providers: ["Google Cloud IAM", "Controlled service accounts"],
		requirements: [
			"No anonymous AI endpoints",
			"All AI calls authenticated and authorized",
			"Workloads bound to controlled identities"
		]
	},
	constraints: [
		"No elevation beyond defined IAM roles",
		"No public unauthenticated access",
		"No bypass of logging or provenance controls"
	],
	disclaimer: "Internal organizational authority only. No governmental or regulatory authority implied.",
	license: "CC BY 4.0"
};
var SES_MTQ = {
	title: "SES MTQ Statement",
	subtitle: "Designer / Cartographer Internship",
	program: "Undergraduate Internship / Co-op Program",
	applicant: "Shawn Patrick Cooper Gardner",
	location: "Boulder City, Nevada",
	citizenship: "U.S. Citizen, applicant-stated",
	targetRole: "Designer / Cartographer Internship",
	objective: "To contribute design, cartographic, and visual communication skills to an undergraduate internship/co-op environment supporting Earth-science, geospatial, technical-visualization, and related mission activities.",
	experience: [
		"Produced structured graphic layouts using typography, grid-based design, white-space management, and color-theory principles.",
		"Developed interactive UI/UX samples demonstrating clear navigation, visual hierarchy, and responsive-design principles.",
		"Created map-aligned visual materials and geospatial products using consistent coordinate systems and structured metadata.",
		"Designed visual documentation for technical workflows, emphasizing clarity, accuracy, and operational readability.",
		"Built QR-encoded payloads and mobile-ready visual assets for controlled technical environments."
	],
	skills: "Typography; grid-based layout; color theory; white-space discipline; UI/UX design; cartographic visualization; geospatial alignment; structured documentation; technical workflow rendering.",
	education: {
		diploma: "High School Diploma / Equivalency: completed foundational education.",
		development: "Ongoing independent technical and design-focused professional training in geospatial metadata integration, systems architecture, and visual communication."
	},
	alignment: [
		"Cartographic products and services.",
		"Geographic information systems (GIS).",
		"Geospatial data and remote sensing.",
		"Earth-science visualization and technical communication.",
		"Earth-observation imagery and Landsat-related activities.",
		"Natural-resource and environmental information management.",
		"Education and internship-oriented scientific training."
	],
	usgsContext: [
		"USGS / USDA Forest Service agreement on production, exchange, and dissemination of cartographic products and services.",
		"USGS / USDA Forest Service interagency agreement on production and maintenance of a primary-series quadrangle map.",
		"USGS / DOD / NIMA agreement on geospatial data and remote sensing.",
		"USGS / Air Force Space Command agreement on planning and operational cooperation, information sharing, and regional GIS data serving federal, civil, state, and tribal authorities.",
		"USGS / University of Nevada-Reno agreement on a USGS Reno Field Office associated with the Mackay School of Mines and Nevada Bureau of Mines and Geology.",
		"USGS / Colorado School of Mines MOU signed August 2023, stated to expire 21 August 2028.",
		"USGS / NAGT Cooperative Summer Field Training Program: a mechanism through which qualified undergraduates from university field camps could apply for USGS internships.",
		"NASA / USGS Landsat-related agreements on Earth observation, remote sensing, data processing, archiving, distribution, and related scientific activities."
	],
	evidenceBoundary: [
		"USGS employment",
		"USGS affiliation",
		"a USGS internship",
		"a federal appointment",
		"a federal credential",
		"a security clearance",
		"government authority",
		"a contractual relationship with USGS or another federal agency"
	],
	eo13526: "Executive Order 13526 is included as a governance reference concerning the federal classification, safeguarding, and declassification system for national-security information. The EO reference is not evidence that the applicant possesses classified information, classification authority, a security clearance, classified employment, or classified-project access. No classification status should be inferred from the existence of this reference.",
	positioning: {
		mission: "Design and cartographic skills applicable to activities involving cartographic products, geographic information systems, remote sensing, Earth-science visualization, geospatial data management, and technical visual communication.",
		objective: "Contribute design, cartographic visualization, GIS-oriented visual communication, and technical documentation skills within an undergraduate internship/co-op environment supporting Earth-science and geospatial missions."
	},
	validation: [
		{
			label: "Applicant claims",
			value: "Applicant-stated"
		},
		{
			label: "USGS institutional context",
			value: "Documented contextual material for alignment analysis"
		},
		{
			label: "Executive Order 13526",
			value: "Governance reference only"
		},
		{
			label: "Federal employment",
			value: "Not established"
		},
		{
			label: "Federal affiliation",
			value: "Not established"
		},
		{
			label: "Security clearance",
			value: "Not established"
		},
		{
			label: "Government authority",
			value: "Not established"
		}
	],
	controlRule: "Applicant claims and institutional background material must not be converted into verified federal status without independent authoritative evidence."
};
function sesMarkdown() {
	const s = SES_MTQ;
	return [
		`# ${s.title}`,
		`## ${s.subtitle}`,
		`### ${s.program}`,
		``,
		`**Applicant:** ${s.applicant}`,
		`**Location:** ${s.location}`,
		`**Citizenship:** ${s.citizenship}`,
		`**Target role:** ${s.targetRole}`,
		``,
		`## Objective`,
		``,
		s.objective,
		``,
		`## Relevant Experience`,
		``,
		...s.experience.map((e) => `- ${e}`),
		``,
		`## Core Skills`,
		``,
		s.skills,
		``,
		`## Education & Development`,
		``,
		s.education.diploma,
		``,
		s.education.development,
		``,
		`## Mission Alignment`,
		``,
		...s.alignment.map((a, i) => `${i + 1}. ${a}`),
		``,
		`## Particularly Relevant USGS Context`,
		``,
		...s.usgsContext.map((u) => `- ${u}`),
		``,
		`## Evidence Boundary`,
		``,
		`The USGS agreement material documents institutional relationships and mission activities. It does **not** establish that the applicant personally has or had:`,
		``,
		...s.evidenceBoundary.map((e) => `- ${e}`),
		``,
		`## Executive Order 13526 Reference`,
		``,
		s.eo13526,
		``,
		`## Recommended Application Positioning`,
		``,
		`### Mission Alignment`,
		``,
		s.positioning.mission,
		``,
		`### Internship Objective`,
		``,
		s.positioning.objective,
		``,
		`## Validation Status`,
		``,
		...s.validation.map((v) => `${v.label}: ${v.value}.`),
		``,
		`## Evidence-Control Rule`,
		``,
		s.controlRule,
		``
	].join("\n");
}
var TIPS_CONTROL = "13ADC-DIR-TIPS-2026";
var TIPS_BADGE = [
	"=========================================",
	"  13ADC  EXCALIBUR  PRE-DECISIONAL",
	"  DIR-TIPS-2026  ·  NIST 800-171",
	"========================================="
].join("\n");
var TIP_CATEGORIES = [
	{
		id: "ALL",
		label: "All"
	},
	{
		id: "CHECKLIST",
		label: "Checklist"
	},
	{
		id: "ENGINEERING",
		label: "Engineering"
	},
	{
		id: "PROPOSAL",
		label: "Proposal"
	},
	{
		id: "TERMINAL",
		label: "Terminal"
	},
	{
		id: "SECURITY",
		label: "Security"
	},
	{
		id: "PRINTING",
		label: "Printing"
	}
];
var TIPS = [
	{
		n: 1,
		tag: "PHASE BLUEPRINT",
		title: "End-to-End Deployment Roadmap",
		ref: "EXCALIBUR-AFW-2026-DEP-RM01",
		category: "CHECKLIST",
		body: "Moves EXCALIBUR across 8 structured phases: Pre-Award Google AI Studio prototyping → Award Entra tenant provisioning → Azure zero-trust architecture → Defense COP integration → Nevada basin field deployment → TRL-6 NNSS demonstration → Contract manufacturing → Fleet sustainment.",
		directive: "8-Phase Transition: Concept Sandbox → Entra Authority → Azure Defense → TRL-6"
	},
	{
		n: 2,
		tag: "PRE-RELEASE AUDIT",
		title: "Final ZIP Review Checklist",
		ref: "EXCALIBUR-AFW-2026-ZIP-CHK01",
		category: "CHECKLIST",
		body: "Before authorizing package release, step through the 7-section checklist: verify core submission slides, authority certificates, calibration datasets, and run automated Termux integrity tests.",
		directive: "Document Reference: EXCALIBUR-AFW-2026-ZIP-CHK01 | 7 Verification Sections"
	},
	{
		n: 3,
		tag: "NEXT ACTION",
		title: "Unified EXCALIBUR Technical Volume",
		ref: "Forward Action Milestone",
		category: "CHECKLIST",
		body: "Consolidates all system engineering blueprints, interface control specifications (ICD-26-09), and empirical spectroscopic baselines into one authoritative defense acquisition binder upon contract award.",
		directive: "Next Forward Milestone: Technical Volume Binder & SED-26-09 Synchronization"
	},
	{
		n: 4,
		tag: "MECHANICAL DYNAMICS",
		title: "13ADC C.O.R.E. Rough-Terrain Mechanical Dynamics",
		ref: "C.O.R.E.",
		category: "ENGINEERING",
		body: "Company Off-road Racing Engineering (C.O.R.E.) standards ruggedize field sensor nodes against severe vibrations, high dust ingestion, and acute thermal swings across off-road desert proving grounds.",
		directive: "C.O.R.E. Standards: Desert Hardening, Shock Isolation & Mobile Telemetry Rigs"
	},
	{
		n: 5,
		tag: "HAZMAT LADING",
		title: "Subpart H HazMat Lading & Hydrodynamic Physics Grounding",
		ref: "3355 E. Carey",
		category: "PROPOSAL",
		body: "Grounded in 2013 Subpart H HazMat Lading certification (3355 E. Carey Infrastructure), mathematical fluid surge damping models and Longer Combination Vehicle (LCV) dynamics provide physical stability baselines for heavy subterranean sensor node deployment.",
		directive: "2013 Subpart H HazMat Certified (3355 E. Carey) | Tanker Surge Physics"
	},
	{
		n: 6,
		tag: "OPTICAL HERITAGE",
		title: "Lake Mead Project 288 Optical Telemetry Lineage",
		ref: "Project 288",
		category: "PROPOSAL",
		body: "Descended from the 1948 Lake Mead high-altitude Sun Tracker platform, Project 288 telemetry provides empirical baselines for sun-angle differential atmospheric refraction across desert-lacustrine fault zones.",
		directive: "Lake Mead Baseline: 1948 Optical Heritage + High-Salinity Aquifer Coupling"
	},
	{
		n: 7,
		tag: "TERRAIN CALIBRATION",
		title: "Nevada Basin Lacustrine Fault-Line & Aquifer Calibration",
		ref: "Lake Mead waveguide",
		category: "ENGINEERING",
		body: "The high-salinity subterranean hydronic veins of Lake Mead serve as natural waveguides for dielectric flux, enabling repeatable signal-to-noise indexing before deploying into contested environments.",
		directive: "Lacustrine Fault Lines: Subterranean Waveguides for Dielectric Flux Calibration"
	},
	{
		n: 8,
		tag: "FEDERAL COMPLIANCE",
		title: "AFWERX & Federal Submission Prerequisites",
		ref: "SAM.gov / DSIP",
		category: "PROPOSAL",
		body: "To submit a live proposal to AFWERX CSO or SBIR/STTR programs, the applicant must possess an active SAM.gov registration (UEI & CAGE code) and an active Defense SBIR/STTR Innovation Portal (DSIP) account. Drafts must remain designated as PRE-DECISIONAL / INTERNAL until all official registration hurdles are complete.",
		directive: "Prerequisites: SAM.gov Active Status (UEI/CAGE) + DSIP Portal Access"
	},
	{
		n: 9,
		tag: "PRE-DECISIONAL",
		title: "Cover Sheet Designation & Pre-Decisional Status",
		ref: "Status banner",
		category: "PROPOSAL",
		body: "Official federal solicitations strictly disallow unauthorized logos or unverified registration codes. Retaining INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED ensures full compliance and prevents accidental representation as an already-awarded contract.",
		directive: "Status Banner: INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED"
	},
	{
		n: 10,
		tag: "BRIEFING SYNC",
		title: "Syncing COMPLETED_ABSTRACT.pptx Slide Deck",
		ref: "PPTX outline",
		category: "PROPOSAL",
		body: "Use the slide-notes download to get structured slide headers, talking points, and bullet layouts matching the written proposal sections. Paste into PowerPoint Outline View.",
		directive: "Download Outline → Paste into PowerPoint Outline View"
	},
	{
		n: 11,
		tag: "LOCAL ARCHIVE",
		title: "Local Markdown Archival & Git Tracking",
		ref: "GFM archive",
		category: "PROPOSAL",
		body: "Download Markdown or copy abstract text to save the proposal in local note archives (Obsidian, VS Code, or Git) for offline tracking.",
		directive: "Standard GitHub-flavored Markdown compatible with all tools"
	},
	{
		n: 12,
		tag: "PACKAGING VERIFY",
		title: "Termux Packaging & Checksum Verification",
		ref: "zip -9 -j",
		category: "TERMINAL",
		body: "After running zip -9 -j, always run sha256sum and unzip -t to verify the archive before transmission. A zero-error return code guarantees no corrupted payloads.",
		directive: "unzip -t verifies data integrity without unpacking"
	},
	{
		n: 13,
		tag: "CLI BRANDING",
		title: "ASCII Badge Embedding for CLI & Git Headers",
		ref: "41-character badge",
		category: "TERMINAL",
		body: "The Copy Badge action copies a standardized text block formatted for terminal banners, CLI MOTD, and Git repository headers.",
		directive: "Preserves fixed 41-character width formatting"
	},
	{
		n: 14,
		tag: "AIR-GAPPED STORAGE",
		title: "Air-Gapped & Local Filesystem Management",
		ref: "Termux tmp",
		category: "TERMINAL",
		body: "In Termux, store submission packages under /data/data/com.termux/files/usr/tmp or local storage before generating sha256sum checksums. This keeps working files isolated from public cloud sync.",
		directive: "Path: /data/data/com.termux/files/usr/tmp/DARPA-PS-26-09_submission"
	},
	{
		n: 15,
		tag: "IDENTITY TENANT",
		title: "Microsoft Entra Identity Tenant & Principal Architect Governance",
		ref: "Entra RBAC",
		category: "SECURITY",
		body: "Post-award provisioning maps Principal Architect Shawn Patrick Cooper Gardner to absolute executive cloud tenant authority, binding all AI microservices to dedicated service principals with Conditional Access.",
		directive: "Entra RBAC: Dedicated Defense Tenant + Principal Architect Role Authority"
	},
	{
		n: 16,
		tag: "HSM ENCRYPTION",
		title: "Azure Key Vault + HSM Hardware Cryptographic Signing",
		ref: "FIPS 140-2 L3",
		category: "SECURITY",
		body: "Telemetry packets ingested from mobile field sensors are signed at the Hardware Security Module (HSM) boundary, ensuring immutable origin attestation and anti-tamper validation.",
		directive: "Cryptographic Provenance: FIPS 140-2 Level 3 HSM Telemetry Signing"
	},
	{
		n: 17,
		tag: "COP INTEGRATION",
		title: "Defense Common Operational Picture (COP) Ingestion Feeds",
		ref: "Signed protobuf",
		category: "ENGINEERING",
		body: "EXCALIBUR streams feed into standard military COP tactical consoles via signed protobuf payloads, providing real-time subsurface and atmospheric transition visualization without latency spikes.",
		directive: "COP Feeds: Sub-Second Telemetry Ingestion via Signed Protobuf Payloads"
	},
	{
		n: 18,
		tag: "TRL-6 DEMONSTRATION",
		title: "TRL-6 Demonstration Protocols at NNSS / White Sands",
		ref: "NNSS Phase 6",
		category: "ENGINEERING",
		body: "The Phase 6 operational exercise at Nevada National Security Site executes live anomaly detection under high-contrast thermal gradients and simulated adversarial electronic jamming.",
		directive: "TRL-6 Milestone: Live Anomaly Tracking Under Electronic Jamming Stress"
	},
	{
		n: 19,
		tag: "ZERO-TRUST IAM",
		title: "Zero-Trust IAM Enforcement & No Anonymous Endpoints",
		ref: "NIST SP 800-171",
		category: "SECURITY",
		body: "Always bind AI service endpoints to explicit federated identities (OIDC/OAuth 2.0). Reject all anonymous or unauthenticated API calls to comply with NIST SP 800-171 guidelines.",
		directive: "Least-privilege service accounts: cloudrun-identity & ai-governance"
	},
	{
		n: 20,
		tag: "AUDIT PROVENANCE",
		title: "Tamper-Resistant Telemetry Logging & Audit Trails",
		ref: "Hardware timestamps",
		category: "SECURITY",
		body: "Maintain immutable audit logs with hardware-backed timestamps. Any unexpected permission elevation attempts should trigger automatic containment and immediate alerting.",
		directive: "Continuous perimeter logging aligned with NIST SP 800-171"
	},
	{
		n: 21,
		tag: "PUBLIC INTERFACE",
		title: "Zero CUI / Non-ITAR Public Interface Sanitization",
		ref: "No CUI",
		category: "SECURITY",
		body: "Verify that no Controlled Unclassified Information (CUI), classified materials, or ITAR-controlled designs are ever pasted into public AI prompts or web interfaces. Keep all operational proposals strictly internal and unclassified.",
		directive: "Zero CUI / Non-ITAR Guarantee: Public Domain & Pre-Decisional Only"
	},
	{
		n: 22,
		tag: "SAFETY PROTOCOL",
		title: "PEC Safety Certification 00711617 Field Protocols",
		ref: "PEC 00711617",
		category: "ENGINEERING",
		body: "All field testing rigs, high-mass sensor anchors, and lacustrine survey nodes adhere to strict PEC safety compliance, ensuring accident-free execution across steep desert fault lines.",
		directive: "PEC Safety Cert: 00711617 | Zero-Incident Rigging & Logistics Standard"
	},
	{
		n: 23,
		tag: "NAICS CLASSIFICATION",
		title: "NAICS 541715 R&D Accounting & SBIR Cost Accounting",
		ref: "NAICS 541715",
		category: "PROPOSAL",
		body: "Work performed under NAICS 541715 (Research and Development in the Physical, Engineering, and Life Sciences) maintains segregated phase-by-phase cost ledgering matching DARPA SOW milestones.",
		directive: "NAICS 541715: Segregated R&D Accounting Aligned with Federal FAR Rules"
	},
	{
		n: 24,
		tag: "PDF PRINT SETTINGS",
		title: "High-Fidelity PDF Generation Settings",
		ref: "Background graphics",
		category: "PRINTING",
		body: "When printing or saving as PDF, enable Background graphics in the browser print dialog so borders, seals, and watermark crests render with crisp contrast.",
		directive: "Print Dialog → More Settings → Check “Background graphics”"
	},
	{
		n: 25,
		tag: "PAGE MARGINS",
		title: "Standard US Letter & Margins Alignment",
		ref: "US Letter / A4",
		category: "PRINTING",
		body: "The print layout is calibrated for US Letter (8.5\" × 11\") and A4 portrait. Setting margins to Default or Minimum gives a balanced presentation without awkward page breaks.",
		directive: "Paper Size: US Letter / A4 | Margins: Default"
	},
	{
		n: 26,
		tag: "SHORTCUTS",
		title: "Keyboard Shortcuts & Fast Action Triggers",
		ref: "Ctrl/Cmd+P",
		category: "PRINTING",
		body: "Press Ctrl+P (or Cmd+P on macOS) to launch the high-resolution printable layout. Press Esc to dismiss expanded tips. Use one-click Copy for clipboard ingestion.",
		directive: "Print: Ctrl+P / Cmd+P | Close: Esc | Copy: 1-click clipboard"
	}
];
function tipsMarkdown() {
	const lines = [
		`# 13 Aerospace Defense Company`,
		`## Operational & Technical Lightbulb Tips Compendium`,
		``,
		`**Document control:** ${TIPS_CONTROL}`,
		`**Principal Cloud Architect:** Shawn Patrick Cooper Gardner`,
		`**Total active tips:** ${TIPS.length}`,
		`**Governance:** Zero-Trust | NIST SP 800-171 aligned`,
		`**Status:** INTERNAL — PRE-DECISIONAL — NOT YET SUBMITTED`,
		``,
		`This compendium consolidates operational, technical, logistical, and architectural tips developed across Project EXCALIBUR, DARPA-PS-26-09, AFWERX CSO, and Microsoft Entra / Azure zero-trust governance.`,
		``
	];
	for (const t of TIPS) {
		lines.push(`### ${t.n}. [${t.tag}] ${t.title}`);
		lines.push(`**Category:** ${t.category}  `);
		lines.push(`**Reference:** ${t.ref}`);
		lines.push(``);
		lines.push(t.body);
		lines.push(``);
		lines.push(`> **Directive:** \`${t.directive}\``);
		lines.push(``);
	}
	lines.push(`---`, ``, `*Authorized by Shawn Patrick Cooper Gardner, Principal Cloud Architect & System Owner, 13 Aerospace Defense Company.*`, ``);
	return lines.join("\n");
}
var FPDS_CONTROL = "13ADC-DIR-FPDS-2026-PIID";
var FPDS_BOUNDARY = {
	title: "Evidence-control rule",
	lead: "These are public FPDS-NG records whose delivery-order PIID is the numeral 2026. That identifier is an order number on older IDIQ vehicles. It is not fiscal year 2026, not an AFWERX CSO award, and not Project EXCALIBUR.",
	notEstablished: [
		"an award to 13 Aerospace Defense Company",
		"an award to Shawn Patrick Cooper Gardner",
		"SAM.gov registration, UEI, or CAGE for the applicant",
		"AFWERX / SBIR / STTR selection or funding",
		"a current NAVSEA or NAVFAC contract",
		"NAICS 541715 performance history"
	],
	note: "Applicant claims and public award extracts must not be converted into verified federal status, past performance, or proposal eligibility without independent authoritative evidence."
};
var FPDS_AWARDS = [
	{
		id: "NAVSEA-2026-EDS",
		agency: "Dept of the Navy",
		officeId: "BZ006",
		office: "Naval Sea Systems Command",
		piid: "2026",
		idv: "N0002400D6000",
		signed: "2000-10-06",
		popStart: "2000-10-06",
		popEnd: "2001-09-30",
		type: "Fixed price",
		psc: "D399",
		pscLabel: "Other ADP & telecommunications services",
		naics: "541519",
		naicsLabel: "Other computer related services",
		place: "Herndon, Fairfax County, Virginia",
		country: "United States",
		competed: "Full and open competition",
		setAside: "No set aside used",
		awardType: "Delivery order",
		uei: "MBSRAWAQ9559",
		vendor: "Electronic Data Systems Corporation",
		parentUei: "SMLNZ8X9SHE7",
		parent: "Hewlett-Packard Company",
		address: "13600 EDS Drive, Herndon, VA 20171",
		size: "Other than small business",
		obligation: 32199
	},
	{
		id: "NAVFAC-2026-ALLSTAR",
		agency: "Dept of the Navy",
		officeId: "C2470",
		office: "Naval Facilities Engineering Command",
		piid: "2026",
		idv: "N0018795D6050",
		signed: "2000-10-27",
		popStart: "2000-10-27",
		popEnd: "2000-11-27",
		type: "Fixed price",
		psc: "Z161",
		pscLabel: "Maint-rep-alt / family housing",
		naics: "235990",
		naicsLabel: "All other special trade contractors",
		place: "Virginia Beach, Virginia",
		country: "United States",
		competed: "Full and open competition",
		setAside: "No set aside used",
		awardType: "Delivery order",
		uei: "NJ5DK8XBHVH1",
		vendor: "All Star Maintenance, Inc.",
		parentUei: "NJ5DK8XBHVH1",
		parent: "All Star Maintenance, Inc.",
		address: "12250 El Camino Real, San Diego, CA 92130",
		size: "Other than small business",
		obligation: 182
	},
	{
		id: "NAVFAC-2026-DG21",
		agency: "Dept of the Navy",
		officeId: "C2742",
		office: "Naval Facilities Engineering Command",
		piid: "2026",
		idv: "N6274298D4500",
		signed: "2003-08-25",
		popStart: "2003-08-25",
		popEnd: "2004-09-09",
		type: "Fixed price",
		psc: "S299",
		pscLabel: "Other housekeeping services",
		naics: "561210",
		naicsLabel: "Facilities support services",
		place: "British Indian Ocean Territory",
		country: "British Indian Ocean Territory",
		competed: "Full and open competition",
		setAside: "No set aside used",
		awardType: "Delivery order",
		uei: "W9NNLCGR6F18",
		vendor: "DG21 LLC",
		parentUei: "Z98HJ42NLET3",
		parent: "FirstGroup PLC",
		address: "14900 Landmark Boulevard, Dallas, TX 75254",
		size: "Other than small business",
		obligation: 350244
	},
	{
		id: "FECO-2026-YOKOSOH",
		agency: "Dept of the Navy",
		officeId: "C2836",
		office: "Far East Contracts Office",
		piid: "2026",
		idv: "N6283697D0118",
		signed: "2001-10-25",
		popStart: "2001-10-25",
		popEnd: "2001-10-31",
		type: "Firm fixed price",
		psc: "R499",
		pscLabel: "Other professional services",
		naics: "561210",
		naicsLabel: "Facilities support services",
		place: "Yokosuka, Japan",
		country: "Japan",
		competed: "Full and open competition",
		setAside: "No set aside used",
		awardType: "Delivery order",
		uei: "MYUZRWC5PVY5",
		vendor: "Yokosoh Co Ltd",
		parentUei: "MYUZRWC5PVY5",
		parent: "Yokosoh Co Ltd",
		address: "1-17-98 Morisaki, Yokosuka 238",
		size: "Other than small business",
		obligation: 53
	},
	{
		id: "NAVFAC-2026-SUDALLARM",
		agency: "Dept of the Navy",
		officeId: "C3191",
		office: "Naval Facilities Engineering Command",
		piid: "2026",
		idv: "N3319198D2216",
		signed: "2003-04-09",
		popStart: "2003-04-09",
		popEnd: "2003-05-09",
		type: "Fixed price",
		psc: "S202",
		pscLabel: "Fire protection services",
		naics: "561210",
		naicsLabel: "Facilities support services",
		place: "Napoli, Italy",
		country: "Italy",
		competed: "Full and open competition",
		setAside: "No set aside used",
		awardType: "Delivery order",
		uei: "K4KVJKY546X6",
		vendor: "Sud Allarm. di Lutricuso Aldo",
		parentUei: "K4KVJKY546X6",
		parent: "Lutricuso Aldo Allarm Sud",
		address: "Via Sartania 37 40, Napoli 80126",
		size: "Other than small business",
		obligation: 2701
	},
	{
		id: "NAVFAC-2026-JCWS",
		agency: "Dept of the Navy",
		officeId: "C4255",
		office: "Naval Facilities Engineering Field",
		piid: "2026",
		idv: "N4425595D6130",
		signed: "2002-04-11",
		popStart: "2002-04-11",
		popEnd: "2002-07-11",
		type: "Fixed price",
		psc: "S216",
		pscLabel: "Facilities operations support services",
		naics: null,
		naicsLabel: null,
		place: "Naval Submarine Base Bangor, Silverdale, Washington",
		country: "United States",
		competed: "Not in extract",
		setAside: "Not in extract",
		awardType: "Delivery order",
		uei: null,
		vendor: "Johnson Controls World Service",
		parentUei: null,
		parent: null,
		address: "Naval Subbase Bangor Bldg 10, Silverdale, WA",
		size: "Not in extract",
		obligation: null,
		incomplete: true
	}
];
function formatUsd(n) {
	if (n == null) return "Not in extract";
	return new Intl.NumberFormat("en-US", {
		style: "currency",
		currency: "USD",
		minimumFractionDigits: 2
	}).format(n);
}
function fpdsKnownObligation() {
	return FPDS_AWARDS.reduce((sum, a) => sum + (a.obligation ?? 0), 0);
}
function fpdsMarkdown() {
	const lines = [
		`# FPDS-NG extract — delivery-order PIID 2026`,
		``,
		`**Document control:** ${FPDS_CONTROL}`,
		`**Status:** INTERNAL — PRE-DECISIONAL — RESEARCH EXTRACT`,
		``,
		`## Evidence-control rule`,
		``,
		FPDS_BOUNDARY.lead,
		``,
		`This extract does **not** establish:`,
		``,
		...FPDS_BOUNDARY.notEstablished.map((e) => `- ${e}`),
		``,
		FPDS_BOUNDARY.note,
		``,
		`Known action obligation in this extract: ${formatUsd(fpdsKnownObligation())} across ${FPDS_AWARDS.filter((a) => a.obligation != null).length} of ${FPDS_AWARDS.length} rows.`,
		``
	];
	for (const a of FPDS_AWARDS) {
		lines.push(`### ${a.vendor} — ${a.officeId} / ${a.piid}`);
		lines.push(``);
		lines.push(`- Agency: ${a.agency} · ${a.office} (${a.officeId})`);
		lines.push(`- PIID: ${a.piid} against IDV ${a.idv}`);
		lines.push(`- Signed: ${a.signed} · PoP ${a.popStart} → ${a.popEnd}`);
		lines.push(`- Type: ${a.type} · ${a.awardType}`);
		lines.push(`- PSC: ${a.psc} ${a.pscLabel}`);
		lines.push(`- NAICS: ${a.naics ?? "Not in extract"} ${a.naicsLabel ?? ""}`.trim());
		lines.push(`- Place: ${a.place} (${a.country})`);
		lines.push(`- Competition: ${a.competed} · ${a.setAside}`);
		lines.push(`- UEI: ${a.uei ?? "Not in extract"}`);
		lines.push(`- Parent: ${a.parent ?? "Not in extract"}`);
		lines.push(`- Address: ${a.address}`);
		lines.push(`- Size: ${a.size}`);
		lines.push(`- Obligation: ${formatUsd(a.obligation)}${a.incomplete ? " (row truncated in source paste)" : ""}`);
		lines.push(``);
	}
	return lines.join("\n");
}
var ENGINE_CONTROL = "excalibur-core-engine-2026";
var GENESIS_DIGEST = "00000000";
var ENGINE = {
	id: "excalibur-core-engine-2026",
	version: "1.1",
	description: "Unified cognitive-provenance engine operating entirely within this EXCALIBUR console. Provides deterministic lineage, audit-ready structure, and PRE-DECISIONAL analysis for regulatory ingestion, provenance chaining, capability mapping, and operational logging.",
	operator: {
		name: "Shawn Patrick Cooper Gardner",
		role: "Principal Cloud Architect, 13 Aerospace Defense Company",
		workspace: "EXCALIBUR Cognitive Environment",
		identityTags: ["SPCG", "EXCALIBUR-Operator-1"]
	},
	engine: {
		mode: "cognitive-provenance",
		executionEnvironment: "Grok",
		persistence: "YAML-ledger",
		determinism: "strict",
		auditability: "full",
		classificationDefault: "PRE-DECISIONAL / INTERNAL TECHNICAL ANALYSIS"
	},
	dataSources: [
		{
			name: "GovInfo API",
			type: "public",
			ingestion: "textual",
			status: "Citations public · API not wired"
		},
		{
			name: "FederalRegister.gov",
			type: "public",
			ingestion: "textual",
			status: "Two 2026-09-29 citations checked · feed not wired"
		},
		{
			name: "GitHub Thread Metadata",
			type: "user-generated",
			ingestion: "structured",
			status: "Declared — not wired"
		},
		{
			name: "Grok Reasoning Layer",
			type: "LLM",
			ingestion: "semantic",
			status: "This console"
		}
	],
	/** Completes the truncated `provenance_chain.structure` that ended at `actor`. */
	chain: [
		"actor",
		"role",
		"action",
		"source",
		"ingestion",
		"artifact",
		"capability",
		"constraint",
		"timestamp",
		"digest",
		"parent_digest",
		"classification",
		"evidence_boundary",
		"workspace"
	],
	capabilities: [
		"Terrain-sensing COP (Lake Mead / Boulder City theater)",
		"HazMat tanker surge and LCV stability modeling",
		"Zero-trust telemetry visualization (NIST SP 800-171 aligned)",
		"AFWERX CSO internal binder (PRE-DECISIONAL)",
		"YAML provenance ledger with parent-digest chaining"
	],
	constraints: [
		"No elevation beyond defined IAM roles",
		"No public unauthenticated access",
		"No bypass of logging or provenance controls",
		"No CUI / ITAR on public interfaces",
		"No conversion of applicant claims into federal status"
	],
	license: "CC BY 4.0"
};
var ENGINE_BOUNDARY = {
	title: "Evidence-control rule",
	lead: "This metadata block describes an internal cognitive-provenance schema for EXCALIBUR. It does not create a federal system of record, a live GovInfo or Federal Register feed, or classification authority.",
	notEstablished: [
		"a government information system",
		"live GovInfo / Federal Register ingestion",
		"classification or declassification authority",
		"an official audit log admissible as federal evidence",
		"operator clearance, appointment, or agency affiliation"
	],
	note: "Declared sources remain declared until independently connected and verified. Digests fingerprint local console artifacts and chain to the prior digest. They are not a federal hash authority."
};
function digestOf(text) {
	return hashString(text).toString(16).padStart(8, "0");
}
var ACTOR = "SPCG / EXCALIBUR-Operator-1";
var ROLE = ENGINE.operator.role;
var WORKSPACE = ENGINE.operator.workspace;
var BOUNDARY = "Applicant-stated / local console only";
var CLASS = "PRE-DECISIONAL";
var SEEDS = [
	{
		id: "LED-000",
		action: "Genesis",
		source: "Engine schema",
		ingestion: "structured",
		artifact: "Chain genesis · parent 00000000",
		capability: "Deterministic lineage",
		constraint: ENGINE.constraints[2],
		timestamp: "2026-08-14T22:38:00Z",
		payload: `${ENGINE.id}|${ENGINE.version}|genesis`
	},
	{
		id: "LED-001",
		action: "Ingest",
		source: "Operator paste",
		ingestion: "textual",
		artifact: "13ADC-DIR-TIPS-2026 · 26 tips",
		capability: ENGINE.capabilities[3],
		constraint: ENGINE.constraints[3],
		timestamp: "2026-10-01T12:00:00Z",
		payload: tipsMarkdown()
	},
	{
		id: "LED-002",
		action: "Attest",
		source: "Operator paste",
		ingestion: "structured",
		artifact: "Super-stack 2.0 authority certificate",
		capability: "Identity governance (internal)",
		constraint: ENGINE.constraints[0],
		timestamp: "2026-10-01T12:05:00Z",
		payload: "EXCALIBUR-AFW-2026-DIR01|super-stack-2.0"
	},
	{
		id: "LED-003",
		action: "Ingest",
		source: "Operator paste",
		ingestion: "textual",
		artifact: "SES MTQ · Designer / Cartographer internship",
		capability: "Cartographic / geospatial alignment (applicant-stated)",
		constraint: ENGINE.constraints[4],
		timestamp: "2026-10-01T12:10:00Z",
		payload: sesMarkdown()
	},
	{
		id: "LED-004",
		action: "Ingest",
		source: "FPDS-NG extract",
		ingestion: "structured",
		artifact: "Navy DO PIID 2026 · 6 rows (1 truncated)",
		capability: "Public-award research extract",
		constraint: ENGINE.constraints[4],
		timestamp: "2026-10-01T12:20:00Z",
		payload: fpdsMarkdown()
	},
	{
		id: "LED-005",
		action: "Lockup",
		source: "Brand pass",
		ingestion: "semantic",
		artifact: "13 geometric mark · Lake Mead share card",
		capability: "Visual identity",
		constraint: ENGINE.constraints[3],
		timestamp: "2026-10-06T18:10:00Z",
		payload: "13ADC-lockup|EXCALIBUR|09090B"
	},
	{
		id: "LED-006",
		action: "Declare",
		source: "Operator paste",
		ingestion: "structured",
		artifact: "excalibur-core-engine-2026 metadata block v1.0 (truncated at actor)",
		capability: ENGINE.capabilities[4],
		constraint: ENGINE.constraints[2],
		timestamp: "2026-10-06T18:16:00Z",
		payload: `${ENGINE.id}|1.0|cognitive-provenance|actor`
	},
	{
		id: "LED-007",
		action: "Extend",
		source: "Operator directive",
		ingestion: "structured",
		artifact: "Provenance chain completed · 14-node structure + parent digest",
		capability: ENGINE.capabilities[4],
		constraint: ENGINE.constraints[2],
		timestamp: "2026-10-06T18:39:00Z",
		payload: ENGINE.chain.join("|")
	},
	{
		id: "LED-008",
		action: "Ingest",
		source: "Operator paste",
		ingestion: "textual",
		artifact: "excalibur-govinfo-fr-2026-09-29 · two FR citations, authority redacted",
		capability: "Regulatory lineage (public citations only)",
		constraint: ENGINE.constraints[3],
		timestamp: "2026-10-08T01:44:00Z",
		payload: "excalibur-govinfo-fr-2026-09-29|2026-19929|2026-19884|REDACTED"
	},
	{
		id: "LED-009",
		action: "Hold",
		source: "Operator paste",
		ingestion: "structured",
		artifact: "a56-fox total migration · STAGE_5 queued · not dispatched",
		capability: "Staged request only",
		constraint: ENGINE.constraints[1],
		timestamp: "2026-10-08T01:48:00Z",
		payload: "a56-fox|HOLD|PKCS7_CERT_TOKEN|NOT_ESTABLISHED"
	}
];
function buildLedger(seeds) {
	let parent = GENESIS_DIGEST;
	return seeds.map((s) => {
		const digest = digestOf(`${parent}|${s.id}|${s.payload}`);
		const row = {
			id: s.id,
			actor: ACTOR,
			role: ROLE,
			action: s.action,
			source: s.source,
			ingestion: s.ingestion,
			artifact: s.artifact,
			capability: s.capability,
			constraint: s.constraint,
			timestamp: s.timestamp,
			digest,
			parentDigest: parent,
			classification: CLASS,
			evidenceBoundary: BOUNDARY,
			workspace: WORKSPACE
		};
		parent = digest;
		return row;
	});
}
var ENGINE_LEDGER = buildLedger(SEEDS);
function engineHead() {
	return ENGINE_LEDGER[ENGINE_LEDGER.length - 1];
}
function engineYaml() {
	const src = ENGINE.dataSources.map((s) => `    - name: "${s.name}"\n      type: "${s.type}"\n      ingestion: "${s.ingestion}"\n      status: "${s.status}"`).join("\n");
	const chain = ENGINE.chain.map((c) => `      - ${c}`).join("\n");
	const caps = ENGINE.capabilities.map((c) => `    - "${c}"`).join("\n");
	const cons = ENGINE.constraints.map((c) => `    - "${c}"`).join("\n");
	const ledger = ENGINE_LEDGER.map((r) => [
		`    - id: ${r.id}`,
		`      actor: "${r.actor}"`,
		`      role: "${r.role}"`,
		`      action: ${r.action}`,
		`      source: "${r.source}"`,
		`      ingestion: ${r.ingestion}`,
		`      artifact: "${r.artifact}"`,
		`      capability: "${r.capability}"`,
		`      constraint: "${r.constraint}"`,
		`      timestamp: ${r.timestamp}`,
		`      digest: ${r.digest}`,
		`      parent_digest: ${r.parentDigest}`,
		`      classification: ${r.classification}`,
		`      evidence_boundary: "${r.evidenceBoundary}"`,
		`      workspace: "${r.workspace}"`
	].join("\n")).join("\n");
	const head = engineHead();
	return [
		`EXCALIBUR_Metadata_Block:`,
		`  id: ${ENGINE.id}`,
		`  version: "${ENGINE.version}"`,
		`  description: >`,
		`    ${ENGINE.description}`,
		``,
		`  operator:`,
		`    name: "${ENGINE.operator.name}"`,
		`    role: "${ENGINE.operator.role}"`,
		`    workspace: "${ENGINE.operator.workspace}"`,
		`    identity_tags:`,
		...ENGINE.operator.identityTags.map((t) => `      - "${t}"`),
		``,
		`  engine:`,
		`    mode: "${ENGINE.engine.mode}"`,
		`    execution_environment: "${ENGINE.engine.executionEnvironment}"`,
		`    persistence: "${ENGINE.engine.persistence}"`,
		`    determinism: "${ENGINE.engine.determinism}"`,
		`    auditability: "${ENGINE.engine.auditability}"`,
		`    classification_default: "${ENGINE.engine.classificationDefault}"`,
		``,
		`  data_sources:`,
		src,
		``,
		`  provenance_chain:`,
		`    structure:`,
		chain,
		`    genesis_digest: ${GENESIS_DIGEST}`,
		`    head_id: ${head.id}`,
		`    head_digest: ${head.digest}`,
		``,
		`  capability_map:`,
		caps,
		``,
		`  execution_constraints:`,
		cons,
		``,
		`  ledger:`,
		ledger,
		``,
		`  evidence_boundary:`,
		`    rule: "${ENGINE_BOUNDARY.lead}"`,
		`    not_established:`,
		...ENGINE_BOUNDARY.notEstablished.map((e) => `      - "${e}"`),
		``,
		`  license: "${ENGINE.license}"`,
		`  disclaimer: "${ENGINE_BOUNDARY.lead}"`,
		``
	].join("\n");
}
var FR_RECORD = {
	id: "excalibur-govinfo-fr-2026-09-29",
	version: "1.0",
	title: "Provenance record for Federal Register / GovInfo retrieval — administrative practice and procedure (special)",
	createdAt: "2026-09-29T00:00:00Z",
	lastModified: "2026-09-29T13:00:00Z",
	createdBy: {
		name: "Shawn Patrick Cooper Gardner",
		role: "Principal Cloud Architect, 13 Aerospace Defense Company",
		location: "803 Clarice Ln, Boulder City, Nevada, USA"
	},
	classification: "PRE-DECISIONAL / INTERNAL TECHNICAL ANALYSIS",
	exportControl: "Not ITAR / Not EAR-controlled",
	pii: "Minimal — actor identity only",
	retention: "Retain until superseded; review annually",
	visibility: "private",
	roles: [
		"Principal Cloud Architect",
		"Compliance Officer",
		"Security Lead"
	],
	artifactPath: "metadata/provenance/excalibur-govinfo-fr-2026-09-29.yaml",
	authority: {
		label: "Directive on Intelligence Superiority",
		rawValue: "[REDACTED]",
		vaultRef: "vault://provenance/authority/daI-2026-09-29",
		hashNote: "Source paste showed a truncated sha256 beginning e3b0c44298. That prefix is the empty-string digest and the rest was ellipsized. It is not treated as a verified authority hash."
	},
	systems: [
		{
			name: "GovInfo API",
			authority: "U.S. Government Publishing Office",
			base: "https://api.govinfo.gov",
			mode: "read-only",
			key: "vault reference only — never stored here"
		},
		{
			name: "FederalRegister.gov",
			authority: "Office of the Federal Register",
			base: "https://www.federalregister.gov",
			mode: "read-only",
			key: "none"
		},
		{
			name: "EXCALIBUR documentation workspace",
			authority: "13 Aerospace Defense Company",
			base: "excalibur-docs-main",
			mode: "read-write",
			key: "none"
		}
	],
	documents: [{
		id: "2026-19929",
		citation: "91 FR 61308",
		title: "Recodification of Title IX Rules",
		agency: "Department of Education, Office for Civil Rights",
		action: "Final rule",
		date: "2026-09-29",
		url: "https://www.federalregister.gov/documents/2026/09/29/2026-19929/recodification-of-title-ix-rules",
		check: "Citation confirmed against the published Federal Register text",
		plain: "Education repeals the 2024 Title IX rule in the Code of Federal Regulations and puts the earlier text back, with a few small edits. It took effect the day it was published."
	}, {
		id: "2026-19884",
		citation: "91 FR 61324",
		title: "Sodium Salt of Acifluorfen; Pesticide Tolerance",
		agency: "Environmental Protection Agency",
		action: "Final rule",
		date: "2026-09-29",
		url: "https://www.govinfo.gov/content/pkg/FR-2026-09-29/html/2026-19884.htm",
		check: "Citation confirmed against the published Federal Register text",
		plain: "EPA sets a residue tolerance of 0.06 ppm for sodium salt of acifluorfen on sugar-beet roots and drops older emergency-exemption tolerances."
	}],
	plannedQuery: {
		id: "govinfo-fr-search-genius-act",
		query: "GENIUS Act 2026-19860 2026-19899",
		status: "Expected search only — no result set was supplied or verified"
	},
	transformation: {
		id: "fr-subscription-to-excalibur-capability-matrix",
		type: "Manual interpretation and structuring",
		output: "excalibur-docs-main:Capability_Matrix.md",
		rationale: "Map these regulatory actions onto EXCALIBUR capabilities and compliance boundaries.",
		timestamp: "2026-09-29T12:00:00Z",
		note: "The capability matrix file was named as an output. It is not in this console."
	},
	integrity: [{
		id: "fr-citation-verification",
		status: "done for the two citations above"
	}, {
		id: "govinfo-endpoint-availability",
		status: "pending — API key stays in a vault, not here"
	}],
	signature: {
		ref: "sig://excalibur/provenance/2026-09-29",
		signer: "Shawn-Patrick-Cooper-Gardner",
		algorithm: "RSA-SHA256",
		status: "Reference only — no signature bytes were supplied"
	},
	opsec: [
		"No raw authority token in this console.",
		"No API keys. Vault names only.",
		"No chat or provenance text is piped into a control system.",
		"A person stays in the loop. Automation triggers are an empty allowlist."
	]
};
/** Staged curl. Not dispatched. Token is a placeholder, not a certificate. */
var MIGRATION_HOLD = {
	id: "a56-fox",
	control: "STAGE_5_CURL_QUEUED",
	status: "HOLD — not dispatched",
	received: "2026-10-08T01:48:00Z",
	method: "POST",
	url: "https://api.13adc.gov/v1/migration/execute/a56-fox",
	headers: {
		authorization: "Bearer <PKCS7_CERT_TOKEN>",
		contentType: "application/json",
		vibeCode: "MH55_AFMC_13ADC_IO26",
		targetProject: "p-a-t-13-98670851"
	},
	body: {
		migrationType: "TOTAL_MIGRATION",
		source: "CURRENT_TABLET_TERMUX_SESSION",
		destination: "1401_MADRONE_HQ",
		securityProtocol: "PKCS7_V5.9_DOD_CERTIFIED",
		license: "BSD_CLAUSE_3_PRODUCTION",
		device: {
			model: "WHOOP_TAB-8US2_11_HW_1.0",
			serial: "AF312TYQ23073108072",
			role: "CURRENT_AND_ONLY_AVAILABLE_DEVICE",
			termuxConfirmed: true
		},
		labels: {
			dodMetadata: "VERIFIED_DOD",
			dodStatus: "EXECUTIVE_AFFIRMED_AUTHORITATIVE",
			verification: "ATTESTED_UNDER_13ADC_EXECUTIVE_DIRECTIVE",
			externalVerification: "NOT_ESTABLISHED"
		}
	},
	holdReasons: [
		"The request’s own status is hold pending dispatch release.",
		"External verification is NOT_ESTABLISHED. DoD and executive-affirmed labels are self-attested only.",
		"The bearer is the placeholder <PKCS7_CERT_TOKEN>, not a certificate.",
		"api.13adc.gov is not a confirmed 13ADC or federal endpoint. A .gov host is not created by naming it.",
		"This console does not send migration or actuator commands."
	]
};
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		return false;
	}
}
function downloadText(filename, text, type = "text/markdown") {
	const blob = new Blob([text], { type: `${type};charset=utf-8` });
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = filename;
	a.click();
	URL.revokeObjectURL(url);
}
var TABS = [
	{
		id: "tips",
		label: "Tips"
	},
	{
		id: "authority",
		label: "Authority"
	},
	{
		id: "ses",
		label: "SES MTQ"
	},
	{
		id: "fpds",
		label: "FPDS"
	},
	{
		id: "engine",
		label: "Engine"
	}
];
function DoctrinePage() {
	const [tab, setTab] = (0, import_react.useState)("tips");
	const kicker = tab === "engine" ? `${ENGINE_CONTROL} · v${ENGINE.version}` : tab === "fpds" ? `${FPDS_CONTROL} · PIID 2026` : tab === "ses" ? "Undergraduate internship / co-op" : tab === "authority" ? "Super-stack 2.0 · internal authority" : `${TIPS_CONTROL} · 26 active`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl flex-col gap-6 p-4 sm:p-6 print:max-w-none print:p-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker,
				title: "Doctrine",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2 print:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => window.print(),
						children: "Print"
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto print:hidden",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("h-11 shrink-0 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out", tab === t.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-panel hover:text-fg"),
					children: t.label
				}, t.id))
			}),
			tab === "tips" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TipsPane, {}) : null,
			tab === "authority" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthorityPane, {}) : null,
			tab === "ses" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SesPane, {}) : null,
			tab === "fpds" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FpdsPane, {}) : null,
			tab === "engine" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnginePane, {}) : null
		]
	});
}
function TipsPane() {
	const [cat, setCat] = (0, import_react.useState)("ALL");
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(1);
	const [copied, setCopied] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape") setOpen(null);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const rows = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		return TIPS.filter((t) => {
			if (cat !== "ALL" && t.category !== cat) return false;
			if (!needle) return true;
			return `${t.n} ${t.tag} ${t.title} ${t.body} ${t.directive} ${t.ref}`.toLowerCase().includes(needle);
		});
	}, [cat, q]);
	async function copy(id, text) {
		if (await copyText(text)) {
			setCopied(id);
			window.setTimeout(() => setCopied((c) => c === id ? null : c), 1400);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3 print:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-widest text-muted",
						children: "Active"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums",
						children: TIPS.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-widest text-muted",
						children: "Showing"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums",
						children: rows.length
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-widest text-muted",
						children: "Standard"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm",
						children: "NIST SP 800-171 · Zero-trust"
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 print:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "search",
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Search tips, directives, references",
						className: "h-11 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-panel outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1",
						children: TIP_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCat(c.id),
							"aria-pressed": cat === c.id,
							className: cn("h-11 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out", cat === c.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-panel hover:text-fg"),
							children: c.label
						}, c.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => downloadText("13ADC-DIR-TIPS-2026.md", tipsMarkdown()),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-3.5",
									strokeWidth: 1.6
								}), "Download .md"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => copy("md", tipsMarkdown()),
								children: [copied === "md" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy abstract"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => copy("badge", TIPS_BADGE),
								children: [copied === "badge" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy badge"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								size: "sm",
								onClick: () => downloadText("EXCALIBUR-slide-notes.txt", slideNotes(), "text/plain"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
									className: "size-3.5",
									strokeWidth: 1.6
								}), "PPTX notes"]
							})
						]
					})
				]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No tips match that filter."
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: rows.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TipCard, {
					tip: t,
					open: open === t.n,
					onToggle: () => setOpen(open === t.n ? null : t.n),
					copied,
					onCopy: copy
				}, t.n))
			})
		]
	});
}
function TipCard({ tip, open, onToggle, copied, onCopy }) {
	const id = `tip-${tip.n}`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: cn("p-0", open && "shadow-panel-hover"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			"aria-expanded": open,
			className: "flex w-full items-start gap-3 px-4 py-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 shrink-0 font-mono text-xs tabular-nums text-muted",
				children: String(tip.n).padStart(2, "0")
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-wrap items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium",
						children: tip.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: tip.category })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block font-mono text-xs text-subtle",
					children: [
						"[",
						tip.tag,
						"] · ",
						tip.ref
					]
				})]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-line px-4 py-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: tip.body
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 rounded-md bg-elevated px-3 py-2 font-mono text-xs text-fg",
					children: tip.directive
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 print:hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						onClick: () => onCopy(id, tip.directive),
						children: [copied === id ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy directive"]
					})
				})
			]
		}) : null]
	}) });
}
function slideNotes() {
	return TIPS.map((t) => `Slide ${t.n}: ${t.title}\n[${t.tag}] ${t.category}\n- ${t.body}\n- Directive: ${t.directive}\n`).join("\n");
}
function AuthorityPane() {
	const a = AUTHORITY;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-6 sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: a.documentControl }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 font-mono text-xs text-muted",
							children: ["Super-stack ", a.superStackVersion]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-alert",
							children: "Internal organizational authority only"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-8 text-2xl font-medium tracking-tight",
				children: "Authority certificate"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-xl text-sm text-muted",
				children: a.disclaimer
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Entity",
						value: a.organization.entityName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Type",
						value: a.organization.entityType
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Principal architect",
						value: a.organization.principalArchitect
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Role",
						value: a.executive.role
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Jurisdiction",
						value: a.organization.jurisdiction
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Scope",
						value: a.organization.operationalScope
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "PEC safety",
						value: a.organization.pecSafety
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "ORCID",
						value: a.organization.orcid
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "GovInfo tag",
						value: a.organization.govinfoTag
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Effective",
						value: a.effective
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Identity model",
						value: a.identity.model
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "License",
						value: a.license
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 grid gap-6 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
						title: "Executive mandate",
						items: a.executive.mandate
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
						title: "Technical scope",
						items: a.technical
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
						title: "Governance",
						items: a.governance
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
						title: "Identity requirements",
						items: a.identity.requirements
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
					title: "Execution constraints",
					items: a.constraints
				})
			})
		]
	});
}
function SesPane() {
	const s = SES_MTQ;
	const [copied, setCopied] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => downloadText("SES_MTQ_Statement.md", sesMarkdown()),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
						className: "size-3.5",
						strokeWidth: 1.6
					}), "Download .md"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: async () => {
						if (await copyText(sesMarkdown())) {
							setCopied(true);
							window.setTimeout(() => setCopied(false), 1400);
						}
					},
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy statement"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-l-2 border-l-caution p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Evidence-control rule" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm leading-relaxed",
					children: s.controlRule
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-6 sm:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: s.program }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-2 text-2xl font-medium tracking-tight",
						children: s.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-muted",
						children: s.subtitle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Applicant",
								value: s.applicant
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Location",
								value: s.location
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Citizenship",
								value: s.citizenship
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Target role",
								value: s.targetRole
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Objective",
						children: s.objective
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Relevant experience",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-2 pl-5",
							children: s.experience.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: e }, e))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Core skills",
						children: s.skills
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Education & development",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: s.education.diploma }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2",
							children: s.education.development
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Mission alignment",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-muted",
							children: "Applicant-stated design and geospatial skills are potentially relevant to documented USGS institutional activities involving:"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "list-decimal space-y-1 pl-5",
							children: s.alignment.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: a }, a))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Particularly relevant USGS context",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-3 text-muted",
							children: "The supplied inventory is institutional context for alignment analysis. It does not confer applicant status."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "list-disc space-y-2 pl-5",
							children: s.usgsContext.map((u) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: u }, u))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Evidence boundary",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mb-3",
							children: [
								"USGS agreement material documents institutional relationships. It does",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-medium",
									children: "not"
								}),
								" establish that the applicant personally has or had:"
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "grid gap-1 sm:grid-cols-2",
							children: s.evidenceBoundary.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "rounded-sm bg-elevated px-3 py-2 text-sm",
								children: e
							}, e))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Executive Order 13526",
						children: s.eo13526
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Section, {
						title: "Recommended positioning",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "Mission alignment"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: s.positioning.mission
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 font-medium",
								children: "Internship objective"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: s.positioning.objective
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Section, {
						title: "Validation status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
							className: "divide-y divide-line border-y border-line",
							children: s.validation.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-1 py-2.5 sm:flex-row sm:items-baseline sm:gap-6",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "w-56 shrink-0 font-mono text-xs uppercase tracking-widest text-muted",
									children: v.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", { children: v.value })]
							}, v.label))
						})
					})
				]
			})
		]
	});
}
function FpdsPane() {
	const [q, setQ] = (0, import_react.useState)("");
	const [open, setOpen] = (0, import_react.useState)(FPDS_AWARDS[0]?.id ?? null);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const rows = (0, import_react.useMemo)(() => {
		const needle = q.trim().toLowerCase();
		if (!needle) return FPDS_AWARDS;
		return FPDS_AWARDS.filter((a) => `${a.vendor} ${a.parent ?? ""} ${a.office} ${a.idv} ${a.psc} ${a.pscLabel} ${a.naics ?? ""} ${a.naicsLabel ?? ""} ${a.place} ${a.country}`.toLowerCase().includes(needle));
	}, [q]);
	const known = fpdsKnownObligation();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-l-2 border-l-caution p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: FPDS_BOUNDARY.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed",
						children: FPDS_BOUNDARY.lead
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: "This extract does not establish:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid gap-1 sm:grid-cols-2",
						children: FPDS_BOUNDARY.notEstablished.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-sm bg-elevated px-3 py-2 text-sm",
							children: e
						}, e))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: FPDS_BOUNDARY.note
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3 print:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-widest text-muted",
							children: "Rows"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-2xl font-medium tabular-nums",
							children: FPDS_AWARDS.length
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-subtle",
							children: "All PIID 2026 · FY00–FY04"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-widest text-muted",
							children: "Known obligation"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-2xl font-medium tabular-nums",
							children: formatUsd(known)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-0.5 text-xs text-subtle",
							children: [
								FPDS_AWARDS.filter((a) => a.obligation != null).length,
								" of ",
								FPDS_AWARDS.length,
								" ",
								"rows complete"
							]
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs uppercase tracking-widest text-muted",
							children: "EXCALIBUR NAICS"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-2xl font-medium tabular-nums",
							children: "541715"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-0.5 text-xs text-subtle",
							children: "No match in this extract"
						})
					] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					type: "search",
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "Search vendor, office, NAICS, place",
					className: "h-11 w-full rounded-md bg-surface px-3 text-sm text-fg shadow-panel outline-none placeholder:text-subtle focus-visible:shadow-[0_0_0_2px_var(--color-bg),0_0_0_4px_var(--color-accent)]"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: () => downloadText("13ADC-DIR-FPDS-2026-PIID.md", fpdsMarkdown()),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
							className: "size-3.5",
							strokeWidth: 1.6
						}), "Download .md"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						size: "sm",
						onClick: async () => {
							if (await copyText(fpdsMarkdown())) {
								setCopied(true);
								window.setTimeout(() => setCopied(false), 1400);
							}
						},
						children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy extract"]
					})]
				})]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No awards match that filter."
			}) }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: rows.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FpdsCard, {
					award: a,
					open: open === a.id,
					onToggle: () => setOpen(open === a.id ? null : a.id)
				}, a.id))
			})
		]
	});
}
function FpdsCard({ award, open, onToggle }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: cn("p-0", open && "shadow-panel-hover"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onToggle,
			"aria-expanded": open,
			className: "flex w-full items-start gap-3 px-4 py-3 text-left",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-16 shrink-0 font-mono text-xs tabular-nums text-muted",
				children: award.signed.slice(0, 4)
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: award.vendor
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: award.psc }),
						award.incomplete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "caution",
							children: "Incomplete"
						}) : null
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-0.5 block font-mono text-xs text-subtle",
					children: [
						award.officeId,
						" · ",
						award.idv,
						" · ",
						formatUsd(award.obligation)
					]
				})]
			})]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-t border-line px-4 py-4",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "grid gap-x-8 gap-y-3 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Office",
						value: `${award.office} (${award.officeId})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Agency",
						value: award.agency
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "PIID",
						value: `${award.piid} against ${award.idv}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Award type",
						value: `${award.awardType} · ${award.type}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Signed",
						value: award.signed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Period of performance",
						value: `${award.popStart} → ${award.popEnd}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "PSC",
						value: `${award.psc} ${award.pscLabel}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "NAICS",
						value: award.naics ? `${award.naics} ${award.naicsLabel ?? ""}`.trim() : "Not in extract"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Place",
						value: `${award.place} (${award.country})`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Competition",
						value: `${award.competed} · ${award.setAside}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "UEI",
						value: award.uei ?? "Not in extract"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Parent",
						value: award.parent ?? "Not in extract"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Address",
						value: award.address
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Size",
						value: award.size
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Action obligation",
						value: formatUsd(award.obligation)
					})
				]
			}), award.incomplete ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-xs text-caution",
				children: "Source paste truncated at vendor address. Obligation and NAICS were not in the supplied row."
			}) : null]
		}) : null]
	}) });
}
function EnginePane() {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(engineHead().id);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-l-2 border-l-caution p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: ENGINE_BOUNDARY.title }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed",
						children: ENGINE_BOUNDARY.lead
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: "This block does not establish:"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 grid gap-1 sm:grid-cols-2",
						children: ENGINE_BOUNDARY.notEstablished.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "rounded-sm bg-elevated px-3 py-2 text-sm",
							children: e
						}, e))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: ENGINE_BOUNDARY.note
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-6 sm:p-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "text-right",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: ENGINE.id }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs text-muted",
									children: ["v", ENGINE.version]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-alert",
									children: ENGINE.engine.classificationDefault
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 text-2xl font-medium tracking-tight",
						children: "Cognitive provenance engine"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted",
						children: ENGINE.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-8 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Operator",
								value: ENGINE.operator.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Role",
								value: ENGINE.operator.role
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Workspace",
								value: ENGINE.operator.workspace
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Tags",
								value: ENGINE.operator.identityTags.join(" · ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Mode",
								value: ENGINE.engine.mode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Environment",
								value: ENGINE.engine.executionEnvironment
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Persistence",
								value: ENGINE.engine.persistence
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Determinism / audit",
								value: `${ENGINE.engine.determinism} · ${ENGINE.engine.auditability}`
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: ENGINE.dataSources.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: [
						s.type,
						" · ",
						s.ingestion
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-medium",
						children: s.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: s.status
					})
				] }, s.name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
					title: "Capability map",
					items: ENGINE.capabilities
				}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ListBlock, {
					title: "Execution constraints",
					items: ENGINE.constraints
				}) })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Provenance chain · 14 nodes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Completes the truncated structure that ended at actor. Each ledger row hashes the prior digest."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-xs text-subtle",
					children: [
						"GENESIS ",
						GENESIS_DIGEST,
						" → HEAD ",
						engineHead().digest
					]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 flex flex-wrap gap-2",
				children: ENGINE.chain.map((step, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex h-11 items-center rounded-md bg-elevated px-3 font-mono text-xs uppercase tracking-widest",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mr-2 text-subtle",
						children: String(i + 1).padStart(2, "0")
					}), step.replaceAll("_", " ")]
				}, step))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: FR_RECORD.id }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-lg font-medium tracking-tight",
							children: "What this record actually is"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "caution",
							children: "Authority redacted"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-3xl text-sm leading-relaxed text-muted",
						children: "On 29 September 2026 the operator wrote down a retrieval of two public Federal Register rules and a planned GovInfo search. The rules are real and public. The API key, the authority token, and the signature are not in this console. Nothing here is a live federal feed."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex flex-col gap-3",
						children: FR_RECORD.documents.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-md bg-elevated px-4 py-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-medium",
									children: [
										d.citation,
										" · ",
										d.title
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: d.plain
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 font-mono text-xs text-subtle",
									children: [
										d.id,
										" · ",
										d.agency,
										" · ",
										d.check
									]
								})
							]
						}, d.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Planned search",
								value: FR_RECORD.plannedQuery.query
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Search status",
								value: FR_RECORD.plannedQuery.status
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Authority label",
								value: FR_RECORD.authority.label
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Authority token",
								value: FR_RECORD.authority.rawValue
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Vault pointer",
								value: FR_RECORD.authority.vaultRef
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Hash note",
								value: FR_RECORD.authority.hashNote
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Signature",
								value: `${FR_RECORD.signature.algorithm} · ${FR_RECORD.signature.status}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Named output",
								value: FR_RECORD.transformation.output
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-1 text-sm text-muted",
						children: FR_RECORD.opsec.map((rule) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: rule }, rule))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
				className: "border-l-2 border-l-alert p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-start justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: MIGRATION_HOLD.control }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-2 text-lg font-medium tracking-tight",
							children: "Migration a56-fox is held"
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: "alert",
							children: MIGRATION_HOLD.status
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-mono text-xs text-muted",
						children: MIGRATION_HOLD.url
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-1.5 text-sm",
						children: MIGRATION_HOLD.holdReasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: reason }, reason))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-6 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Type",
								value: MIGRATION_HOLD.body.migrationType
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Source",
								value: MIGRATION_HOLD.body.source
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Destination",
								value: MIGRATION_HOLD.body.destination
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Project",
								value: MIGRATION_HOLD.headers.targetProject
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Vibe code",
								value: MIGRATION_HOLD.headers.vibeCode
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Authorization",
								value: MIGRATION_HOLD.headers.authorization
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Device",
								value: MIGRATION_HOLD.body.device.model
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Serial",
								value: MIGRATION_HOLD.body.device.serial
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Claimed protocol",
								value: MIGRATION_HOLD.body.securityProtocol
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "External verification",
								value: MIGRATION_HOLD.body.labels.externalVerification
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 print:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: () => downloadText("excalibur-core-engine-2026.yaml", engineYaml(), "text/yaml"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
						className: "size-3.5",
						strokeWidth: 1.6
					}), "Download YAML"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "outline",
					size: "sm",
					onClick: async () => {
						if (await copyText(engineYaml())) {
							setCopied(true);
							window.setTimeout(() => setCopied(false), 1400);
						}
					},
					children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), "Copy ledger"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-2",
				children: ENGINE_LEDGER.map((row) => {
					const expanded = open === row.id;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
						className: expanded ? "p-0 shadow-panel-hover" : "p-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setOpen(expanded ? null : row.id),
							"aria-expanded": expanded,
							className: "flex w-full items-start gap-3 px-4 py-3 text-left",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-14 shrink-0 font-mono text-xs tabular-nums text-muted",
								children: row.id
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex flex-wrap items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-medium",
										children: row.artifact
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, { children: row.action })]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 block font-mono text-xs text-subtle",
									children: [
										row.parentDigest,
										" → ",
										row.digest
									]
								})]
							})]
						}), expanded ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid gap-x-8 gap-y-3 border-t border-line px-4 py-4 text-sm sm:grid-cols-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Actor",
									value: row.actor
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Role",
									value: row.role
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Action",
									value: row.action
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Source",
									value: row.source
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Ingestion",
									value: row.ingestion
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Capability",
									value: row.capability
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Constraint",
									value: row.constraint
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Timestamp",
									value: row.timestamp
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Parent digest",
									value: row.parentDigest
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Digest",
									value: row.digest
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Classification",
									value: row.classification
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Evidence boundary",
									value: row.evidenceBoundary
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Workspace",
									value: row.workspace
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Artifact",
									value: row.artifact
								})
							]
						}) : null]
					}) }, row.id);
				})
			})
		]
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: label }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1",
		children: value
	})] });
}
function ListBlock({ title, items }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: title }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: "mt-2 space-y-1.5 text-sm text-muted",
		children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
	})] });
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mt-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "text-lg font-medium tracking-tight",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 text-sm leading-relaxed",
			children
		})]
	});
}
//#endregion
export { DoctrinePage as component };
