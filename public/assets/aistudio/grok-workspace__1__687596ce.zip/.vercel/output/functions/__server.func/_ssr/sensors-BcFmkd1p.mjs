import { i as __toESM } from "../_runtime.mjs";
import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as formatPct, O as Badge, S as formatCoord, h as SENSORS, k as cn, n as useExcalibur, s as KIND_META } from "./router-NnI91c-F.mjs";
import { i as Panel, n as Metric, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
import { a as sensorLive, i as provenanceHash } from "./live-nx98WfDC.mjs";
import { t as StatusDot } from "./status-dot-BITN0THI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sensors-BcFmkd1p.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FILTERS = [
	{
		id: "all",
		label: "All"
	},
	{
		id: "lidar",
		label: "LiDAR"
	},
	{
		id: "hsi",
		label: "HSI"
	},
	{
		id: "gpr",
		label: "GPR"
	},
	{
		id: "mag",
		label: "MAG"
	},
	{
		id: "hydro",
		label: "Hydro"
	},
	{
		id: "edge",
		label: "Edge"
	}
];
function SensorsPage() {
	const [filter, setFilter] = (0, import_react.useState)("all");
	const selectedId = useExcalibur((s) => s.selectedId);
	const setSelected = useExcalibur((s) => s.setSelected);
	const tick = useExcalibur((s) => s.tick);
	const rows = (0, import_react.useMemo)(() => filter === "all" ? SENSORS : SENSORS.filter((s) => s.kind === filter), [filter]);
	const selected = SENSORS.find((s) => s.id === selectedId) ?? rows[0];
	const live = selected ? sensorLive(selected.id, selected.health, tick) : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "Multi-sensor array",
				title: "Terrain sensing grid",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-sm text-sm text-muted",
					children: "LiDAR, hyperspectral, GPR, and magnetometry over the Lake Mead baseline. Edge nodes carry identity and provenance."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1",
				children: FILTERS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(f.id),
					className: cn("h-11 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out", filter === f.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-panel hover:text-fg"),
					children: f.label
				}, f.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, {
					className: "lg:col-span-3 lg:p-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-line",
						children: rows.map((s) => {
							const l = sensorLive(s.id, s.health, tick);
							const active = selected?.id === s.id;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setSelected(s.id),
								className: cn("flex w-full items-center gap-3 px-3 py-3 text-left transition-[background-color] duration-150 ease-out hover:bg-elevated", active && "bg-elevated"),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusDot, {
										health: s.health,
										pulse: true
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: s.name
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "font-mono text-xs text-muted",
											children: [
												s.id,
												" · ",
												KIND_META[s.kind].label
											]
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-xs tabular-nums text-fg",
											children: formatPct(l.anomaly, 1)
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "font-mono text-xs text-subtle",
											children: "anom"
										})]
									})
								]
							}) }, s.id);
						})
					})
				}), selected && live ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex flex-col gap-4 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: KIND_META[selected.kind].label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-lg font-medium",
								children: selected.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: selected.health === "nominal" ? "ok" : selected.health === "degraded" ? "caution" : "alert",
								children: selected.health
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: selected.notes
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: selected.spec
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Fix",
									value: formatCoord(selected.lat, selected.lon)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Elev",
									value: `${selected.elevM} m`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Packets",
									value: live.packets.toLocaleString()
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "SNR",
									value: `${live.snr.toFixed(1)} dB`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Delay",
									value: `${live.delayMs.toFixed(0)} ms`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
									label: "Integrity",
									value: formatPct(live.integrity, 1),
									tone: "ok"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-mono text-xs text-subtle",
							children: [
								"prov ",
								provenanceHash(selected.id, tick),
								" · cal ",
								selected.installed
							]
						})
					]
				}) : null]
			})
		]
	});
}
//#endregion
export { SensorsPage as component };
