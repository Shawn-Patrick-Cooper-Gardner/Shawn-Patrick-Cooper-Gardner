import { i as __toESM } from "../_runtime.mjs";
import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { D as Mark, O as Badge, i as CALIBRATION, k as cn, l as MANIFEST, p as PROGRAM, u as NIST_FAMILIES } from "./router-NnI91c-F.mjs";
import { i as Panel, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/package-EASNhmtH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var TABS = [
	{
		id: "cover",
		label: "Cover"
	},
	{
		id: "abstract",
		label: "Abstract"
	},
	{
		id: "directive",
		label: "Directive"
	},
	{
		id: "compliance",
		label: "Compliance"
	},
	{
		id: "calibration",
		label: "Calibration"
	},
	{
		id: "manifest",
		label: "Manifest"
	}
];
function PackagePage() {
	const [tab, setTab] = (0, import_react.useState)("cover");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-5xl flex-col gap-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "AFWERX CSO · internal binder",
				title: "Submission package",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: "caution",
					children: "Not yet submitted"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1 overflow-x-auto",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("h-11 shrink-0 rounded-md px-3 font-mono text-xs uppercase tracking-widest transition-[background-color,color] duration-150 ease-out", tab === t.id ? "bg-accent text-accent-fg" : "bg-surface text-muted shadow-panel hover:text-fg"),
					children: t.label
				}, t.id))
			}),
			tab === "cover" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cover, {}) : null,
			tab === "abstract" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Abstract, {}) : null,
			tab === "directive" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Directive, {}) : null,
			tab === "compliance" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compliance, {}) : null,
			tab === "calibration" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calibration, {}) : null,
			tab === "manifest" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Manifest, {}) : null
		]
	});
}
function Cover() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-6 sm:p-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-12" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: PROGRAM.control }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-mono text-xs text-alert",
						children: PROGRAM.classification
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-10 font-mono text-xs uppercase tracking-widest text-muted",
				children: PROGRAM.company
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-3 max-w-xl text-3xl font-medium tracking-widest",
				children: "EXCALIBUR"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-xl text-muted",
				children: PROGRAM.subtitle
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-mono text-xs uppercase tracking-widest text-subtle",
				children: PROGRAM.solicitation
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-10 grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Applicant",
						value: PROGRAM.legalName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Business structure",
						value: "Sole Proprietorship (U.S.)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Principal investigator",
						value: `${PROGRAM.pi}, ${PROGRAM.piTitle}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email / phone",
						value: `${PROGRAM.email} · ${PROGRAM.phone}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Operating location",
						value: PROGRAM.location
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "NAICS",
						value: `${PROGRAM.naics} — ${PROGRAM.naicsLabel}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Operational nexus",
						value: PROGRAM.theater
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "UEI / CAGE",
						value: "Internal placeholder — SAM.gov pending"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 border-t border-line pt-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Signature authority" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm font-medium tracking-wide",
						children: PROGRAM.pi.toUpperCase()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Principal Cloud Architect · ",
							PROGRAM.company,
							" · Boulder City, Nevada"
						]
					})
				]
			})
		]
	});
}
function Abstract() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Executive summary" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-medium",
				children: "Technical abstract"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-4 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Project EXCALIBUR is a dual-use research initiative integrating advanced terrain sensing, hazardous-material logistics modeling, and zero-trust cyber-physical telemetry security. The system is designed for deployment in austere, degraded-communication environments and supports defense, emergency response, and commercial logistics operations." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The Boulder City / Lake Mead theater provides a compact, instrumentable baseline: high-relief terrain, critical civil infrastructure at Hoover Dam, constrained tanker corridors on US-93 and I-11, and a hydrological body whose pool elevation is independently published. Phase I establishes that baseline. Later phases fabricate autonomous sensor units, apply edge-AI anomaly filters, and demonstrate a common operating picture." })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 grid gap-3 sm:grid-cols-3",
				children: [
					{
						t: "Terrain",
						d: "LiDAR, hyperspectral, GPR, and magnetometry fused against a shared grid."
					},
					{
						t: "Logistics",
						d: "Subpart H-aligned tanker surge and LCV stability on theater grades."
					},
					{
						t: "Telemetry",
						d: "NIST SP 800-171 provenance, OIDC identity, no CUI on public interfaces."
					}
				].map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-md bg-elevated p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: p.t
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: p.d
					})]
				}, p.t))
			})
		]
	});
}
function Directive() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "EXCALIBUR Directive" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-medium",
				children: "Internal operating instruction"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "mt-6 list-decimal space-y-4 pl-5 text-sm leading-relaxed text-muted",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The Principal Architect is system owner and sole signature authority for release of this package. No artifact leaves the binder without that authorization." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Public interfaces SHALL NOT ingest CUI or ITAR. Telemetry at the edge is signed, hashed, and forwarded through EDGE-01 as the provenance root." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Identity is federated (OIDC / OAuth 2.0) with mTLS between edge nodes. Local accounts are not provisioned on field units." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Sensor calibration residuals in this binder are the Phase I baseline. GPR-02 remains degraded pending EMI retune at Railroad Pass." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Source remains under internal code freeze pending Principal Architect approval. This console is a demonstration of the operating picture, not a production control system." })
				]
			})
		]
	});
}
function Compliance() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "overflow-x-auto p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 pb-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "NIST SP 800-171 Rev 2" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-2 text-xl font-medium",
					children: "Control alignment"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-xl text-sm text-muted",
					children: "Internal mapping only. Not a CMMC assessment. Zero-trust overlay per NIST SP 800-207. Subpart H security plan covers cargo-tank movements."
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "font-mono text-xs uppercase tracking-widest text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-y border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 py-2 font-medium",
							children: "Family"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Name"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Aligned"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 py-2 font-medium",
							children: "Note"
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: NIST_FAMILIES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-6 py-2.5 font-mono text-xs",
						children: f.id
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2.5",
						children: f.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-4 py-2.5 tabular-nums",
						children: [
							f.aligned,
							"/",
							f.controls
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-6 py-2.5 text-muted",
						children: f.note
					})
				]
			}, f.id)) })]
		})]
	});
}
function Calibration() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "overflow-x-auto p-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-6 pb-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Lake Mead baseline" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-medium",
				children: "Instrument calibration"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "font-mono text-xs uppercase tracking-widest text-muted",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-y border-line",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 py-2 font-medium",
							children: "Instrument"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Node"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Last"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Next"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-2 font-medium",
							children: "Residual"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-6 py-2 font-medium",
							children: "Standard"
						})
					]
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: CALIBRATION.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-line",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-6 py-2.5",
						children: r.instrument
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2.5 font-mono text-xs",
						children: r.node
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2.5 tabular-nums text-muted",
						children: r.last
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2.5 tabular-nums text-muted",
						children: r.next
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-2.5 font-mono text-xs",
						children: r.residual
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-6 py-2.5 text-muted",
						children: r.standard
					})
				]
			}, `${r.node}-${r.instrument}`)) })]
		})]
	});
}
function Manifest() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
		className: "p-6 sm:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "DARPA-PS-26-09_submission.zip" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 text-xl font-medium",
				children: "Archive manifest"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "All artifacts remain internal until Principal Architect release authorization. Checksums are demonstration values."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-line border-y border-line",
				children: MANIFEST.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-col gap-1 py-3 sm:flex-row sm:items-center sm:gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-sm",
							children: m.file
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex-1 text-sm text-muted",
							children: m.role
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-subtle",
							children: m.size
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-muted",
							children: m.sha
						})
					]
				}, m.file))
			})
		]
	});
}
function Field({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: label }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
		className: "mt-1",
		children: value
	})] });
}
//#endregion
export { PackagePage as component };
