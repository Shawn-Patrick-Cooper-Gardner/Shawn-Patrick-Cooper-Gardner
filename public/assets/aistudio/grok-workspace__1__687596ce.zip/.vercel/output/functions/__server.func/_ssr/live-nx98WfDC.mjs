import { E as seededUnit, T as hashString, h as SENSORS, o as CONVOYS, r as AUDIT_VERBS, w as formatZulu } from "./router-NnI91c-F.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/live-nx98WfDC.js
function sensorLive(id, health, tick) {
	const u = seededUnit(id, tick, 1);
	const u2 = seededUnit(id, tick, 7);
	const u3 = seededUnit(id, tick, 13);
	const baseAnom = health === "degraded" ? .24 : health === "offline" ? .61 : .035;
	return {
		packets: 8400 + Math.floor(u * 9200),
		anomaly: Math.max(0, Math.min(1, baseAnom + (u2 - .5) * .07)),
		snr: 14 + u3 * 12,
		delayMs: health === "degraded" ? 48 + u * 70 : 8 + u * 22,
		integrity: health === "offline" ? 0 : .97 + (u - .5) * .03
	};
}
function poolElevation(tick) {
	return 1065.4 + seededUnit("pool", tick, 2) * .35;
}
function provenanceHash(id, tick) {
	return hashString(`${id}:${Math.floor(tick / 3)}`).toString(16).padStart(8, "0");
}
function auditFeed(tick, now, count = 11) {
	const lines = [];
	for (let i = 0; i < count; i++) {
		const t = tick + 64 - i;
		const h = hashString(`audit:${t}`);
		const node = SENSORS[h % SENSORS.length];
		const verb = AUDIT_VERBS[h % AUDIT_VERBS.length];
		const d = /* @__PURE__ */ new Date(now.getTime() - i * 1400);
		let detail = `sig=${provenanceHash(node.id, t).slice(0, 6)}`;
		let tone = "neutral";
		if (verb === "ANOM") {
			detail = `score=${(.04 + h % 18 / 100).toFixed(2)}`;
			tone = node.health === "degraded" ? "caution" : "ok";
		} else if (verb === "DENY") {
			detail = "policy=OIDC.session";
			tone = "alert";
		} else if (verb === "AUTH") {
			detail = "oidc=ok  mfa=internal";
			tone = "ok";
		} else if (verb === "FRAME") detail = `pts=${(12e4 + h % 8e4).toString()}`;
		else if (verb === "ROUTE") {
			const c = CONVOYS[h % CONVOYS.length];
			detail = `${c.callsign}  ${c.un}`;
		} else if (verb === "PROV") {
			detail = `root=${provenanceHash("EDGE-01", t).slice(0, 6)}`;
			tone = "ok";
		}
		lines.push({
			id: `audit-${i}-${t}-${h}`,
			time: formatZulu(d),
			verb,
			node: node.id,
			detail,
			tone
		});
	}
	return lines;
}
function identitySessions(tick) {
	return [
		{
			id: "pi-root",
			subject: "gardner.s",
			role: "Principal Architect",
			method: "OIDC",
			age: `${12 + tick % 40}m`,
			status: "active"
		},
		{
			id: "edge-01",
			subject: "EDGE-01",
			role: "Issuer",
			method: "mTLS",
			age: "bound",
			status: "active"
		},
		{
			id: "edge-02",
			subject: "EDGE-02",
			role: "Relay",
			method: "mTLS",
			age: `${tick % 7 + 1} hops`,
			status: "active"
		},
		{
			id: "field-svc",
			subject: "field.cal",
			role: "Calibration",
			method: "OAuth 2.0",
			age: "standby",
			status: "idle"
		}
	];
}
//#endregion
export { sensorLive as a, provenanceHash as i, identitySessions as n, poolElevation as r, auditFeed as t };
