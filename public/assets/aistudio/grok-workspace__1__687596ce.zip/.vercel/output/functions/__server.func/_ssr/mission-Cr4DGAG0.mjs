import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Minus, f as Check } from "../_libs/lucide-react.mjs";
import { C as formatPct, O as Badge, f as PHASES, k as cn } from "./router-NnI91c-F.mjs";
import { i as Panel, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/mission-Cr4DGAG0.js
var import_jsx_runtime = require_jsx_runtime();
function MissionPage() {
	const overall = PHASES.reduce((a, p) => {
		const span = p.id === "I" ? 6 : p.id === "II" ? 8 : 10;
		return a + p.progress * span;
	}, 0) / 24;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "24-month program",
				title: "Mission phases",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "text-right",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Overall" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-2xl font-medium tabular-nums tracking-tight",
						children: formatPct(overall)
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Timeline" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex h-3 overflow-hidden rounded-sm bg-elevated",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-accent",
							style: { width: `25%` },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-fg/40",
								style: { width: formatPct(PHASES[0].progress) }
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-line",
							style: { width: `${8 / 24 * 100}%` }
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "bg-elevated",
							style: { width: `${10 / 24 * 100}%` }
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 flex justify-between font-mono text-xs text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M6" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M14" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "M24" })
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 lg:grid-cols-3",
				children: PHASES.map((phase) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "flex flex-col gap-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Kicker, { children: [
								"Phase ",
								phase.id,
								" · ",
								phase.window
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 text-lg font-medium tracking-tight",
								children: phase.name
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: phase.status === "active" ? "ok" : phase.status === "complete" ? "ok" : "neutral",
								children: phase.status
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs text-muted",
							children: phase.months
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-1 flex justify-between font-mono text-xs text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Progress" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums",
								children: formatPct(phase.progress)
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-1.5 rounded-sm bg-elevated",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full rounded-sm bg-accent",
								style: { width: formatPct(phase.progress) }
							})
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "space-y-2",
							children: phase.objectives.map((o) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-start gap-2 text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("mt-0.5 flex size-4 shrink-0 items-center justify-center rounded-sm", o.done ? "bg-ok/20 text-ok" : "bg-elevated text-subtle"),
									children: o.done ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: o.done ? "text-fg" : "text-muted",
									children: o.text
								})]
							}, o.id))
						})
					]
				}, phase.id))
			})
		]
	});
}
//#endregion
export { MissionPage as component };
