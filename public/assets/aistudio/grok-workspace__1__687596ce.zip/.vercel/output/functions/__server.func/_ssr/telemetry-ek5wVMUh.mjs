import { i as __toESM } from "../_runtime.mjs";
import { K as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { C as formatPct, O as Badge, k as cn, n as useExcalibur, u as NIST_FAMILIES } from "./router-NnI91c-F.mjs";
import { i as Panel, n as Metric, r as PageHeader, t as Kicker } from "./chrome-Cy9Zw8CL.mjs";
import { c as ResponsiveContainer, i as XAxis, l as Tooltip, r as YAxis, s as Bar, t as BarChart } from "../_libs/recharts+[...].mjs";
import { i as provenanceHash, n as identitySessions, t as auditFeed } from "./live-nx98WfDC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/telemetry-ek5wVMUh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function TelemetryPage() {
	const tick = useExcalibur((s) => s.tick);
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setNow(/* @__PURE__ */ new Date());
	}, [tick]);
	const aligned = NIST_FAMILIES.reduce((a, f) => a + f.aligned, 0);
	const total = NIST_FAMILIES.reduce((a, f) => a + f.controls, 0);
	const sessions = identitySessions(tick);
	const feed = now ? auditFeed(tick, now) : [];
	const chart = NIST_FAMILIES.map((f) => ({
		id: f.id,
		pct: Number((f.aligned / f.controls * 100).toFixed(0))
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-6xl flex-col gap-6 p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "NIST SP 800-171 · SP 800-207",
				title: "Zero-trust telemetry",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-md text-sm text-muted",
					children: "Identity, provenance, and control alignment. No CUI or ITAR crosses public interfaces. Federated OIDC / OAuth 2.0 at the edge."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "800-171 aligned",
						value: `${aligned}/${total}`,
						hint: formatPct(aligned / total),
						tone: "ok"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Provenance root",
						value: provenanceHash("EDGE-01", tick),
						hint: "EDGE-01 issuer"
					}) }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Panel, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
						label: "Sessions",
						value: `${sessions.filter((s) => s.status === "active").length} active`,
						hint: "OIDC · mTLS · OAuth 2.0"
					}) })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "lg:col-span-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Control family coverage" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: chart,
								margin: {
									top: 4,
									right: 4,
									left: -16,
									bottom: 0
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "id",
										tick: {
											fill: "var(--color-muted)",
											fontSize: 11
										},
										axisLine: { stroke: "var(--color-line)" },
										tickLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tick: {
											fill: "var(--color-muted)",
											fontSize: 12
										},
										axisLine: false,
										tickLine: false,
										domain: [0, 100]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										contentStyle: {
											background: "var(--color-elevated)",
											border: "1px solid var(--color-line)",
											borderRadius: 8,
											color: "var(--color-fg)",
											fontSize: 12
										},
										formatter: (value) => [`${value}%`, "aligned"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "pct",
										fill: "var(--color-accent)",
										radius: [
											3,
											3,
											0,
											0
										]
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, {
					className: "lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Identity sessions" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-line",
						children: sessions.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-3 py-2.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: s.subject
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-xs text-muted",
									children: [
										s.role,
										" · ",
										s.method
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
								tone: s.status === "active" ? "ok" : "neutral",
								children: s.age
							})]
						}, s.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Audit / provenance" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 space-y-1.5 font-mono text-xs",
					children: feed.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap gap-x-3 gap-y-0.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "tabular-nums text-subtle",
								children: line.time
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("w-10", line.tone === "ok" && "text-ok", line.tone === "caution" && "text-caution", line.tone === "alert" && "text-alert", line.tone === "neutral" && "text-accent"),
								children: line.verb
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-fg",
								children: line.node
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: line.detail
							})
						]
					}, line.id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Panel, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Kicker, { children: "Family notes" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 divide-y divide-line",
					children: NIST_FAMILIES.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-baseline gap-3 py-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "w-8 font-mono text-xs text-muted",
								children: f.id
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "flex-1 text-sm",
								children: f.name
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular-nums text-muted",
								children: [
									f.aligned,
									"/",
									f.controls
								]
							})
						]
					}, f.id))
				})] })]
			})
		]
	});
}
//#endregion
export { TelemetryPage as component };
